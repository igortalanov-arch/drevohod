// compact.js — compact family circle selection + printable SVG scheme
// Drevohod v102
//
// This module deliberately does not modify genealogy data. It builds a temporary
// view around one person, keeps complete sibling/family packets where possible,
// and renders the result as a self-contained SVG suitable for PNG/JPG/PDF export.

const compactTree = (function () {
  'use strict';

  const SVG_NS = 'http://www.w3.org/2000/svg';
  const CARD_W = 242;
  const CARD_H = 132;
  const CARD_GAP = 32;
  const BLOCK_GAP = 44;
  const ROW_GAP = 44;
  const MAX_CARDS_PER_ROW = 9;
  const SIDE_PAD = 118;
  const HEADER_H = 132;

  let _data = null;
  let _indexes = null;
  let _selection = null;
  let _layout = null;
  let _scale = 1;
  let _builderSelectedId = null;
  let _builderLimit = 50;
  let _renderToken = '';
  let _wired = false;
  let _drag = null;

  const tr = (ru, en) => (typeof i18n !== 'undefined' && i18n.currentLang === 'en') ? en : ru;

  function esc(value) {
    if (typeof dataModule !== 'undefined' && dataModule.escapeHtml) return dataModule.escapeHtml(value == null ? '' : String(value));
    return String(value == null ? '' : value).replace(/[&<>"']/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' })[c]);
  }

  function unique(values) {
    return Array.from(new Set(values || []));
  }

  function addToMapSet(map, key, value) {
    if (!map.has(key)) map.set(key, new Set());
    map.get(key).add(value);
  }

  function mapArray(map, key) {
    return Array.from(map.get(key) || []);
  }

  function buildIndexes(data) {
    const people = new Map();
    const parents = new Map();
    const children = new Map();
    const spouses = new Map();
    const explicitSiblings = new Map();
    const adjacency = new Map();

    (data && data.persons || []).forEach(p => {
      people.set(p.id, p);
      parents.set(p.id, new Set());
      children.set(p.id, new Set());
      spouses.set(p.id, new Set());
      explicitSiblings.set(p.id, new Set());
      adjacency.set(p.id, new Set());
    });

    (data && data.links || []).forEach(link => {
      if (!link || link.source === link.target || !people.has(link.source) || !people.has(link.target)) return;
      if (link.type === 'parent_child') {
        addToMapSet(children, link.source, link.target);
        addToMapSet(parents, link.target, link.source);
      } else if (link.type === 'marriage') {
        addToMapSet(spouses, link.source, link.target);
        addToMapSet(spouses, link.target, link.source);
      } else if (link.type === 'sibling') {
        addToMapSet(explicitSiblings, link.source, link.target);
        addToMapSet(explicitSiblings, link.target, link.source);
      } else {
        return;
      }
      addToMapSet(adjacency, link.source, link.target);
      addToMapSet(adjacency, link.target, link.source);
    });

    function siblingsOf(pid) {
      const result = new Set(explicitSiblings.get(pid) || []);
      (parents.get(pid) || []).forEach(parentId => {
        (children.get(parentId) || []).forEach(childId => {
          if (childId !== pid) result.add(childId);
        });
      });
      return result;
    }

    // Shared-parent siblings are valid graph neighbours even if an older JSON
    // file has not yet been through dataModule.syncLinks().
    people.forEach((person, pid) => {
      siblingsOf(pid).forEach(sid => {
        addToMapSet(adjacency, pid, sid);
        addToMapSet(adjacency, sid, pid);
      });
    });

    return { people, parents, children, spouses, explicitSiblings, adjacency, siblingsOf };
  }

  function directionalDepth(startId, map, maxDepth) {
    const result = new Map();
    let frontier = [startId];
    const visited = new Set([startId]);
    for (let depth = 1; depth <= maxDepth; depth++) {
      const next = [];
      frontier.forEach(id => {
        (map.get(id) || []).forEach(nextId => {
          if (visited.has(nextId)) return;
          visited.add(nextId);
          result.set(nextId, depth);
          next.push(nextId);
        });
      });
      frontier = next;
      if (!frontier.length) break;
    }
    return result;
  }

  function graphDistances(centerId, indexes) {
    const distances = new Map([[centerId, 0]]);
    const queue = [centerId];
    for (let i = 0; i < queue.length; i++) {
      const id = queue[i];
      const d = distances.get(id);
      (indexes.adjacency.get(id) || []).forEach(nid => {
        if (distances.has(nid)) return;
        distances.set(nid, d + 1);
        queue.push(nid);
      });
    }
    return distances;
  }

  function familyBundles(indexes) {
    const bundles = new Map();
    const addBundle = (key, type, members) => {
      const clean = unique(members).filter(id => indexes.people.has(id));
      if (clean.length > 1) bundles.set(key, { key, type, members: clean });
    };

    // A marriage is the smallest family packet.
    const marriageSeen = new Set();
    indexes.spouses.forEach((values, id) => {
      values.forEach(spouseId => {
        const pair = [id, spouseId].sort();
        const key = 'M:' + pair.join('|');
        if (marriageSeen.has(key)) return;
        marriageSeen.add(key);
        addBundle(key, 'spouse', pair);
      });
    });

    // Parent family: parents plus ALL children of either known parent. This is
    // what prevents a selected family from showing only one brother/sister.
    indexes.people.forEach((person, childId) => {
      const parentIds = mapArray(indexes.parents, childId).sort();
      if (!parentIds.length) return;
      const members = new Set(parentIds);
      parentIds.forEach(parentId => {
        (indexes.children.get(parentId) || []).forEach(id => members.add(id));
      });
      addBundle('P:' + parentIds.join('|'), 'parent-family', Array.from(members));
    });

    // Descendant family: all children of a person and every known co-parent.
    indexes.people.forEach((person, parentId) => {
      const childIds = mapArray(indexes.children, parentId);
      if (!childIds.length) return;
      const members = new Set([parentId]);
      childIds.forEach(childId => {
        members.add(childId);
        (indexes.parents.get(childId) || []).forEach(id => members.add(id));
      });
      addBundle('C:' + parentId, 'child-family', Array.from(members));
    });

    // Explicit sibling components cover incomplete imports without parents.
    const seen = new Set();
    indexes.people.forEach((person, startId) => {
      if (seen.has(startId) || !(indexes.explicitSiblings.get(startId) || new Set()).size) return;
      const component = [];
      const queue = [startId];
      seen.add(startId);
      for (let i = 0; i < queue.length; i++) {
        const id = queue[i];
        component.push(id);
        (indexes.explicitSiblings.get(id) || []).forEach(sid => {
          if (!seen.has(sid)) { seen.add(sid); queue.push(sid); }
        });
      }
      addBundle('S:' + component.slice().sort().join('|'), 'siblings', component);
    });

    return Array.from(bundles.values());
  }

  // Core selection rule:
  //   required = centre + spouse(s) + all centre siblings + 3 ancestor levels
  //              + 3 descendant levels + co-parents needed to explain descendants.
  // The target is intentionally soft. If the required circle itself is larger,
  // nobody required is dropped. Every optional family packet is accepted whole
  // or rejected whole, so the limit never cuts a sibling group in half.
  function buildSelection(data, centerId, requestedLimit) {
    const indexes = buildIndexes(data);
    if (!indexes.people.has(centerId)) return null;
    const limit = Math.max(10, Math.min(200, parseInt(requestedLimit, 10) || 50));
    const required = new Set([centerId]);
    const reasons = new Map([[centerId, 'center']]);
    const ancestorDepth = directionalDepth(centerId, indexes.parents, 3);
    const descendantDepth = directionalDepth(centerId, indexes.children, 3);

    ancestorDepth.forEach((depth, id) => { required.add(id); reasons.set(id, 'ancestor-' + depth); });
    descendantDepth.forEach((depth, id) => { required.add(id); reasons.set(id, 'descendant-' + depth); });

    indexes.siblingsOf(centerId).forEach(id => {
      required.add(id);
      if (!reasons.has(id)) reasons.set(id, 'sibling');
    });

    // The selected person's partner is essential context in an everyday family scheme.
    (indexes.spouses.get(centerId) || []).forEach(id => {
      required.add(id);
      if (!reasons.has(id)) reasons.set(id, 'spouse');
    });

    // If a child/grandchild/great-grandchild is present, include their other
    // parent where known; otherwise the visible family connector is misleading.
    Array.from(descendantDepth.keys()).forEach(childId => {
      (indexes.parents.get(childId) || []).forEach(parentId => {
        required.add(parentId);
        if (!reasons.has(parentId)) reasons.set(parentId, 'co-parent');
      });
    });

    const included = new Set(required);
    const distances = graphDistances(centerId, indexes);
    const bundles = familyBundles(indexes);
    const processed = new Set();
    let skippedBundles = 0;

    while (true) {
      const candidates = [];
      bundles.forEach(bundle => {
        if (processed.has(bundle.key)) return;
        const touches = bundle.members.some(id => included.has(id));
        const outside = bundle.members.filter(id => !included.has(id));
        if (!touches || !outside.length) return;
        const nearest = Math.min(...outside.map(id => distances.has(id) ? distances.get(id) : 999));
        const typeBonus = bundle.type === 'spouse' ? -0.25 : (bundle.type === 'siblings' ? -0.1 : 0);
        candidates.push({ bundle, outside, score: nearest + typeBonus + outside.length / 1000 });
      });
      if (!candidates.length) break;
      candidates.sort((a, b) => a.score - b.score || a.outside.length - b.outside.length || a.bundle.key.localeCompare(b.bundle.key));
      const candidate = candidates[0];
      processed.add(candidate.bundle.key);
      if (included.size + candidate.outside.length <= limit) {
        candidate.outside.forEach(id => {
          included.add(id);
          if (!reasons.has(id)) reasons.set(id, 'additional');
        });
      } else {
        skippedBundles++;
      }
    }

    const connectedCount = distances.size;
    return {
      centerId,
      limit,
      ids: Array.from(included),
      requiredIds: Array.from(required),
      reasons,
      ancestorDepth,
      descendantDepth,
      requiredCount: required.size,
      addedCount: included.size - required.size,
      skippedBundles,
      connectedCount,
      omittedCount: Math.max(0, connectedCount - included.size),
      builtAt: Date.now()
    };
  }

  function isFemale(person) { return person && person.gender === 'female'; }
  function isMale(person) { return person && person.gender === 'male'; }

  function roleFor(pid, centerId, indexes) {
    const p = indexes.people.get(pid);
    if (pid === centerId) return tr('Выбранный человек', 'Selected person');
    if ((indexes.spouses.get(centerId) || new Set()).has(pid)) {
      return isFemale(p) ? tr('Жена', 'Wife') : (isMale(p) ? tr('Муж', 'Husband') : tr('Супруг(а)', 'Spouse'));
    }
    if ((indexes.parents.get(centerId) || new Set()).has(pid)) {
      return isFemale(p) ? tr('Мать', 'Mother') : (isMale(p) ? tr('Отец', 'Father') : tr('Родитель', 'Parent'));
    }
    if ((indexes.children.get(centerId) || new Set()).has(pid)) {
      return isFemale(p) ? tr('Дочь', 'Daughter') : (isMale(p) ? tr('Сын', 'Son') : tr('Ребёнок', 'Child'));
    }
    if (indexes.siblingsOf(centerId).has(pid)) {
      return isFemale(p) ? tr('Сестра', 'Sister') : (isMale(p) ? tr('Брат', 'Brother') : tr('Брат / сестра', 'Sibling'));
    }

    const ancestors = directionalDepth(centerId, indexes.parents, 12);
    const descendants = directionalDepth(centerId, indexes.children, 12);
    if (ancestors.has(pid)) {
      const d = ancestors.get(pid);
      if (d === 2) return isFemale(p) ? tr('Бабушка', 'Grandmother') : tr('Дедушка', 'Grandfather');
      if (d === 3) return isFemale(p) ? tr('Прабабушка', 'Great-grandmother') : tr('Прадедушка', 'Great-grandfather');
      return tr(`Предок · ${d} поколение`, `Ancestor · generation ${d}`);
    }
    if (descendants.has(pid)) {
      const d = descendants.get(pid);
      if (d === 2) return isFemale(p) ? tr('Внучка', 'Granddaughter') : tr('Внук', 'Grandson');
      if (d === 3) return isFemale(p) ? tr('Правнучка', 'Great-granddaughter') : tr('Правнук', 'Great-grandson');
      return tr(`Потомок · ${d} поколение`, `Descendant · generation ${d}`);
    }

    // Aunts/uncles: sibling of either parent.
    for (const parentId of (indexes.parents.get(centerId) || [])) {
      if (indexes.siblingsOf(parentId).has(pid)) return isFemale(p) ? tr('Тётя', 'Aunt') : tr('Дядя', 'Uncle');
    }
    // Nephews/nieces: child of a centre sibling.
    for (const siblingId of indexes.siblingsOf(centerId)) {
      if ((indexes.children.get(siblingId) || new Set()).has(pid)) return isFemale(p) ? tr('Племянница', 'Niece') : tr('Племянник', 'Nephew');
    }
    // Cousins: child of an aunt/uncle.
    for (const parentId of (indexes.parents.get(centerId) || [])) {
      for (const auntUncleId of indexes.siblingsOf(parentId)) {
        if ((indexes.children.get(auntUncleId) || new Set()).has(pid)) return isFemale(p) ? tr('Двоюродная сестра', 'Cousin') : tr('Двоюродный брат', 'Cousin');
      }
    }
    // Spouse of a child or a sibling.
    for (const childId of (indexes.children.get(centerId) || [])) {
      if ((indexes.spouses.get(childId) || new Set()).has(pid)) return isFemale(p) ? tr('Невестка', 'Daughter-in-law') : tr('Зять', 'Son-in-law');
    }
    for (const siblingId of indexes.siblingsOf(centerId)) {
      if ((indexes.spouses.get(siblingId) || new Set()).has(pid)) {
        const sibling = indexes.people.get(siblingId);
        if (isFemale(p)) return isMale(sibling) ? tr('Жена брата', "Brother's wife") : tr('Супруга родственницы', "Relative's wife");
        return isFemale(sibling) ? tr('Муж сестры', "Sister's husband") : tr('Супруг родственника', "Relative's husband");
      }
    }

    // Generic but still explicit label for partners of a known relative.
    for (const spouseId of (indexes.spouses.get(pid) || [])) {
      const spouseRole = roleForWithoutSpouseLoop(spouseId, centerId, indexes);
      if (spouseRole) return spouseOfRoleLabel(p, spouseRole);
    }
    return isFemale(p) ? tr('Родственница', 'Relative') : tr('Родственник', 'Relative');
  }

  function spouseOfRoleLabel(person, baseRole) {
    const prefixRu = isFemale(person) ? 'Жена' : (isMale(person) ? 'Муж' : 'Супруг(а)');
    const prefixEn = isFemale(person) ? 'Wife' : (isMale(person) ? 'Husband' : 'Spouse');
    if (typeof i18n !== 'undefined' && i18n.currentLang === 'en') return `${prefixEn} of ${String(baseRole).toLowerCase()}`;
    const genitive = {
      'сын':'сына', 'дочь':'дочери', 'брат':'брата', 'сестра':'сестры',
      'внук':'внука', 'внучка':'внучки', 'правнук':'правнука', 'правнучка':'правнучки',
      'отец':'отца', 'мать':'матери', 'дедушка':'дедушки', 'бабушка':'бабушки',
      'предок':'предка', 'потомок':'потомка', 'выбранного человека':'выбранного человека'
    };
    const key = String(baseRole).toLowerCase();
    return `${prefixRu} ${genitive[key] || key}`;
  }

  function roleForWithoutSpouseLoop(pid, centerId, indexes) {
    const p = indexes.people.get(pid);
    if (pid === centerId) return tr('выбранного человека', 'selected person');
    if ((indexes.parents.get(centerId) || new Set()).has(pid)) return isFemale(p) ? tr('мать', 'mother') : tr('отец', 'father');
    if ((indexes.children.get(centerId) || new Set()).has(pid)) return isFemale(p) ? tr('дочь', 'daughter') : tr('сын', 'son');
    if (indexes.siblingsOf(centerId).has(pid)) return isFemale(p) ? tr('сестра', 'sister') : tr('брат', 'brother');
    const a = directionalDepth(centerId, indexes.parents, 3);
    const d = directionalDepth(centerId, indexes.children, 3);
    if (a.has(pid)) {
      if (a.get(pid) === 2) return isFemale(p) ? tr('бабушка', 'grandmother') : tr('дедушка', 'grandfather');
      if (a.get(pid) === 3) return isFemale(p) ? tr('прабабушка', 'great-grandmother') : tr('прадедушка', 'great-grandfather');
      return tr('предок', 'ancestor');
    }
    if (d.has(pid)) {
      if (d.get(pid) === 2) return isFemale(p) ? tr('внучка', 'granddaughter') : tr('внук', 'grandson');
      if (d.get(pid) === 3) return isFemale(p) ? tr('правнучка', 'great-granddaughter') : tr('правнук', 'great-grandson');
      return tr('потомок', 'descendant');
    }
    return '';
  }

  function computeLevels(selection, indexes) {
    const allowed = new Set(selection.ids);
    const levels = new Map([[selection.centerId, 0]]);
    const queue = [selection.centerId];
    for (let i = 0; i < queue.length; i++) {
      const id = queue[i];
      const level = levels.get(id);
      const push = (nextId, delta) => {
        if (!allowed.has(nextId) || levels.has(nextId)) return;
        levels.set(nextId, level + delta);
        queue.push(nextId);
      };
      // Blood direction is processed before same-generation links.
      (indexes.parents.get(id) || []).forEach(nid => push(nid, -1));
      (indexes.children.get(id) || []).forEach(nid => push(nid, 1));
      (indexes.spouses.get(id) || []).forEach(nid => push(nid, 0));
      indexes.siblingsOf(id).forEach(nid => push(nid, 0));
    }
    // A defensive fallback for malformed but connected cyclic data.
    selection.ids.forEach(id => { if (!levels.has(id)) levels.set(id, 0); });
    return levels;
  }

  function personSort(a, b, indexes) {
    const pa = indexes.people.get(a), pb = indexes.people.get(b);
    const ya = (typeof dataModule !== 'undefined' && dataModule.getBirthYear) ? (dataModule.getBirthYear(pa) || 9999) : 9999;
    const yb = (typeof dataModule !== 'undefined' && dataModule.getBirthYear) ? (dataModule.getBirthYear(pb) || 9999) : 9999;
    if (ya !== yb) return ya - yb;
    const na = pa ? [pa.lastName, pa.firstName, pa.patronymic].filter(Boolean).join(' ') : '';
    const nb = pb ? [pb.lastName, pb.firstName, pb.patronymic].filter(Boolean).join(' ') : '';
    return na.localeCompare(nb, (typeof i18n !== 'undefined' ? i18n.currentLang : 'ru'));
  }

  function spouseBlocks(ids, level, levels, indexes, centerId) {
    const allowed = new Set(ids);
    const parent = new Map(ids.map(id => [id, id]));
    const find = id => {
      let root = id;
      while (parent.get(root) !== root) root = parent.get(root);
      let cur = id;
      while (parent.get(cur) !== cur) { const next = parent.get(cur); parent.set(cur, root); cur = next; }
      return root;
    };
    const union = (a, b) => { const ra = find(a), rb = find(b); if (ra !== rb) parent.set(rb, ra); };
    ids.forEach(id => {
      (indexes.spouses.get(id) || []).forEach(sid => {
        if (allowed.has(sid) && levels.get(sid) === level) union(id, sid);
      });
    });
    const groups = new Map();
    ids.forEach(id => {
      const root = find(id);
      if (!groups.has(root)) groups.set(root, []);
      groups.get(root).push(id);
    });
    const blocks = Array.from(groups.values()).map(members => {
      members.sort((a, b) => {
        if (a === centerId) return -1;
        if (b === centerId) return 1;
        return personSort(a, b, indexes);
      });
      return { members };
    });
    blocks.sort((a, b) => personSort(a.members[0], b.members[0], indexes));
    return blocks;
  }

  function orderBlocksByFamily(levelBlocks, levels, indexes) {
    const levelKeys = Array.from(levelBlocks.keys()).sort((a, b) => a - b);
    const positionMap = () => {
      const result = new Map();
      levelKeys.forEach(level => {
        let pos = 0;
        (levelBlocks.get(level) || []).forEach(block => {
          block.members.forEach(id => result.set(id, pos));
          pos += block.members.length;
        });
      });
      return result;
    };

    for (let pass = 0; pass < 3; pass++) {
      let pos = positionMap();
      levelKeys.forEach(level => {
        const blocks = levelBlocks.get(level);
        blocks.forEach((block, stable) => {
          const refs = [];
          block.members.forEach(id => (indexes.parents.get(id) || []).forEach(pid => { if (levels.get(pid) === level - 1 && pos.has(pid)) refs.push(pos.get(pid)); }));
          block._score = refs.length ? refs.reduce((a,b) => a+b, 0) / refs.length : 10000 + stable;
        });
        blocks.sort((a,b) => a._score - b._score);
      });
      pos = positionMap();
      levelKeys.slice().reverse().forEach(level => {
        const blocks = levelBlocks.get(level);
        blocks.forEach((block, stable) => {
          const refs = [];
          block.members.forEach(id => (indexes.children.get(id) || []).forEach(cid => { if (levels.get(cid) === level + 1 && pos.has(cid)) refs.push(pos.get(cid)); }));
          if (refs.length) block._score = refs.reduce((a,b) => a+b, 0) / refs.length;
          else block._score = 10000 + stable;
        });
        blocks.sort((a,b) => a._score - b._score);
      });
    }
  }

  function packBlockRows(blocks) {
    const rows = [];
    let row = [];
    let slots = 0;
    blocks.forEach(block => {
      const size = block.members.length;
      if (row.length && slots + size > MAX_CARDS_PER_ROW) {
        rows.push(row); row = []; slots = 0;
      }
      row.push(block);
      slots += size;
      if (slots >= MAX_CARDS_PER_ROW) { rows.push(row); row = []; slots = 0; }
    });
    if (row.length) rows.push(row);
    return rows.length ? rows : [[]];
  }

  function rowWidth(row) {
    if (!row.length) return 0;
    let width = 0;
    row.forEach((block, bi) => {
      if (bi) width += BLOCK_GAP;
      width += block.members.length * CARD_W + Math.max(0, block.members.length - 1) * CARD_GAP;
    });
    return width;
  }

  function generationLabel(level) {
    const labelsRu = {
      '-3': 'Прабабушки и прадедушки', '-2': 'Бабушки и дедушки', '-1': 'Родители и их поколение',
      '0': 'Выбранный человек и его поколение', '1': 'Дети и их поколение',
      '2': 'Внуки и их поколение', '3': 'Правнуки и их поколение'
    };
    const labelsEn = {
      '-3': 'Great-grandparents', '-2': 'Grandparents', '-1': "Parents' generation",
      '0': "Selected person's generation", '1': "Children's generation",
      '2': "Grandchildren's generation", '3': "Great-grandchildren's generation"
    };
    const labels = (typeof i18n !== 'undefined' && i18n.currentLang === 'en') ? labelsEn : labelsRu;
    if (labels[String(level)]) return labels[String(level)];
    return level < 0 ? tr(`Предки · ${Math.abs(level)} поколение`, `Ancestors · generation ${Math.abs(level)}`)
                     : tr(`Потомки · ${level} поколение`, `Descendants · generation ${level}`);
  }

  function createLayout(selection, indexes) {
    const levels = computeLevels(selection, indexes);
    const byLevel = new Map();
    selection.ids.forEach(id => {
      const level = levels.get(id) || 0;
      if (!byLevel.has(level)) byLevel.set(level, []);
      byLevel.get(level).push(id);
    });
    const levelBlocks = new Map();
    byLevel.forEach((ids, level) => levelBlocks.set(level, spouseBlocks(ids, level, levels, indexes, selection.centerId)));
    orderBlocksByFamily(levelBlocks, levels, indexes);

    const packed = new Map();
    let widest = 0;
    levelBlocks.forEach((blocks, level) => {
      const rows = packBlockRows(blocks);
      packed.set(level, rows);
      rows.forEach(row => { widest = Math.max(widest, rowWidth(row)); });
    });
    const width = Math.max(1180, Math.ceil(widest + SIDE_PAD * 2));
    const nodes = new Map();
    const bands = [];
    const levelsSorted = Array.from(packed.keys()).sort((a,b) => a-b);
    let cursorY = HEADER_H;

    levelsSorted.forEach((level, bandIndex) => {
      const rows = packed.get(level);
      const bandTop = cursorY;
      const labelH = 42;
      rows.forEach((row, rowIndex) => {
        const rw = rowWidth(row);
        let x = (width - rw) / 2;
        const y = bandTop + labelH + rowIndex * (CARD_H + ROW_GAP);
        row.forEach((block, bi) => {
          if (bi) x += BLOCK_GAP;
          block.members.forEach((id, mi) => {
            if (mi) x += CARD_GAP;
            nodes.set(id, { id, x, y, width: CARD_W, height: CARD_H, level, row: rowIndex, block });
            x += CARD_W;
          });
        });
      });
      const bandHeight = labelH + rows.length * CARD_H + Math.max(0, rows.length - 1) * ROW_GAP + 44;
      bands.push({ level, y: bandTop, height: bandHeight, label: generationLabel(level), index: bandIndex });
      cursorY += bandHeight + 18;
    });

    return { width, height: Math.ceil(cursorY + 42), nodes, bands, levels, packed };
  }

  function yearOnly(value) {
    const match = String(value || '').match(/(\d{4})/);
    return match ? match[1] : '?';
  }

  function initials(person) {
    const a = (person && person.firstName || '').trim().charAt(0);
    const b = (person && person.lastName || '').trim().charAt(0);
    return (a + b).toUpperCase() || '?';
  }

  function fitTextAttrs(text, maxWidth, fontSize) {
    const approx = Array.from(String(text || '')).length * fontSize * 0.57;
    return approx > maxWidth ? ` textLength="${maxWidth}" lengthAdjust="spacingAndGlyphs"` : '';
  }

  function cardSvg(node, person, role, isCenter) {
    const x = node.x, y = node.y;
    const female = person.gender === 'female';
    const accent = female ? '#c23673' : (person.gender === 'male' ? '#2f6fbd' : '#64748b');
    const soft = female ? '#fdf0f6' : (person.gender === 'male' ? '#eef6ff' : '#f1f5f9');
    const alive = (typeof dataModule !== 'undefined' && dataModule.isAlive) ? dataModule.isAlive(person) : person.status !== 'deceased';
    const life = alive ? (female ? tr('Жива', 'Alive') : tr('Жив', 'Alive')) : (female ? tr('Умерла', 'Deceased') : tr('Умер', 'Deceased'));
    const lifeColor = alive ? '#15803d' : '#64748b';
    const birth = yearOnly(person.birthDate);
    const death = alive && !person.deathDate ? tr('н. в.', 'present') : yearOnly(person.deathDate);
    const surname = person.lastName || person.maidenName || tr('Без фамилии', 'No surname');
    const first = person.firstName || tr('Без имени', 'No name');
    const patronymic = person.patronymic || '';
    const roleWidth = Math.min(CARD_W - 24, Math.max(78, Array.from(role).length * 6.4 + 22));
    const outline = isCenter ? '#d49a16' : '#d9e2ec';
    const outlineW = isCenter ? 3 : 1.2;
    const textMax = CARD_W - 78;
    return `
      <g class="compact-person-card" data-person-card="1" data-pid="${esc(person.id)}" role="button" tabindex="0" aria-label="${esc([surname, first, patronymic, role].filter(Boolean).join(' '))}">
        <rect x="${x}" y="${y}" width="${CARD_W}" height="${CARD_H}" rx="14" fill="#ffffff" stroke="${outline}" stroke-width="${outlineW}" filter="url(#cardShadow)"/>
        <rect x="${x}" y="${y}" width="7" height="${CARD_H}" rx="4" fill="${accent}"/>
        <rect x="${x + 13}" y="${y + 10}" width="${roleWidth}" height="21" rx="10.5" fill="${isCenter ? '#fff4cc' : soft}"/>
        <text x="${x + 23}" y="${y + 24.5}" class="ct-role" fill="${isCenter ? '#8a5b00' : accent}"${fitTextAttrs(role, roleWidth - 20, 10.8)}>${esc(role)}</text>
        ${isCenter ? `<text x="${x + CARD_W - 22}" y="${y + 26}" class="ct-star">★</text>` : ''}
        <circle cx="${x + 35}" cy="${y + 61}" r="20" fill="${soft}" stroke="${accent}" stroke-width="1.5"/>
        <text x="${x + 35}" y="${y + 66}" text-anchor="middle" class="ct-initials" fill="${accent}">${esc(initials(person))}</text>
        <text x="${x + 65}" y="${y + 49}" class="ct-surname"${fitTextAttrs(surname, textMax, 13.2)}>${esc(surname)}</text>
        <text x="${x + 65}" y="${y + 66}" class="ct-name"${fitTextAttrs(first, textMax, 12.3)}>${esc(first)}</text>
        ${patronymic ? `<text x="${x + 65}" y="${y + 82}" class="ct-name"${fitTextAttrs(patronymic, textMax, 11.7)}>${esc(patronymic)}</text>` : ''}
        <line x1="${x + 14}" y1="${y + 92}" x2="${x + CARD_W - 14}" y2="${y + 92}" stroke="#e8edf3"/>
        <text x="${x + 16}" y="${y + 110}" class="ct-years">${esc(birth)} — ${esc(death)}</text>
        <circle cx="${x + 17}" cy="${y + 121}" r="3.2" fill="${lifeColor}"/>
        <text x="${x + 26}" y="${y + 125}" class="ct-life" fill="${lifeColor}">${esc(life)}</text>
      </g>`;
  }

  function connectorSvg(layout, selection, indexes) {
    const allowed = new Set(selection.ids);
    const parts = [];
    const familyChildren = new Map();

    selection.ids.forEach(childId => {
      const childNode = layout.nodes.get(childId);
      if (!childNode) return;
      const selectedParents = mapArray(indexes.parents, childId)
        .filter(pid => allowed.has(pid) && layout.nodes.has(pid) && layout.levels.get(pid) < layout.levels.get(childId))
        .sort();
      if (!selectedParents.length) return;
      const key = selectedParents.join('|');
      if (!familyChildren.has(key)) familyChildren.set(key, { parents: selectedParents, children: [] });
      familyChildren.get(key).children.push(childId);
    });

    familyChildren.forEach(family => {
      const parentNodes = family.parents.map(id => layout.nodes.get(id)).filter(Boolean);
      if (!parentNodes.length) return;
      const sx = parentNodes.reduce((sum,n) => sum + n.x + n.width / 2, 0) / parentNodes.length;
      const sy = Math.max(...parentNodes.map(n => n.y + n.height));
      // Classic family-tree buses are much easier to follow than a fan of
      // overlapping curves. Wrapped generation rows get one bus per row.
      const childrenByRow = new Map();
      family.children.forEach(childId => {
        const child = layout.nodes.get(childId);
        if (!child) return;
        if (!childrenByRow.has(child.y)) childrenByRow.set(child.y, []);
        childrenByRow.get(child.y).push(child);
      });
      childrenByRow.forEach((childNodes, targetY) => {
        const targets = childNodes.map(child => child.x + child.width / 2).sort((a,b) => a-b);
        const busY = targetY - 20;
        const minX = Math.min(sx, targets[0]);
        const maxX = Math.max(sx, targets[targets.length - 1]);
        let d = `M ${sx} ${sy} L ${sx} ${busY} M ${minX} ${busY} L ${maxX} ${busY}`;
        targets.forEach(tx => { d += ` M ${tx} ${busY} L ${tx} ${targetY}`; });
        parts.push(`<path d="${d}" class="ct-parent-link" fill="none" stroke="#8295aa" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" opacity="0.67"/>`);
      });
      parts.push(`<circle cx="${sx}" cy="${sy + 2}" r="4" class="ct-family-dot" fill="#8295aa"/>`);
    });

    const marriageSeen = new Set();
    selection.ids.forEach(id => {
      (indexes.spouses.get(id) || []).forEach(sid => {
        if (!allowed.has(sid) || !layout.nodes.has(id) || !layout.nodes.has(sid)) return;
        const key = [id, sid].sort().join('|');
        if (marriageSeen.has(key)) return;
        marriageSeen.add(key);
        const a = layout.nodes.get(id), b = layout.nodes.get(sid);
        if (a.level !== b.level) return;
        const left = a.x < b.x ? a : b;
        const right = a.x < b.x ? b : a;
        const y = left.y + 66;
        const x1 = left.x + left.width;
        const x2 = right.x;
        if (x2 <= x1) return;
        parts.push(`<line x1="${x1}" y1="${y}" x2="${x2}" y2="${y}" class="ct-marriage-link" stroke="#b54a78" stroke-width="2" stroke-dasharray="5 4" opacity="0.82"/>`);
        parts.push(`<circle cx="${(x1 + x2)/2}" cy="${y}" r="7" fill="#fff" stroke="#b54a78" stroke-width="1.6"/>`);
        parts.push(`<text x="${(x1 + x2)/2}" y="${y + 3.6}" text-anchor="middle" class="ct-marriage-mark">∞</text>`);
      });
    });
    return parts.join('\n');
  }

  function buildSvgString(data, selection, layout, indexes) {
    const center = indexes.people.get(selection.centerId);
    const centerName = (typeof dataModule !== 'undefined' && dataModule.getFullName) ? dataModule.getFullName(center) : [center.lastName, center.firstName, center.patronymic].filter(Boolean).join(' ');
    const title = tr('Круг семьи', 'Family circle') + ': ' + centerName;
    const subtitle = tr(
      `${selection.ids.length} человек · ориентир ${selection.limit} · обязательных ${selection.requiredCount}`,
      `${selection.ids.length} people · target ${selection.limit} · required ${selection.requiredCount}`
    );
    const bands = layout.bands.map(band => `
      <g class="ct-band">
        <rect x="22" y="${band.y}" width="${layout.width - 44}" height="${band.height}" rx="18" fill="${band.index % 2 ? '#f8fbff' : '#fbfcfe'}" stroke="#e5ebf2"/>
        <rect x="36" y="${band.y + 13}" width="6" height="18" rx="3" fill="${band.level === 0 ? '#d49a16' : '#7c93ad'}"/>
        <text x="52" y="${band.y + 27}" class="ct-band-label">${esc(band.label)}</text>
        <text x="${layout.width - 48}" y="${band.y + 27}" text-anchor="end" class="ct-band-count">${esc(String(Array.from(layout.nodes.values()).filter(n => n.level === band.level).length))} ${tr('чел.', 'people')}</text>
      </g>`).join('');
    const cards = Array.from(layout.nodes.values())
      .sort((a,b) => a.y-b.y || a.x-b.x)
      .map(node => cardSvg(node, indexes.people.get(node.id), roleFor(node.id, selection.centerId, indexes), node.id === selection.centerId))
      .join('\n');

    return `<svg id="compact-svg" xmlns="${SVG_NS}" width="${layout.width}" height="${layout.height}" viewBox="0 0 ${layout.width} ${layout.height}" role="img" aria-label="${esc(title)}">
      <defs>
        <filter id="cardShadow" x="-15%" y="-20%" width="130%" height="150%"><feDropShadow dx="0" dy="3" stdDeviation="4" flood-color="#1e293b" flood-opacity="0.11"/></filter>
        <style>
          text{font-family:'Segoe UI',Arial,sans-serif}.ct-title{font-size:24px;font-weight:750;fill:#16243a}.ct-subtitle{font-size:12.5px;fill:#64748b}.ct-brand{font-size:11px;font-weight:700;letter-spacing:1.2px;fill:#8a9aae}.ct-band-label{font-size:12px;font-weight:750;letter-spacing:.35px;fill:#43566e;text-transform:uppercase}.ct-band-count{font-size:11px;fill:#8a9aae}.ct-role{font-size:10.8px;font-weight:750}.ct-star{font-size:18px;fill:#d49a16}.ct-initials{font-size:12px;font-weight:800}.ct-surname{font-size:13.2px;font-weight:750;fill:#17243a}.ct-name{font-size:12px;font-weight:560;fill:#334155}.ct-years{font-size:12px;font-weight:700;fill:#334155}.ct-life{font-size:9.8px;font-weight:650}.ct-parent-link{fill:none;stroke:#8295aa;stroke-width:1.7;stroke-linecap:round;opacity:.67}.ct-family-dot{fill:#8295aa}.ct-marriage-link{stroke:#b54a78;stroke-width:2;stroke-dasharray:5 4;opacity:.82}.ct-marriage-mark{font-size:12px;font-weight:800;fill:#a23666}.compact-person-card{cursor:pointer}.compact-person-card:hover rect:first-child{stroke:#2f6fbd;stroke-width:2.4}
        </style>
      </defs>
      <rect width="100%" height="100%" fill="#f3f6fa"/>
      <rect x="22" y="18" width="${layout.width - 44}" height="96" rx="20" fill="#ffffff" stroke="#e2e8f0"/>
      <rect x="22" y="18" width="10" height="96" rx="5" fill="#d49a16"/>
      <text x="52" y="48" class="ct-brand">${tr('ДРЕВОХОД · СОКРАЩЁННАЯ СХЕМА', 'DREVOKHOD · COMPACT SCHEME')}</text>
      <text x="52" y="78" class="ct-title"${fitTextAttrs(title, layout.width - 360, 24)}>${esc(title)}</text>
      <text x="52" y="101" class="ct-subtitle">${esc(subtitle)}</text>
      <g transform="translate(${layout.width - 265},42)">
        <line x1="0" y1="14" x2="50" y2="14" class="ct-parent-link" stroke="#8295aa" stroke-width="1.7"/><text x="60" y="18" class="ct-subtitle">${tr('родство', 'parent / child')}</text>
        <line x1="0" y1="42" x2="50" y2="42" class="ct-marriage-link" stroke="#b54a78" stroke-width="2" stroke-dasharray="5 4"/><text x="60" y="46" class="ct-subtitle">${tr('брак / пара', 'marriage / couple')}</text>
      </g>
      ${bands}
      <g id="compact-connectors">${connectorSvg(layout, selection, indexes)}</g>
      <g id="compact-cards">${cards}</g>
    </svg>`;
  }

  function selectionIsValid(data) {
    if (!_selection || !data || !Array.isArray(data.persons)) return false;
    return data.persons.some(p => p.id === _selection.centerId);
  }

  function hasSelection(data) {
    return selectionIsValid(data || _data);
  }

  function render(data) {
    _data = data || _data;
    const root = document.getElementById('compact-mode');
    if (!root) return;
    localize();
    if (!selectionIsValid(_data)) {
      root.classList.add('compact-empty');
      const empty = document.getElementById('compact-empty-state');
      if (empty) empty.style.display = 'flex';
      const viewport = document.getElementById('compact-viewport');
      if (viewport) viewport.style.display = 'none';
      return;
    }
    root.classList.remove('compact-empty');
    const empty = document.getElementById('compact-empty-state');
    if (empty) empty.style.display = 'none';
    const viewport = document.getElementById('compact-viewport');
    if (viewport) viewport.style.display = '';

    _indexes = buildIndexes(_data);
    // Drop IDs no longer present after editing/importing, while preserving centre.
    _selection.ids = _selection.ids.filter(id => _indexes.people.has(id));
    _layout = createLayout(_selection, _indexes);
    const stage = document.getElementById('compact-stage');
    if (!stage) return;
    stage.innerHTML = buildSvgString(_data, _selection, _layout, _indexes);
    stage.style.width = Math.round(_layout.width * _scale) + 'px';
    stage.style.height = Math.round(_layout.height * _scale) + 'px';

    stage.querySelectorAll('[data-person-card]').forEach(card => {
      const open = () => {
        const pid = card.getAttribute('data-pid');
        if (typeof app !== 'undefined') {
          app.selectedPersonId = pid;
          if (app._highlightChain) app._highlightChain(pid);
          if (app._openPersonPanel) app._openPersonPanel(pid);
        }
      };
      card.addEventListener('click', open);
      card.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); open(); } });
    });

    updateInfo();
    wireViewport();
    const token = `${_selection.centerId}|${_selection.ids.join(',')}|${i18n.currentLang}`;
    if (_renderToken !== token) {
      _renderToken = token;
      requestAnimationFrame(() => fitToScreen());
    } else {
      applyScale();
    }
  }

  function updateInfo() {
    if (!_selection || !_indexes) return;
    const center = _indexes.people.get(_selection.centerId);
    const name = center && dataModule.getFullName(center) || '';
    const set = (id, value) => { const el = document.getElementById(id); if (el) el.textContent = value; };
    set('compact-center-name', name);
    set('compact-count', `${_selection.ids.length} ${tr('человек', 'people')}`);
    set('compact-target', `${tr('Ориентир', 'Target')}: ${_selection.limit}`);
    set('compact-required', `${tr('Обязательный круг', 'Required circle')}: ${_selection.requiredCount}`);
    set('compact-added', `${tr('Дополнительно', 'Additional')}: ${_selection.addedCount}`);
    const note = document.getElementById('compact-limit-note');
    if (note) {
      if (_selection.requiredCount > _selection.limit) {
        note.textContent = tr(
          `Обязательных родственников ${_selection.requiredCount}, поэтому мягкий лимит ${_selection.limit} превышен. Никто из обязательного круга не скрыт.`,
          `${_selection.requiredCount} relatives are required, so the soft limit of ${_selection.limit} was exceeded. Nobody in the required circle was hidden.`
        );
      } else if (_selection.ids.length < _selection.limit) {
        note.textContent = tr(
          `Показаны все подходящие целые семейные группы: ${_selection.ids.length} из ориентира ${_selection.limit}. Ветки не разрезаются ради точного числа.`,
          `All fitting complete family groups are shown: ${_selection.ids.length} of the ${_selection.limit} target. Branches are not split just to reach an exact number.`
        );
      } else {
        note.textContent = tr(
          `Схема собрана близко к ориентиру. Следующие ветви не добавлены целиком, чтобы не разрезать семьи.`,
          `The scheme is close to the target. Further branches were omitted whole rather than splitting families.`
        );
      }
    }
  }

  function applyScale() {
    if (!_layout) return;
    const stage = document.getElementById('compact-stage');
    if (stage) {
      stage.style.width = Math.round(_layout.width * _scale) + 'px';
      stage.style.height = Math.round(_layout.height * _scale) + 'px';
    }
    const label = document.getElementById('compact-zoom-label');
    if (label) label.textContent = Math.round(_scale * 100) + '%';
  }

  function zoomBy(factor) {
    _scale = Math.max(0.18, Math.min(2.25, _scale * factor));
    applyScale();
  }

  function zoomTo(value) {
    _scale = Math.max(0.18, Math.min(2.25, Number(value) || 1));
    applyScale();
  }

  function fitToScreen() {
    if (!_layout) return;
    const viewport = document.getElementById('compact-viewport');
    if (!viewport) return;
    const w = Math.max(200, viewport.clientWidth - 42);
    const h = Math.max(160, viewport.clientHeight - 42);
    _scale = Math.max(0.18, Math.min(1.15, Math.min(w / _layout.width, h / _layout.height)));
    applyScale();
    requestAnimationFrame(() => {
      viewport.scrollLeft = Math.max(0, (viewport.scrollWidth - viewport.clientWidth) / 2);
      viewport.scrollTop = 0;
    });
  }

  function wireViewport() {
    if (_wired) return;
    const viewport = document.getElementById('compact-viewport');
    if (!viewport) return;
    _wired = true;
    viewport.addEventListener('wheel', e => {
      if (!e.ctrlKey && !e.metaKey) return;
      e.preventDefault();
      zoomBy(e.deltaY < 0 ? 1.12 : 1 / 1.12);
    }, { passive: false });
    viewport.addEventListener('mousedown', e => {
      if (e.button !== 0 || (e.target.closest && e.target.closest('[data-person-card]'))) return;
      _drag = { x: e.clientX, y: e.clientY, left: viewport.scrollLeft, top: viewport.scrollTop };
      viewport.classList.add('dragging');
    });
    window.addEventListener('mousemove', e => {
      if (!_drag) return;
      viewport.scrollLeft = _drag.left - (e.clientX - _drag.x);
      viewport.scrollTop = _drag.top - (e.clientY - _drag.y);
    });
    window.addEventListener('mouseup', () => { _drag = null; viewport.classList.remove('dragging'); });
  }

  function showBuilder(data, preferredId) {
    _data = data || _data;
    if (!_data || !_data.persons || !_data.persons.length) {
      if (typeof ui !== 'undefined') ui.showAlert(tr('Сначала добавьте или импортируйте людей.', 'Add or import people first.'));
      return;
    }
    _indexes = buildIndexes(_data);
    const validPreferred = preferredId && _indexes.people.has(preferredId) ? preferredId : null;
    _builderSelectedId = validPreferred || (_selection && _indexes.people.has(_selection.centerId) ? _selection.centerId : null) || _data.persons[0].id;
    _builderLimit = _selection ? _selection.limit : 50;
    const search = document.getElementById('compact-person-search');
    if (search) search.value = '';
    const range = document.getElementById('compact-limit-range');
    const number = document.getElementById('compact-limit-number');
    if (range) range.value = _builderLimit;
    if (number) number.value = _builderLimit;
    localize();
    renderBuilderList('');
    updateBuilderSelected();
    if (typeof ui !== 'undefined') ui.openModal('modal-compact-builder');
  }

  function renderBuilderList(query) {
    const list = document.getElementById('compact-person-list');
    if (!list || !_data) return;
    const q = String(query || '').trim().toLowerCase();
    let persons = _data.persons.filter(p => {
      if (!q) return true;
      return [p.lastName, p.firstName, p.patronymic, p.maidenName, p.birthDate]
        .some(v => String(v || '').toLowerCase().includes(q));
    });
    persons = persons.slice().sort((a,b) => personSort(a.id,b.id,_indexes)).slice(0, 60);
    list.innerHTML = persons.map(p => {
      const name = dataModule.getFullName(p);
      const years = `${yearOnly(p.birthDate)} — ${dataModule.isAlive(p) && !p.deathDate ? tr('н. в.', 'present') : yearOnly(p.deathDate)}`;
      const selected = p.id === _builderSelectedId ? ' selected' : '';
      return `<button type="button" class="compact-person-option${selected}" data-pid="${esc(p.id)}"><span><strong>${esc(name)}</strong><small>${esc(years)}</small></span><span class="compact-option-check">${selected ? '✓' : ''}</span></button>`;
    }).join('') || `<div class="compact-no-results">${tr('Никого не найдено', 'No people found')}</div>`;
    list.querySelectorAll('[data-pid]').forEach(button => {
      button.addEventListener('click', () => {
        _builderSelectedId = button.getAttribute('data-pid');
        renderBuilderList(document.getElementById('compact-person-search').value);
        updateBuilderSelected();
      });
    });
  }

  function filterPersonSearch() {
    const input = document.getElementById('compact-person-search');
    renderBuilderList(input ? input.value : '');
  }

  function updateBuilderSelected() {
    const p = _indexes && _indexes.people.get(_builderSelectedId);
    const name = document.getElementById('compact-selected-name');
    if (name) name.textContent = p ? dataModule.getFullName(p) : tr('Не выбран', 'Not selected');
  }

  function syncLimit(source) {
    const range = document.getElementById('compact-limit-range');
    const number = document.getElementById('compact-limit-number');
    let value = source === 'number' ? parseInt(number && number.value, 10) : parseInt(range && range.value, 10);
    value = Math.max(10, Math.min(200, value || 50));
    _builderLimit = value;
    if (range) range.value = value;
    if (number) number.value = value;
  }

  function confirmBuild() {
    if (!_data || !_builderSelectedId) {
      if (typeof ui !== 'undefined') ui.showAlert(tr('Выберите человека.', 'Select a person.'));
      return false;
    }
    syncLimit('number');
    const result = buildSelection(_data, _builderSelectedId, _builderLimit);
    if (!result) return false;
    _selection = result;
    _renderToken = '';
    if (typeof ui !== 'undefined') ui.closeModal('modal-compact-builder');
    if (typeof app !== 'undefined') {
      app.selectedPersonId = result.centerId;
      app.setView('compact');
    } else {
      render(_data);
    }
    if (typeof ui !== 'undefined') {
      const message = result.requiredCount > result.limit
        ? tr(`Обязательный круг — ${result.requiredCount} чел.; мягкий лимит превышен без потери близких.`, `Required circle: ${result.requiredCount}; the soft limit was exceeded without hiding close relatives.`)
        : tr(`Схема готова: ${result.ids.length} человек вокруг выбранной персоны.`, `Scheme ready: ${result.ids.length} people around the selected person.`);
      ui.showToast(message);
    }
    return true;
  }

  function localize() {
    const isEn = typeof i18n !== 'undefined' && i18n.currentLang === 'en';
    document.querySelectorAll('[data-compact-ru]').forEach(el => {
      const value = isEn ? el.getAttribute('data-compact-en') : el.getAttribute('data-compact-ru');
      if (value != null) el.textContent = value;
    });
    const search = document.getElementById('compact-person-search');
    if (search) search.placeholder = tr('Фамилия, имя, отчество или год...', 'Last name, first name, patronymic or year...');
  }

  function safeFileBase() {
    if (!_selection || !_indexes) return 'family-circle';
    const p = _indexes.people.get(_selection.centerId);
    const raw = [p && p.lastName, p && p.firstName].filter(Boolean).join('-') || 'family-circle';
    return ('drevohod-' + raw).replace(/[\\/:*?"<>|\s]+/g, '-').replace(/-+/g, '-').slice(0, 80);
  }

  function downloadBlob(blob, filename) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1500);
  }

  function exportImage(format) {
    const svg = document.getElementById('compact-svg');
    if (!svg || !_layout) return;
    const mime = format === 'jpg' || format === 'jpeg' ? 'image/jpeg' : 'image/png';
    const ext = mime === 'image/jpeg' ? 'jpg' : 'png';
    const serialized = new XMLSerializer().serializeToString(svg);
    const blob = new Blob([serialized], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const img = new Image();
    img.onload = () => {
      const maxSide = 15000;
      const maxPixels = 80000000;
      const exportScale = Math.max(0.35, Math.min(2,
        maxSide / _layout.width,
        maxSide / _layout.height,
        Math.sqrt(maxPixels / (_layout.width * _layout.height))
      ));
      const canvas = document.createElement('canvas');
      canvas.width = Math.max(1, Math.round(_layout.width * exportScale));
      canvas.height = Math.max(1, Math.round(_layout.height * exportScale));
      const ctx = canvas.getContext('2d');
      ctx.fillStyle = '#f3f6fa';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      URL.revokeObjectURL(url);
      canvas.toBlob(out => {
        if (!out) {
          if (typeof ui !== 'undefined') ui.showAlert(tr('Не удалось создать изображение.', 'Could not create the image.'));
          return;
        }
        downloadBlob(out, safeFileBase() + '.' + ext);
        if (typeof ui !== 'undefined') ui.showToast(tr(`Схема сохранена в ${ext.toUpperCase()}`, `Scheme saved as ${ext.toUpperCase()}`));
      }, mime, mime === 'image/jpeg' ? 0.94 : undefined);
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      if (typeof ui !== 'undefined') ui.showAlert(tr('Браузер не смог подготовить изображение.', 'The browser could not prepare the image.'));
    };
    img.src = url;
  }

  function exportPDF() {
    if (!document.getElementById('compact-svg')) return;
    document.body.classList.add('compact-printing');
    const cleanup = () => document.body.classList.remove('compact-printing');
    window.addEventListener('afterprint', cleanup, { once: true });
    if (typeof ui !== 'undefined') ui.showToast(tr('В диалоге печати выберите «Сохранить как PDF»', 'Choose “Save as PDF” in the print dialog'));
    setTimeout(() => {
      window.print();
      // Some older browsers do not fire afterprint.
      setTimeout(cleanup, 1500);
    }, 180);
  }

  function clear() {
    _selection = null;
    _layout = null;
    _renderToken = '';
  }

  function getSelection() { return _selection; }

  return {
    showBuilder,
    filterPersonSearch,
    syncLimit,
    confirmBuild,
    render,
    hasSelection,
    getSelection,
    clear,
    zoomBy,
    zoomTo,
    fitToScreen,
    exportImage,
    exportPDF,
    localize,
    // Pure helpers exposed for automated regression tests.
    _test: { buildIndexes, buildSelection, computeLevels, createLayout, roleFor }
  };
})();

if (typeof window !== 'undefined') window.compactTree = compactTree;
