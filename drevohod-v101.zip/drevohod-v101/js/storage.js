// storage.js — Data persistence (localStorage for data, photo/ folder for photos)
// Drevohod v92 Arena Edition
//
// v92 CHANGE: photos are NO LONGER stored in IndexedDB. Instead:
//   - person.photo stores the FILENAME of the photo in the photo/ folder (e.g. "p_abc123.jpg")
//     or an empty string if no photo exists.
//   - The actual image file lives in the photo/ folder on disk (managed by filesystem.js).
//   - IndexedDB photo storage is kept only for backward compatibility (old data migration)
//     but is not used for new photos.
//
// This means:
//   - Photos are transparent files on disk (openable in any image viewer)
//   - Clearing browser cache does NOT delete photos
//   - localStorage stays light (only filename strings, not base64 image data)

const storage = {
  MAIN_KEY: 'drevokhod_data',            // legacy key (v99 и раньше) — используется для миграции
  TREE_KEY_PREFIX: 'drevokhod_tree_',    // v100: каждое древо хранится под своим ключом
  CURRENT_KEY: 'drevokhod_current',      // v100: указатель на ключ текущего древа
  RECENT_KEY: 'drevokhod_recent',
  THEME_KEY: 'drevokhod_theme',
  LANG_KEY: 'drevokhod_lang',

  // v100 (аудит #3): ключ localStorage для данного древа.
  // Раньше все записи в «Недавних» указывали на один ключ MAIN_KEY, поэтому
  // мультипроектность фактически не работала. Теперь каждое древо получает
  // уникальный id (meta.id) и хранится под собственным ключом.
  _treeKey(data) {
    if (!data.meta) data.meta = {};
    if (!data.meta.id) {
      data.meta.id = (typeof crypto !== 'undefined' && crypto.randomUUID)
        ? crypto.randomUUID().slice(0, 8)
        : Math.random().toString(36).slice(2, 10);
    }
    return this.TREE_KEY_PREFIX + data.meta.id;
  },

  // v92: IndexedDB is no longer used for photos, but we keep the connection
  // for backward compatibility (migrating old base64 photos to the new system).
  _db: null,
  _saveTimer: null,       // v73 #6: debounce localStorage.save
  _saveInFlight: false,  // v73 #6: prevent concurrent saves

  // v73 #18: handle IndexedDB versionchange — fires when another tab upgrades
  // the DB. We close our connection so the upgrade can proceed, and surface
  // the issue to the user via a callback (set by app.js).
  onVersionConflict: null,

  async initDB() {
    return new Promise((resolve) => {
      if (!window.indexedDB) { resolve(false); return; }
      const req = indexedDB.open('drevokhod_photos', 1);
      req.onupgradeneeded = (e) => {
        const db = e.target.result;
        if (!db.objectStoreNames.contains('photos')) {
          db.createObjectStore('photos', { keyPath: 'id' });
        }
      };
      req.onsuccess = (e) => {
        this._db = e.target.result;
        // v73 #18: if another tab tries to upgrade the DB, our connection blocks it.
        // Close our connection and notify the user.
        this._db.onversionchange = () => {
          this._db.close();
          this._db = null;
          if (typeof this.onVersionConflict === 'function') {
            this.onVersionConflict();
          }
        };
        resolve(true);
      };
      // v73 #18: handle blocked open (another tab holds the connection)
      req.onblocked = () => {
        console.warn('IndexedDB open blocked — close other tabs with this app');
        if (typeof this.onVersionConflict === 'function') {
          this.onVersionConflict();
        }
        resolve(false);
      };
      req.onerror = () => { resolve(false); };
    });
  },

  // v100 (аудит #5): восстановлен fallback на IndexedDB для фото.
  // Основное хранилище — папка photo/ (filesystem.js), но если File System
  // Access API недоступен (Firefox, Safari, file://), фото раньше МОЛЧА
  // пропадали. Теперь в этом случае фото сохраняются в IndexedDB, а
  // пользователь получает предупреждение (см. app.submitAddPerson).
  async savePhoto(id, dataUrl) {
    if (!this._db) return false;
    return new Promise((resolve) => {
      try {
        const tx = this._db.transaction('photos', 'readwrite');
        tx.objectStore('photos').put({ id, dataUrl });
        tx.oncomplete = () => resolve(true);
        tx.onerror = () => resolve(false);
      } catch (e) { resolve(false); }
    });
  },

  async loadPhoto(id) {
    if (!this._db) return null;
    return new Promise((resolve) => {
      try {
        const tx = this._db.transaction('photos', 'readonly');
        const req = tx.objectStore('photos').get(id);
        req.onsuccess = () => resolve(req.result ? req.result.dataUrl : null);
        req.onerror = () => resolve(null);
      } catch (e) { resolve(null); }
    });
  },

  async deletePhoto(id) {
    if (!this._db) return false;
    return new Promise((resolve) => {
      try {
        const tx = this._db.transaction('photos', 'readwrite');
        tx.objectStore('photos').delete(id);
        tx.oncomplete = () => resolve(true);
        tx.onerror = () => resolve(false);
      } catch (e) { resolve(false); }
    });
  },

  async getAllPhotoIds() {
    // v92: returns empty — no photos in IndexedDB anymore.
    return [];
  },

  async deleteOrphanPhotos(activeIds) {
    // v92: no-op — orphan photos are cleaned up by filesystem operations.
  },

  // ---- Main data (localStorage, no photos embedded) ----
  // v73 #6: synchronous save with quota handling. Returns { ok, error }
  // where error is 'quota' | 'serialize' | 'unknown'.
  save(data) {
    // v73 #6: prevent concurrent saves — if a save is in flight, queue this one
    if (this._saveInFlight) {
      // Debounce: schedule a single save after the current one finishes
      if (this._saveTimer) clearTimeout(this._saveTimer);
      this._saveTimer = setTimeout(() => {
        this._saveTimer = null;
        this.save(data);
      }, 200);
      return { ok: true, error: null, deferred: true };
    }
    this._saveInFlight = true;
    try {
      // v92: person.photo now stores the FILENAME (e.g. "p_abc123.jpg"), not base64 data.
      // So we no longer strip it — it's a short string that's fine to keep in localStorage.
      // The actual image file lives in the photo/ folder on disk.
      const stripped = {
        ...data,
        persons: data.persons.map(p => {
          // v92: if person.photo still contains old base64 data (from v91 or earlier),
          // strip it out — we only keep the filename now. The filename is stored in
          // person.photoFileName (from GEDCOM import) or derived from person.id.
          const cleaned = { ...p };
          // If photo looks like base64 data (starts with "data:"), clear it —
          // we don't store base64 in localStorage anymore.
          if (cleaned.photo && typeof cleaned.photo === 'string' && cleaned.photo.startsWith('data:')) {
            cleaned.photo = cleaned.photoFileName || '';  // fall back to filename
          }
          return cleaned;
        })
      };
      stripped.meta = stripped.meta || {};
      stripped.meta.modified = new Date().toISOString();
      const json = JSON.stringify(stripped);
      // v100 (аудит #3): сохраняем древо под уникальным ключом + указатель на него.
      const treeKey = this._treeKey(data);
      try {
        localStorage.setItem(treeKey, json);
        localStorage.setItem(this.CURRENT_KEY, treeKey);
        // v101 FIX Б17: removed MAIN_KEY write on every save — was doubling quota usage.
        // MAIN_KEY is only used for one-time migration in load().
      } catch (quotaErr) {
        // v73 #17: QuotaExceededError — notify caller so they can prompt user
        const isQuota = quotaErr && (quotaErr.name === 'QuotaExceededError' ||
                                     quotaErr.code === 22 ||
                                     quotaErr.code === 1014);
        console.error('localStorage quota exceeded:', quotaErr);
        this._saveInFlight = false;
        return { ok: false, error: isQuota ? 'quota' : 'unknown' };
      }

      // Update recent list (best-effort, ignore quota errors here)
      // v100 (аудит #3): в recent пишем УНИКАЛЬНЫЙ ключ древа, а не MAIN_KEY —
      // теперь каждый элемент списка «Недавние» ведёт на своё древо.
      try {
        let recent = this.loadRecent();
        const entry = {
          key: treeKey,
          name: data.meta?.name || 'Моё древо',
          count: data.persons.length,
          date: new Date().toISOString()
        };
        recent = recent.filter(r => r.key !== entry.key && r.key !== this.MAIN_KEY);
        recent.unshift(entry);
        recent = recent.slice(0, 5);
        localStorage.setItem(this.RECENT_KEY, JSON.stringify(recent));
      } catch (recentErr) {
        console.warn('Could not update recent list:', recentErr);
      }
      this._saveInFlight = false;
      return { ok: true, error: null };
    } catch (e) {
      console.error('Save error:', e);
      this._saveInFlight = false;
      return {
        ok: false,
        error: e.name === 'TypeError' ? 'serialize' : 'unknown'
      };
    }
  },

  // v73 #6: debounced save — coalesces multiple save() calls within 500ms
  // into a single localStorage write. Useful for auto-save + manual save race.
  saveDebounced(data, delay = 500) {
    if (this._saveTimer) clearTimeout(this._saveTimer);
    return new Promise((resolve) => {
      this._saveTimer = setTimeout(() => {
        this._saveTimer = null;
        const result = this.save(data);
        resolve(result);
      }, delay);
    });
  },

  load() {
    try {
      // v100 (аудит #3): сначала пробуем текущий уникальный ключ, затем legacy MAIN_KEY.
      const currentKey = localStorage.getItem(this.CURRENT_KEY);
      let saved = currentKey ? localStorage.getItem(currentKey) : null;
      if (!saved) saved = localStorage.getItem(this.MAIN_KEY);
      if (!saved) return null;
      const parsed = JSON.parse(saved);
      // v73 #19: use schema validation
      const validation = dataModule.validateData(parsed);
      if (!validation.valid) {
        console.warn('Data validation issues:', validation.errors);
        // Don't delete — try to recover with migrated data
        if (!parsed || !Array.isArray(parsed.persons) || !Array.isArray(parsed.links)) {
          localStorage.removeItem(this.MAIN_KEY);
          return null;
        }
      }
      return parsed;
    } catch (e) {
      console.warn('Load error:', e);
      return null;
    }
  },

  loadRecent() {
    try {
      return JSON.parse(localStorage.getItem(this.RECENT_KEY) || '[]');
    } catch { return []; }
  },

  saveTheme(theme) {
    try { localStorage.setItem(this.THEME_KEY, theme); }
    catch (e) { console.warn('Could not save theme:', e); }
  },

  loadTheme() {
    return localStorage.getItem(this.THEME_KEY) || 'light';
  },

  clear() {
    // v100: удаляем и legacy-ключ, и текущее древо
    const currentKey = localStorage.getItem(this.CURRENT_KEY);
    if (currentKey) localStorage.removeItem(currentKey);
    localStorage.removeItem(this.CURRENT_KEY);
    localStorage.removeItem(this.MAIN_KEY);
  },

  // ---- Export helpers ----
  exportJSON(data, filename) {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  },

  // v73 #20: encrypt data with password using Web Crypto API (AES-GCM).
  // Returns base64 string of encrypted payload (iv + ciphertext).
  async encryptWithPassword(data, password) {
    if (!window.crypto || !window.crypto.subtle) {
      throw new Error('Web Crypto API not available');
    }
    const enc = new TextEncoder();
    const iv = window.crypto.getRandomValues(new Uint8Array(12));
    // Derive key from password using PBKDF2
    const keyMaterial = await window.crypto.subtle.importKey(
      'raw', enc.encode(password), { name: 'PBKDF2' }, false, ['deriveKey']
    );
    const key = await window.crypto.subtle.deriveKey(
      { name: 'PBKDF2', salt: iv, iterations: 100000, hash: 'SHA-256' },
      keyMaterial,
      { name: 'AES-GCM', length: 256 },
      false,
      ['encrypt']
    );
    const ciphertext = await window.crypto.subtle.encrypt(
      { name: 'AES-GCM', iv },
      key,
      enc.encode(JSON.stringify(data))
    );
    // Combine iv + ciphertext into base64
    const combined = new Uint8Array(iv.length + ciphertext.byteLength);
    combined.set(iv, 0);
    combined.set(new Uint8Array(ciphertext), iv.length);
    return btoa(String.fromCharCode(...combined));
  },

  // v73 #20: decrypt data encrypted with encryptWithPassword
  async decryptWithPassword(encryptedBase64, password) {
    if (!window.crypto || !window.crypto.subtle) {
      throw new Error('Web Crypto API not available');
    }
    const combined = Uint8Array.from(atob(encryptedBase64), c => c.charCodeAt(0));
    const iv = combined.slice(0, 12);
    const ciphertext = combined.slice(12);
    const enc = new TextEncoder();
    const keyMaterial = await window.crypto.subtle.importKey(
      'raw', enc.encode(password), { name: 'PBKDF2' }, false, ['deriveKey']
    );
    const key = await window.crypto.subtle.deriveKey(
      { name: 'PBKDF2', salt: iv, iterations: 100000, hash: 'SHA-256' },
      keyMaterial,
      { name: 'AES-GCM', length: 256 },
      false,
      ['decrypt']
    );
    const plaintext = await window.crypto.subtle.decrypt(
      { name: 'AES-GCM', iv },
      key,
      ciphertext
    );
    return JSON.parse(new TextDecoder().decode(plaintext));
  },

  // v73 #20: export with optional password protection
  async exportJSONSecure(data, filename, password) {
    let payload;
    if (password) {
      const encrypted = await this.encryptWithPassword(data, password);
      payload = { encrypted: true, data: encrypted, app: 'drevokhod', version: 73 };
    } else {
      payload = data;
    }
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  },

  // v91: Generate GEDCOM string from data (without triggering download).
  // Used by exportGEDCOM (download) and _saveWorkGed (save to Work/ folder).
  generateGEDCOMString(data) {
    let ged = '0 HEAD\n1 SOUR Drevokhod\n2 VERS 9.1\n1 GEDC\n2 VERS 5.5.1\n1 CHAR UTF-8\n1 LANG Russian\n';
    // v88: collect picture records so we can emit them at the end
    const picRecords = {};  // picId → { id, name, fileName, path, primaryForIndiIds: [] }
    let picCounter = 0;
    // Map each person's photoFileName → a picId (so multiple people sharing the same
    // photo file share one PIC record, matching GenoPro convention).
    const fileNameToPicId = {};

    // v101 FIX Б16: escape @ in all user text to prevent spurious xref pointers
    const esc = s => (s || '').toString().replace(/@/g, '@@');

    data.persons.forEach(p => {
      ged += `0 @${p.id}@ INDI\n`;
      const nameParts = [p.firstName, p.patronymic].filter(Boolean).join(' ');
      const fullName = nameParts + (p.lastName ? ` /${p.lastName}/` : '');
      // v101: skip NAME line if all parts empty (invalid GEDCOM otherwise)
      if (fullName.trim() || p.lastName) {
        ged += `1 NAME ${esc(fullName.trim())}\n`;
      }
      if (p.firstName) ged += `2 GIVN ${esc(p.firstName)}\n`;
      if (p.lastName)  ged += `2 SURN ${esc(p.lastName)}\n`;
      if (p.patronymic) ged += `2 _PATR ${esc(p.patronymic)}\n`;
      if (p.maidenName) ged += `2 _MAID ${esc(p.maidenName)}\n`;
      // v101 FIX Б16: handle unknown gender as 'U' (GEDCOM 5.5.1)
      ged += `1 SEX ${p.gender === 'female' ? 'F' : p.gender === 'male' ? 'M' : 'U'}\n`;
      if (p.birthDate || p.birthPlace) {
        ged += `1 BIRT\n`;
        if (p.birthDate) ged += `2 DATE ${esc(p.birthDate)}\n`;
        if (p.birthDateApprox) ged += `2 _APPROX Y\n`;
        if (p.birthPlace) ged += `2 PLAC ${esc(p.birthPlace)}\n`;
      }
      if (p.status === 'deceased' || p.deathDate || p.deathPlace) {
        // v101 FIX Б16: no trailing space when status is not deceased
        ged += `1 DEAT${p.status === 'deceased' ? ' Y' : ''}\n`;
        if (p.deathDate) ged += `2 DATE ${esc(p.deathDate)}\n`;
        if (p.deathPlace) ged += `2 PLAC ${esc(p.deathPlace)}\n`;
      }
      // v101 FIX Б16: emit family field as custom tag
      if (p.family) ged += `2 _FAM ${esc(p.family)}\n`;
      if (p.bio) {
        // v101 FIX Б16: trim leading newlines in bio
        const trimmedBio = p.bio.replace(/^\n+/, '');
        if (trimmedBio) ged += `1 NOTE ${esc(trimmedBio).replace(/\n/g, '\n2 CONT ')}\n`;
      }

      // v88: emit PICTURES reference if person has photoFileName
      if (p.photoFileName && p.photoFileName.trim()) {
        let picId = fileNameToPicId[p.photoFileName];
        if (!picId) {
          picId = 'pic' + String(++picCounter).padStart(5, '0');
          fileNameToPicId[p.photoFileName] = picId;
          picRecords[picId] = {
            id: picId,
            name: p.photoFileName.trim(),
            fileName: p.photoFileName.trim().replace(/\s+/g, ''),
            path: p.photoFileName.trim()
          };
        }
        ged += `1 PICTURES @${picId}@\n`;
        ged += `2 PRIMARY @${picId}@\n`;
      }
    });

    // Families
    let famIdx = 1;
    const marriages = data.links.filter(l => l.type === 'marriage');
    marriages.forEach(m => {
      const famId = `F${famIdx++}`;
      const srcPerson = data.persons.find(p => p.id === m.source);
      const tgtPerson = data.persons.find(p => p.id === m.target);
      ged += `0 @${famId}@ FAM\n`;
      const husband = srcPerson?.gender === 'male' ? srcPerson : tgtPerson;
      const wife    = srcPerson?.gender === 'female' ? srcPerson : tgtPerson;
      if (husband) ged += `1 HUSB @${husband.id}@\n`;
      if (wife)    ged += `1 WIFE @${wife.id}@\n`;
      // Find children
      const parents = [m.source, m.target];
      const childLinks = data.links.filter(l => l.type === 'parent_child' && parents.includes(l.source));
      const childIds = [...new Set(childLinks.map(l => l.target))];
      childIds.forEach(cid => { ged += `1 CHIL @${cid}@\n`; });
    });

    // v88: emit Picture records (GenoPro format)
    Object.values(picRecords).forEach(pic => {
      ged += `0 @${pic.id}@ Picture\n`;
      ged += `1 PATH ${pic.path}\n`;
      ged += `2 RELATIVE ${pic.path}\n`;
      ged += `2 FILEUNIQUE ${pic.fileName}\n`;
      ged += `2 REPORT pictures/${pic.fileName}\n`;
      ged += `1 NAME ${pic.name}\n`;
    });

    ged += '0 TRLR\n';
    return ged;
  },

  exportGEDCOM(data) {
    const ged = this.generateGEDCOMString(data);
    const blob = new Blob([ged], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = (data.meta?.name || 'drevokhod') + '.ged';
    a.click();
    URL.revokeObjectURL(url);
  }
};
