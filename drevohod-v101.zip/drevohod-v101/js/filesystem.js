// filesystem.js — v89: File System Access API wrapper for Work/ and photo/ folders
// Provides persistent filesystem storage alongside IndexedDB.
// Falls back gracefully when API is unavailable (Firefox, Safari, file:// protocol).
//
// User flow:
//   1. App loads → init() tries to restore directory handle from IndexedDB
//   2. If no handle → status = 'available' (API exists, user must pick directory)
//   3. User clicks "Настроить папку программы" in Settings → pickDirectory()
//   4. User picks the Drevohod program directory (containing css/ and js/)
//   5. We create Work/ and photo/ subdirectories inside
//   6. status = 'connected' — all imports save to Work/, all photos save to photo/

const filesystem = {

  // ---- State ----
  _dirHandle: null,       // root directory handle (Drevohod program directory)
  _workDirHandle: null,   // Work/ subdirectory handle
  _photoDirHandle: null,  // photo/ subdirectory handle
  _initialized: false,
  _status: 'unknown',     // 'unknown' | 'unavailable' | 'available' | 'connected' | 'needs-permission'

  // Check if File System Access API is available.
  // Requires Chrome/Edge 86+ AND a secure context (https:// or http://localhost).
  // file:// protocol is NOT a secure context — API will be unavailable.
  isAvailable() {
    return typeof window !== 'undefined' &&
           'showDirectoryPicker' in window &&
           window.isSecureContext;
  },

  // Get current status (for UI display).
  getStatus() {
    return this._status;
  },

  // Check if filesystem is connected and ready for read/write.
  isConnected() {
    return this._status === 'connected' && this._dirHandle;
  },

  // ---- IndexedDB for handle persistence ----
  // We store the FileSystemDirectoryHandle in a separate IndexedDB database
  // so it survives page reloads. Handles are structured-cloneable.
  _openMetaDB() {
    return new Promise((resolve, reject) => {
      if (!window.indexedDB) { reject(new Error('IndexedDB not available')); return; }
      const req = indexedDB.open('drevokhod_fs_meta', 1);
      req.onupgradeneeded = (e) => {
        const db = e.target.result;
        if (!db.objectStoreNames.contains('meta')) {
          db.createObjectStore('meta', { keyPath: 'key' });
        }
      };
      req.onsuccess = (e) => resolve(e.target.result);
      req.onerror = (e) => reject(e.target.error);
    });
  },

  async _saveHandle(handle) {
    try {
      const db = await this._openMetaDB();
      return new Promise((resolve, reject) => {
        const tx = db.transaction('meta', 'readwrite');
        tx.objectStore('meta').put({ key: 'programDir', handle });
        tx.oncomplete = () => resolve();
        tx.onerror = () => reject(tx.error);
      });
    } catch (e) { console.warn('filesystem._saveHandle failed:', e); }
  },

  async _loadHandle() {
    try {
      const db = await this._openMetaDB();
      return new Promise((resolve, reject) => {
        const tx = db.transaction('meta', 'readonly');
        const req = tx.objectStore('meta').get('programDir');
        req.onsuccess = () => resolve(req.result ? req.result.handle : null);
        req.onerror = () => reject(req.error);
      });
    } catch (e) { console.warn('filesystem._loadHandle failed:', e); return null; }
  },

  async _clearHandle() {
    try {
      const db = await this._openMetaDB();
      return new Promise((resolve) => {
        const tx = db.transaction('meta', 'readwrite');
        tx.objectStore('meta').delete('programDir');
        tx.oncomplete = () => resolve();
        tx.onerror = () => resolve();
      });
    } catch (e) { console.warn('filesystem._clearHandle failed:', e); }
  },

  // ---- Initialization ----
  // Called on app startup. Restores handle if previously saved.
  // Does NOT prompt the user — that only happens via pickDirectory() (user gesture).
  async init() {
    if (this._initialized) return this._status;
    this._initialized = true;

    if (!this.isAvailable()) {
      this._status = 'unavailable';
      return this._status;
    }

    const handle = await this._loadHandle();
    if (!handle) {
      this._status = 'available';  // API exists but no directory picked yet
      return this._status;
    }

    // Check permission (may be 'granted', 'denied', or 'prompt')
    try {
      const perm = await handle.queryPermission({ mode: 'readwrite' });
      if (perm === 'granted') {
        this._dirHandle = handle;
        await this._ensureSubdirs();
        this._status = 'connected';
      } else if (perm === 'prompt') {
        // Can't request permission without a user gesture — wait for user action
        this._dirHandle = handle;
        this._status = 'needs-permission';
      } else {
        this._status = 'available';  // denied — user must re-pick
      }
    } catch (e) {
      console.warn('filesystem.init permission check failed:', e);
      this._status = 'available';
    }
    return this._status;
  },

  // Try to request permission (requires user gesture in most browsers).
  // Call this from a click handler.
  async requestPermission() {
    if (!this._dirHandle) return this._status;
    try {
      const perm = await this._dirHandle.requestPermission({ mode: 'readwrite' });
      if (perm === 'granted') {
        await this._ensureSubdirs();
        this._status = 'connected';
      }
    } catch (e) {
      console.warn('filesystem.requestPermission failed:', e);
    }
    return this._status;
  },

  // Pick the Drevohod program directory. Must be called from a user gesture (click).
  // After picking, creates Work/ and photo/ subdirectories.
  async pickDirectory() {
    if (!this.isAvailable()) {
      throw new Error('File System Access API недоступен. Используйте Chrome/Edge через http://localhost.');
    }
    try {
      const handle = await window.showDirectoryPicker();
      this._dirHandle = handle;
      await this._saveHandle(handle);
      await this._ensureSubdirs();
      this._status = 'connected';
      return this._status;
    } catch (e) {
      if (e.name === 'AbortError') {
        // User cancelled — don't change status
        return this._status;
      }
      throw e;
    }
  },

  // Create Work/ and photo/ subdirectories if they don't exist.
  async _ensureSubdirs() {
    if (!this._dirHandle) return;
    try {
      this._workDirHandle = await this._dirHandle.getDirectoryHandle('Work', { create: true });
    } catch (e) {
      console.warn('Failed to create/access Work/ directory:', e);
    }
    try {
      this._photoDirHandle = await this._dirHandle.getDirectoryHandle('photo', { create: true });
    } catch (e) {
      console.warn('Failed to create/access photo/ directory:', e);
    }
  },

  // Disconnect — clears the stored handle (user must re-pick next time).
  async disconnect() {
    await this._clearHandle();
    this._dirHandle = null;
    this._workDirHandle = null;
    this._photoDirHandle = null;
    this._status = this.isAvailable() ? 'available' : 'unavailable';
    return this._status;
  },

  // ---- Work/ folder: save imported files ----
  // Saves imported JSON/GED file content to Work/<filename>.
  // If filesystem not connected, does nothing (data is still in localStorage).
  async saveImportedFile(filename, content) {
    if (!this.isConnected() || !this._workDirHandle) return false;
    try {
      // Sanitize filename: remove path separators, keep it readable
      const safeName = filename.replace(/[/\\]/g, '_').replace(/\s+/g, ' ').trim();
      const fileHandle = await this._workDirHandle.getFileHandle(safeName, { create: true });
      const writable = await fileHandle.createWritable();
      await writable.write(content);
      await writable.close();
      return true;
    } catch (e) {
      console.warn('filesystem.saveImportedFile failed:', e);
      return false;
    }
  },

  // List files in Work/ folder (for UI display).
  async listImportedFiles() {
    if (!this.isConnected() || !this._workDirHandle) return [];
    try {
      const files = [];
      for await (const entry of this._workDirHandle.values()) {
        if (entry.kind === 'file') {
          files.push(entry.name);
        }
      }
      return files.sort();
    } catch (e) {
      console.warn('filesystem.listImportedFiles failed:', e);
      return [];
    }
  },

  // v91: Save content to Work/work.ged — the unified working file.
  // Called on every saveData(), auto-save, and after imports.
  async saveWorkGed(content) {
    if (!this.isConnected() || !this._workDirHandle) return false;
    try {
      const fileHandle = await this._workDirHandle.getFileHandle('work.ged', { create: true });
      const writable = await fileHandle.createWritable();
      await writable.write(content);
      await writable.close();
      return true;
    } catch (e) {
      console.warn('filesystem.saveWorkGed failed:', e);
      return false;
    }
  },

  // v100 (аудит #1): Основной рабочий файл теперь Work/work.json — JSON сохраняет
  // модель данных БЕЗ ПОТЕРЬ (полные даты, sibling-связи, bio, флаги approx),
  // в отличие от GEDCOM round-trip, который обрезал даты до года и прогонял
  // данные через агрессивную дедупликацию при каждой загрузке.
  // work.ged продолжает записываться параллельно — для совместимости и
  // просмотра в сторонних программах (GenoPro и др.).
  async saveWorkJson(content) {
    if (!this.isConnected() || !this._workDirHandle) return false;
    try {
      const fileHandle = await this._workDirHandle.getFileHandle('work.json', { create: true });
      const writable = await fileHandle.createWritable();
      await writable.write(content);
      await writable.close();
      return true;
    } catch (e) {
      console.warn('filesystem.saveWorkJson failed:', e);
      return false;
    }
  },

  // v100: Load Work/work.json content. Returns null if file doesn't exist.
  async loadWorkJson() {
    if (!this.isConnected() || !this._workDirHandle) return null;
    try {
      const fileHandle = await this._workDirHandle.getFileHandle('work.json');
      const file = await fileHandle.getFile();
      return await file.text();
    } catch (e) {
      // File doesn't exist yet — return null (normal for first run or upgrade from v99)
      return null;
    }
  },

  // v91: Load Work/work.ged content. Returns null if file doesn't exist.
  async loadWorkGed() {
    if (!this.isConnected() || !this._workDirHandle) return null;
    try {
      const fileHandle = await this._workDirHandle.getFileHandle('work.ged');
      const file = await fileHandle.getFile();
      return await file.text();
    } catch (e) {
      // File doesn't exist yet — return null (normal for first run)
      return null;
    }
  },

  // v91: Check if Work/work.ged exists.
  async workGedExists() {
    if (!this.isConnected() || !this._workDirHandle) return false;
    try {
      await this._workDirHandle.getFileHandle('work.ged');
      return true;
    } catch (e) {
      return false;
    }
  },

  // ---- photo/ folder: save/delete/check/load photos ----

  // Determine file extension from a data URL.
  _extensionFromDataUrl(dataUrl) {
    if (!dataUrl || !dataUrl.startsWith('data:')) return '.jpg';
    const m = dataUrl.match(/^data:image\/([a-zA-Z0-9]+);/);
    if (!m) return '.jpg';
    const sub = m[1].toLowerCase();
    if (sub === 'jpeg' || sub === 'jpg') return '.jpg';
    if (sub === 'png') return '.png';
    if (sub === 'gif') return '.gif';
    if (sub === 'webp') return '.webp';
    if (sub === 'bmp') return '.bmp';
    return '.' + sub;
  },

  // Save a photo to photo/ folder. Photo is named by personId for uniqueness.
  // dataUrl is the base64 data URL (e.g. "data:image/jpeg;base64,...").
  // v91 FIX: replaced unreliable fetch(dataUrl) with manual base64 → Uint8Array → Blob.
  // v92: returns the filename (e.g. "p_abc123.jpg") on success, so caller can store
  // it in person.photo as a reference (not the base64 data itself).
  async savePhoto(personId, dataUrl) {
    if (!this.isConnected() || !this._photoDirHandle) return null;
    try {
      const ext = this._extensionFromDataUrl(dataUrl);
      const filename = personId + ext;
      const fileHandle = await this._photoDirHandle.getFileHandle(filename, { create: true });
      const writable = await fileHandle.createWritable();

      // v91: manually decode base64 data URL to Uint8Array, then create Blob.
      const commaIdx = dataUrl.indexOf(',');
      if (commaIdx < 0) {
        await writable.close();
        return null;
      }
      const base64 = dataUrl.substring(commaIdx + 1);
      const byteString = atob(base64);
      const bytes = new Uint8Array(byteString.length);
      for (let i = 0; i < byteString.length; i++) {
        bytes[i] = byteString.charCodeAt(i);
      }
      const mimeMatch = dataUrl.match(/^data:([^;]+);/);
      const mimeType = mimeMatch ? mimeMatch[1] : 'image/jpeg';
      const blob = new Blob([bytes], { type: mimeType });

      await writable.write(blob);
      await writable.close();
      return filename;  // v92: return filename for person.photo reference
    } catch (e) {
      console.warn('filesystem.savePhoto failed:', e);
      return null;
    }
  },

  // v92: Get the photo filename for a person (without loading the file content).
  // Returns the filename (e.g. "p_abc123.jpg") if a photo file exists, or null.
  // This is used to set person.photo to the filename string (not base64 data).
  async getPhotoFilename(personId) {
    if (!this.isConnected() || !this._photoDirHandle) return null;
    const filename = await this.photoExists(personId);
    return filename;  // returns filename string or false
  },

  // Delete a photo from photo/ folder by personId.
  // We don't know the extension, so we try common ones.
  async deletePhoto(personId) {
    if (!this.isConnected() || !this._photoDirHandle) return false;
    const extensions = ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp'];
    let deleted = false;
    for (const ext of extensions) {
      try {
        await this._photoDirHandle.removeEntry(personId + ext);
        deleted = true;
      } catch (e) {
        // File doesn't exist with this extension — try next
      }
    }
    return deleted;
  },

  // Check if a photo exists for the given personId.
  async photoExists(personId) {
    if (!this.isConnected() || !this._photoDirHandle) return null;  // null = can't check
    const extensions = ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp'];
    for (const ext of extensions) {
      try {
        const handle = await this._photoDirHandle.getFileHandle(personId + ext);
        if (handle) return personId + ext;  // return filename if exists
      } catch (e) {
        // Not found with this extension
      }
    }
    return false;  // explicitly doesn't exist
  },

  // Load a photo as a data URL. Returns null if not found.
  async loadPhoto(personId) {
    if (!this.isConnected() || !this._photoDirHandle) return null;
    const filename = await this.photoExists(personId);
    if (!filename) return null;
    try {
      const fileHandle = await this._photoDirHandle.getFileHandle(filename);
      const file = await fileHandle.getFile();
      return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });
    } catch (e) {
      console.warn('filesystem.loadPhoto failed:', e);
      return null;
    }
  },

  // List all photo filenames in photo/ folder.
  // Returns array of { personId, filename }.
  async listPhotos() {
    if (!this.isConnected() || !this._photoDirHandle) return [];
    try {
      const photos = [];
      for await (const entry of this._photoDirHandle.values()) {
        if (entry.kind === 'file') {
          // Extract personId from filename (strip extension)
          const name = entry.name;
          const dotIdx = name.lastIndexOf('.');
          const personId = dotIdx > 0 ? name.substring(0, dotIdx) : name;
          photos.push({ personId, filename: name });
        }
      }
      return photos;
    } catch (e) {
      console.warn('filesystem.listPhotos failed:', e);
      return [];
    }
  },

  // v92: In-memory cache of photo data URLs, keyed by personId.
  // Populated on-demand by getCachedPhotoDataUrl() and invalidated on save/delete.
  _photoCache: new Map(),

  // v92: Get photo data URL for rendering, with caching.
  // Returns data URL string if photo exists in cache or photo/ folder, null otherwise.
  // This is the main method called by render code to display photos.
  async getCachedPhotoDataUrl(personId) {
    if (!personId) return null;
    // Check cache first
    if (this._photoCache.has(personId)) {
      return this._photoCache.get(personId);
    }
    // Load from photo/ folder
    if (this.isConnected()) {
      const dataUrl = await this.loadPhoto(personId);
      if (dataUrl) {
        // Cache for subsequent renders
        this._photoCache.set(personId, dataUrl);
        return dataUrl;
      }
    } else if (typeof storage !== 'undefined' && storage.loadPhoto) {
      // v100 (аудит #5): fallback на IndexedDB, когда File System Access API
      // недоступен (Firefox, Safari, file://) — фото больше не пропадают.
      const dataUrl = await storage.loadPhoto(personId);
      if (dataUrl) {
        this._photoCache.set(personId, dataUrl);
        return dataUrl;
      }
    }
    return null;
  },

  // v92: Invalidate cache for a person (called after save/delete).
  invalidatePhotoCache(personId) {
    if (personId) {
      this._photoCache.delete(personId);
    } else {
      this._photoCache.clear();
    }
  },

  // v92: Synchronous check — returns cached data URL if available, null otherwise.
  // Used by render code for fast initial render. If null, the caller should
  // call getCachedPhotoDataUrl() async and re-render.
  getCachedPhotoDataUrlSync(personId) {
    if (!personId) return null;
    return this._photoCache.has(personId) ? this._photoCache.get(personId) : null;
  },
};

if (typeof window !== 'undefined') {
  window.filesystem = filesystem;
}
