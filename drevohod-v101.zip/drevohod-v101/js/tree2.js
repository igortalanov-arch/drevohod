// tree2.js — Tree v2.0 (Tidy Layered Tree + Lazy Rendering) for Drevohod v4.9
//
// v4.9 rewrite — addresses v4.8 issues:
//   • CARDS OVERLAPPING: radial layout cannot fit 150×50 cards for 500+ people
//     without overlap. Switched to TOP-DOWN TIDY TREE layout (Reingold-Tilford
//     style) where every subtree reserves enough horizontal space — cards
//     NEVER overlap by design.
//   • SLOW RENDERING: every redraw iterated all 524 nodes + 2598 links.
//     Added viewport culling (only visible cards are drawn) + cached lookup
//     tables (nodesById, childrenByParent, marriagesByPerson).
//   • CHILDREN DON'T EXPAND: layout was static. Now layout is recomputed
//     when folders expand/collapse so newly-shown children get proper space.
//   • CLICK LAG: every UI action triggered full _draw() with all work.
//     Now uses throttled requestAnimationFrame + dirty flags.
//
// Layout design:
//   • Each connected component = one tidy-tree block, stacked vertically
//   • Root at top, generations go DOWN
//   • Children spread horizontally under their parent
//   • Subtree width = max(ownCardWidth, sum of children widths)
//   • Card size: 150×50px (working), 70×24 (structural), 4×4 dot (satellite)
//   • Generation gap: 90px; Sibling gap: 20px
//
// Performance design:
//   • Cached maps: _nodesById, _childrenByParent, _parentsByChild, _marriagesByPerson
//   • Viewport culling: only draw nodes/links within visible world rect
//   • Dirty flags: _layoutDirty, _visibilityDirty — recompute only when needed
//   • Throttled redraw: requestAnimationFrame coalescing
//
// All public API names preserved so app.js keeps working unchanged.

const tree2 = (function () {
  'use strict';

  // ---------- State ----------
  let _data = null;
  let _familyColors = {};
  let _persons = [];
  let _personsById = new Map();  // v73 #4: O(1) lookup by id (replaces _persons.find in loops)
  let _nodes = [];         // {id, person, gen, x, y, isFolder, childCount, visible, isSpouse, partnerId, component, isRoot, subtreeWidth}
  let _marriages = [];     // {a, b, divorced}
  let _siblingGroups = []; // {parentIds:[], childIds:[]}
  let _branches = [];      // [{id, name, color, count}]
  let _rootIds = [];       // multi-root: one per connected component
  let _components = [];    // [{rootId, members:Set, size, headerY, blockHeight}]

  // Cached lookup tables (rebuilt on setData)
  let _nodesById = new Map();
  let _childrenByParent = new Map();
  let _parentsByChild = new Map();
  let _marriagesByPerson = new Map();
  let _visibleNodesCache = null;
  let _visibleLinksCache = null;

  let _canvas, _ctx, _mmCanvas, _mmCtx;
  let _wrap, _sidebar;
  let _dpr = 1;

  // View transform
  let _scale = 1.0;
  let _targetScale = 1.0;
  let _offsetX = 0;
  let _offsetY = 0;
  let _targetOffsetX = 0;
  let _targetOffsetY = 0;

  // Interaction
  let _isPanning = false;
  let _isMinimapDrag = false;
  let _lastMouseX = 0, _lastMouseY = 0;
  let _hoveredNode = null;
  let _selectedNodeId = null;
  let _focusPersonId = null;
  let _focusMode = null;       // 'descendants' | 'ancestors' | null

  // highlight set for the "click card → highlight parents/children/grandchildren" feature.
  // _highlightSet = Set of node IDs that should be drawn highlighted (others dimmed).
  // _highlightedLinks = list of {kind, source, target} links to draw with thick accent color.
  let _highlightSet = null;
  let _highlightedLinks = null;
  let _directConnectionSet = null;  // v80 #2: directly-connected nodes for filter borders

  // Settings
  let _depthLimit = 10;
  let _showSpouses = true;
  let _autoCollapse = true;
  let _aliveOnly = false;
  let _deceasedOnly = false;  // v71: filter "deceased only" (Ушедшие)
  let _hideDivorced = false;
  let _viewMode = 'full';      // 'full' | 'folder' | 'descendants'
  let _expandedFolders = new Set();
  let _expandedFolderId = null;
  // tree orientation — 'down' (oldest at top) or 'up' (oldest at bottom)
  let _treeOrientation = 'down';
  let _hiddenBranches = new Set();

  // Dirty flags (avoid recomputing on every frame)
  let _layoutDirty = true;
  let _visibilityDirty = true;
  let _genRemapInfo = null;  // debug info for genRemap
  let _redrawScheduled = false;
  let _lastHoverTime = 0;  // v73 #5: throttle _handleHover

  // Layout cache
  let _layoutBounds = { minX: 0, minY: 0, maxX: 0, maxY: 0, width: 0, height: 0 };

  // Constants
  const MIN_SCALE = 0.05;
  const MAX_SCALE = 4.0;
  // Circle-based layout constants
  const CIRCLE_R = 22;          // circle radius (base)
  const CIRCLE_GAP = 8;         // gap between circles
  const CARD_W = CIRCLE_R * 2 + CIRCLE_GAP;  // for backward compat (layout spacing)
  const CARD_H = CIRCLE_R * 2 + CIRCLE_GAP;
  const CARD_W_STRUCT = 70;  // v73 #27: structural zoom level card width
  const CARD_H_STRUCT = 24;  // v73 #27: structural zoom level card height
  const GEN_GAP = 90;
  const SIBLING_GAP = 20;
  const COMPONENT_GAP = 80;
  // Dynamic layout params
  let _effectiveCardW = CARD_W;
  let _effectiveCardH = CARD_H;
  let _effectiveGenGap = GEN_GAP;
  let _effectiveSiblingGap = SIBLING_GAP;
  let _effectiveCircleR = CIRCLE_R;  // actual circle radius used in layout
  const FOLDER_THRESHOLD = 3;

  // ============================================================
  // THEME
  // ============================================================
  function readTheme() {
    const cs = getComputedStyle(document.body);
    const get = (name) => cs.getPropertyValue(name).trim();
    return {
      bgPrimary:    get('--bg-primary')    || '#f5f7fa',
      bgCard:       get('--bg-card')       || '#ffffff',
      bgInput:      get('--bg-input')      || '#f0f3f8',
      bgSecondary:  get('--bg-secondary')  || '#eef2f8',
      textPrimary:  get('--text-primary')  || '#1a1a2e',
      textSecondary:get('--text-secondary')|| '#4a5568',
      textMuted:    get('--text-muted')    || '#718096',
      borderColor:  get('--border-color')  || '#dde2ea',
      accent:       get('--accent')        || '#3b7dd8',
      male:         get('--male-color')    || '#3b7dd8',
      female:       get('--female-color')  || '#d63384',
      success:      get('--success')       || '#28a745',
      danger:       get('--danger')        || '#dc3545',
      warning:      get('--warning')       || '#e67e22',
      connParent:   get('--conn-parent')   || '#3b7dd8',
      connMarriage: get('--conn-marriage') || '#d63384',
      isDark:       (document.body.getAttribute('data-theme') || 'light') === 'dark',
    };
  }

  function hexToRgba(hex, alpha) {
    if (!hex) return `rgba(0,0,0,${alpha})`;
    if (hex.startsWith('rgba') || hex.startsWith('rgb')) return hex;
    let h = hex.replace('#', '');
    if (h.length === 3) h = h.split('').map(c => c + c).join('');
    const r = parseInt(h.slice(0, 2), 16);
    const g = parseInt(h.slice(2, 4), 16);
    const b = parseInt(h.slice(4, 6), 16);
    return `rgba(${r},${g},${b},${alpha})`;
  }

  // ============================================================
  // DATA — build graph + connected components + cached lookups
  // ============================================================
  function setData(data, familyColors) {
    _data = data;
    _familyColors = familyColors || {};
    if (!_data || !_data.persons) return;
    _persons = _data.persons.slice();
    // v73 #4: build O(1) lookup map — replaces _persons.find() in hot loops
    _personsById = new Map();
    _persons.forEach(p => _personsById.set(p.id, p));
    _buildGraph();
    _buildBranches();
    // v74 #1: always default to "full tree" view mode (user request).
    // Previously: trees with 200+ people auto-switched to "folder" mode.
    // Now: always start in "full" mode — user can switch to "folder" if needed.
    _viewMode = 'full';
    _layoutDirty = true;
    _visibilityDirty = true;
    _computeLayout();
    _populateSidebar();
  }

  function _buildGraph() {
    const links = _data.links || [];
    const personsById = {};
    _persons.forEach(p => { personsById[p.id] = p; });

    // Marriages
    _marriages = [];
    const marriageSeen = new Set();
    _marriagesByPerson = new Map();
    links.forEach(l => {
      if (l.type === 'marriage' && personsById[l.source] && personsById[l.target]) {
        const key = [l.source, l.target].sort().join('|');
        if (marriageSeen.has(key)) return;
        marriageSeen.add(key);
        const m = { a: l.source, b: l.target, divorced: !!l.divorced };
        _marriages.push(m);
        if (!_marriagesByPerson.has(l.source)) _marriagesByPerson.set(l.source, []);
        _marriagesByPerson.get(l.source).push(m);
        if (!_marriagesByPerson.has(l.target)) _marriagesByPerson.set(l.target, []);
        _marriagesByPerson.get(l.target).push(m);
      }
    });

    // Cached parent/child maps (skip self-loops defensively)
    _childrenByParent = new Map();
    _parentsByChild = new Map();
    links.forEach(l => {
      if (l.type !== 'parent_child') return;
      if (l.source === l.target) return;
      if (!_childrenByParent.has(l.source)) _childrenByParent.set(l.source, []);
      _childrenByParent.get(l.source).push(l.target);
      if (!_parentsByChild.has(l.target)) _parentsByChild.set(l.target, []);
      _parentsByChild.get(l.target).push(l.source);
    });

    // ---- Connected components (treating both parent_child AND marriage as edges) ----
    const adj = {};
    _persons.forEach(p => { adj[p.id] = []; });
    links.forEach(l => {
      if (l.source === l.target) return;
      if (!personsById[l.source] || !personsById[l.target]) return;
      adj[l.source].push(l.target);
      adj[l.target].push(l.source);
    });

    const visited = new Set();
    _components = [];
    _persons.forEach(p => {
      if (visited.has(p.id)) return;
      const members = new Set();
      const queue = [p.id];
      while (queue.length) {
        const id = queue.shift();
        if (members.has(id)) continue;
        members.add(id);
        visited.add(id);
        (adj[id] || []).forEach(n => { if (!members.has(n)) queue.push(n); });
      }
      const memberList = Array.from(members);
      const hasParent = new Set();
      links.forEach(l => {
        if (l.type !== 'parent_child') return;
        if (l.source === l.target) return;
        if (members.has(l.target)) hasParent.add(l.target);
      });
      const noParents = memberList.filter(id => !hasParent.has(id));
      const candidates = noParents.length > 0 ? noParents : memberList;
      candidates.sort((a, b) => {
        const pa = personsById[a], pb = personsById[b];
        const ya = dataModule.getBirthYear(pa) || 9999;
        const yb = dataModule.getBirthYear(pb) || 9999;
        return ya - yb;
      });
      const rootId = candidates[0];
      _components.push({
        rootId,
        members,
        size: members.size,
        headerY: 0,
        blockHeight: 0,
      });
    });

    _components.sort((a, b) => b.size - a.size);
    _rootIds = _components.map(c => c.rootId);

    // Sibling groups
    _siblingGroups = [];
    const childrenByParents = new Map();
    links.forEach(l => {
      if (l.type !== 'parent_child') return;
      const childId = l.target;
      const parents = (links)
        .filter(ll => ll.type === 'parent_child' && ll.target === childId && ll.source !== childId)
        .map(ll => ll.source)
        .sort();
      if (parents.length === 0) return;
      const key = parents.join('|');
      if (!childrenByParents.has(key)) {
        childrenByParents.set(key, { parentIds: parents, childIds: new Set() });
      }
      childrenByParents.get(key).childIds.add(childId);
    });
    childrenByParents.forEach(g => {
      _siblingGroups.push({ parentIds: g.parentIds, childIds: Array.from(g.childIds) });
    });
  }

  function _buildBranches() {
    _branches = [];
    const counts = {};
    _persons.forEach(p => {
      const fam = p.family || '—';
      if (!counts[fam]) counts[fam] = 0;
      counts[fam]++;
    });
    Object.keys(counts).forEach((name, i) => {
      _branches.push({
        id: String(i),
        name: name,
        color: _familyColors[name] || dataModule.defaultColors[i % dataModule.defaultColors.length],
        count: counts[name],
      });
    });
    if (_branches.length === 0) {
      _branches.push({ id: '0', name: '—', color: dataModule.defaultColors[0], count: _persons.length });
    }
  }




  // ============================================================
  // LAYOUT — v5.9 Generation-Layered Layout (NO OVERLAP, PARENTS ALWAYS ABOVE)
  // ============================================================
  // Algorithm:
  //   1. Compute generation for each person (root=0, child=parent+1)

  // ============================================================
  // LAYOUT — v6.1 Tidy-Tree "Ёлка" (children centered under parents)
  // ============================================================
  // Algorithm:
  //   1. Compute generation per person (root=0, child=parent+1)
  //   2. Post-order: compute subtree width = max(circleSpacing, sum of children widths)
  //   3. Pre-order: assign X positions — children centered under parent
  //   4. Y = generation × rowHeight (parents always above children)
  //   5. Spouses placed next to partner (same Y)
  //   6. Horizontal stagger: odd generations shifted by half a circle
  //   7. Collision detection: shift right if cell occupied
  //
  // The tree looks like a Christmas tree (ёлка): top = oldest ancestor,
  // branches spreading down and out, children under parents.
  function _computeLayout() {
    if (!_data || _persons.length === 0) {
      _nodes = [];
      _nodesById = new Map();
      _layoutBounds = { minX: 0, minY: 0, maxX: 0, maxY: 0, width: 0, height: 0 };
      _layoutDirty = false;
      _visibilityDirty = true;
      return;
    }

    // Larger spacing for better readability
    const n = _persons.length;
    const scale = n > 400 ? 0.80 : (n > 200 ? 0.90 : 1.0);
    const circleR = Math.round(CIRCLE_R * scale);
    // Increased gaps — horizontal and vertical
    const hGap = circleR * 2 + CIRCLE_GAP + 12;  // horizontal gap between circles
    const vGap = circleR * 2 + CIRCLE_GAP + 60;  // 3x vertical gap between rows
    const rowHeight = vGap;
    const colWidth = hGap;

    _effectiveCardW = colWidth;
    _effectiveCardH = rowHeight;
    _effectiveGenGap = rowHeight;
    _effectiveSiblingGap = hGap;
    _effectiveCircleR = circleR;

    _nodes = [];
    _nodesById = new Map();

    // v70: GENERATION COMPUTATION — cycle-break + cluster BFS + safe sync.
    //
    // HARD REQUIREMENTS (user request v70):
    //   1. Every child's generation MUST be strictly greater than each of its
    //      parents' generations. No exceptions.
    //   2. Spouses MUST be on the same generation IF their birth-year difference
    //      is ≤ 10 years OR one/both birth years are unknown.
    //
    // These two requirements can conflict in cyclic data. Priority: child > parent
    // is HARD requirement, spouse sync is "best-effort" (sync only if it doesn't
    // violate child rule).
    //
    // Algorithm:
    //   1. Build parent_child maps (skip invalid: parent < 12 yrs older than child)
    //   2. BREAK CYCLES via DFS
    //   3. Build marriage clusters via union-find (spouses with shouldSync=true)
    //   4. BFS over clusters using parent_child links (cluster gen = max parent cluster + 1)
    //   5. Iterate enforceChildrenRule + syncSpousesSafe until fixpoint:
    //      - enforce raises child.gen to parent.gen + 1 (capped)
    //      - syncSpousesSafe raises lower spouse to higher spouse's gen, but
    //        ONLY if no child of the lower spouse would be left at gen ≤ new parent gen
    //   6. HARD_CAP = maxClusterGen + 5 (prevents runaway)

    function isValidParent(parentId, childId) {
      const parent = _personsById.get(parentId);
      const child = _personsById.get(childId);
      if (!parent || !child) return false;
      const py = dataModule.getBirthYear(parent);
      const cy = dataModule.getBirthYear(child);
      if (py == null || cy == null) return true;
      return py + 12 <= cy;
    }

    // Build valid parent→children and child→parents maps
    const validChildrenByParent = new Map();
    const validParentsByChild = new Map();
    (_data.links || []).forEach(l => {
      if (l.type !== 'parent_child' || l.source === l.target) return;
      if (!isValidParent(l.source, l.target)) return;
      if (!validChildrenByParent.has(l.source)) validChildrenByParent.set(l.source, []);
      validChildrenByParent.get(l.source).push(l.target);
      if (!validParentsByChild.has(l.target)) validParentsByChild.set(l.target, []);
      validParentsByChild.get(l.target).push(l.source);
    });

    // ---- v70: BREAK CYCLES via DFS ----
    const onPath = new Set();
    const cycleBrokenLinks = new Set();
    function breakCyclesDFS(nodeId) {
      if (onPath.has(nodeId)) return;
      onPath.add(nodeId);
      const children = validChildrenByParent.get(nodeId) || [];
      children.forEach(cid => {
        if (onPath.has(cid)) cycleBrokenLinks.add(nodeId + '|' + cid);
        else breakCyclesDFS(cid);
      });
      onPath.delete(nodeId);
    }
    _persons.forEach(p => { if (!validParentsByChild.has(p.id)) breakCyclesDFS(p.id); });
    _persons.forEach(p => { if (!onPath.has(p.id)) breakCyclesDFS(p.id); });
    cycleBrokenLinks.forEach(key => {
      const [parentId, childId] = key.split('|');
      const kids = validChildrenByParent.get(parentId);
      if (kids) {
        const idx = kids.indexOf(childId);
        if (idx >= 0) kids.splice(idx, 1);
        if (kids.length === 0) validChildrenByParent.delete(parentId);
      }
      const parents = validParentsByChild.get(childId);
      if (parents) {
        const idx = parents.indexOf(parentId);
        if (idx >= 0) parents.splice(idx, 1);
        if (parents.length === 0) validParentsByChild.delete(childId);
      }
    });

    // ---- v70: Build marriage links + shouldSyncSpouses ----
    const marriageLinks = (_data.links || []).filter(l => l.type === 'marriage').filter(m => {
      const aChildrenB = (validChildrenByParent.get(m.source) || []).includes(m.target);
      const bChildrenA = (validChildrenByParent.get(m.target) || []).includes(m.source);
      return !(aChildrenB || bChildrenA);
    });
    function shouldSyncSpouses(p1, p2) {
      const y1 = dataModule.getBirthYear(p1);
      const y2 = dataModule.getBirthYear(p2);
      if (y1 == null || y2 == null) return true;  // one or both unknown
      return Math.abs(y1 - y2) <= 10;
    }

    // ---- v70: Build marriage clusters via union-find ----
    const parent_uf = new Map();
    function ufFind(x) {
      if (!parent_uf.has(x)) parent_uf.set(x, x);
      while (parent_uf.get(x) !== x) {
        parent_uf.set(x, parent_uf.get(parent_uf.get(x)));
        x = parent_uf.get(x);
      }
      return x;
    }
    function ufUnion(a, b) {
      const ra = ufFind(a), rb = ufFind(b);
      if (ra !== rb) parent_uf.set(ra, rb);
    }
    marriageLinks.forEach(m => {
      const p1 = _personsById.get(m.source);
      const p2 = _personsById.get(m.target);
      if (!p1 || !p2) return;
      if (shouldSyncSpouses(p1, p2)) ufUnion(m.source, m.target);
    });

    // ---- v70: Build cluster-level parent_child graph ----
    const clusterChildren = new Map();
    const clusterMembers = new Map();
    _persons.forEach(p => {
      const cr = ufFind(p.id);
      if (!clusterMembers.has(cr)) clusterMembers.set(cr, new Set());
      clusterMembers.get(cr).add(p.id);
    });
    validChildrenByParent.forEach((kids, parentId) => {
      const pCluster = ufFind(parentId);
      if (!clusterChildren.has(pCluster)) clusterChildren.set(pCluster, new Set());
      kids.forEach(cid => {
        const cCluster = ufFind(cid);
        if (cCluster !== pCluster) clusterChildren.get(pCluster).add(cCluster);
      });
    });
    const clusterParents = new Map();
    clusterChildren.forEach((kidsSet, pCluster) => {
      kidsSet.forEach(cCluster => {
        if (!clusterParents.has(cCluster)) clusterParents.set(cCluster, new Set());
        clusterParents.get(cCluster).add(pCluster);
      });
    });

    // ---- v70: BFS over clusters (relaxed) ----
    const clusterGenCache = new Map();
    const clusterRoots = [];
    clusterMembers.forEach((_, cr) => {
      const ps = clusterParents.get(cr);
      if (!ps || ps.size === 0) {
        clusterRoots.push(cr);
        clusterGenCache.set(cr, 0);
      }
    });
    const cQueue = [...clusterRoots];
    const cVisited = new Set(clusterRoots);
    let cIter = 0;
    let cLastChange = 0;
    while (cQueue.length > 0 && cIter - cLastChange < clusterMembers.size * 3) {
      cIter++;
      const cr = cQueue.shift();
      const kids = clusterChildren.get(cr) || [];
      kids.forEach(kCluster => {
        if (cVisited.has(kCluster)) return;
        const allPClusters = Array.from(clusterParents.get(kCluster) || []);
        // v70: relaxed — at least ONE parent must be visited
        const visitedParents = allPClusters.filter(pc => clusterGenCache.has(pc));
        if (visitedParents.length === 0) return;
        const maxParentGen = Math.max(...visitedParents.map(pc => clusterGenCache.get(pc)));
        clusterGenCache.set(kCluster, maxParentGen + 1);
        cVisited.add(kCluster);
        cQueue.push(kCluster);
        cLastChange = cIter;
      });
    }
    clusterMembers.forEach((_, cr) => {
      if (!clusterGenCache.has(cr)) clusterGenCache.set(cr, 0);
    });

    let maxClusterGen = 0;
    clusterGenCache.forEach(v => { if (v > maxClusterGen) maxClusterGen = v; });

    // Map cluster gen to persons
    const genCache = new Map();
    _persons.forEach(p => {
      const cr = ufFind(p.id);
      genCache.set(p.id, clusterGenCache.get(cr) || 0);
    });

    // ---- v70: Iterated enforce + safe sync ----
    const HARD_CAP = maxClusterGen + 5;

    function enforceChildrenRuleCapped() {
      validParentsByChild.forEach((parents, childId) => {
        const parentGens = parents.map(pid => Math.min(genCache.get(pid) || 0, HARD_CAP));
        const maxParentGen = Math.max(...parentGens);
        let expectedChildGen = maxParentGen + 1;
        if (expectedChildGen > HARD_CAP) expectedChildGen = HARD_CAP;
        if (expectedChildGen > (genCache.get(childId) || 0)) {
          genCache.set(childId, expectedChildGen);
        }
      });
    }
    function syncSpousesSafe() {
      marriageLinks.forEach(m => {
        const p1 = _personsById.get(m.source);
        const p2 = _personsById.get(m.target);
        if (!p1 || !p2) return;
        if (!shouldSyncSpouses(p1, p2)) return;
        let g1 = Math.min(genCache.get(m.source) || 0, HARD_CAP);
        let g2 = Math.min(genCache.get(m.target) || 0, HARD_CAP);
        if (g1 === g2) return;
        const higherId = g1 > g2 ? m.source : m.target;
        const lowerId = g1 > g2 ? m.target : m.source;
        const higherGen = Math.max(g1, g2);
        // Only raise lower to higherGen if all lower's children are > higherGen
        const lowerChildren = validChildrenByParent.get(lowerId) || [];
        const canRaise = lowerChildren.every(cid => (genCache.get(cid) || 0) > higherGen);
        if (!canRaise) return;
        genCache.set(lowerId, higherGen);
      });
    }

    const MAX_ITER = 50;
    let iter = 0;
    let changed = true;
    while (changed && iter < MAX_ITER) {
      changed = false;
      iter++;
      const beforeSnapshot = new Map();
      genCache.forEach((v, k) => beforeSnapshot.set(k, v));
      enforceChildrenRuleCapped();
      syncSpousesSafe();
      genCache.forEach((v, k) => {
        if (beforeSnapshot.get(k) !== v) changed = true;
      });
    }

    const allGens = Array.from(new Set(genCache.values()));
    const maxGen = allGens.length > 0 ? Math.max(...allGens) : 0;

    // ---- Per-component tidy-tree layout ----
    let cursorY = 0;
    let maxAbsX = 0, minAbsX = 0;

    _components.forEach((comp, compIdx) => {
      comp.headerY = cursorY;
      cursorY += 40;

      function isCollapsedFolder(pid) {
        const kids = _childrenByParent.get(pid) || [];
        const childCount = kids.filter(k => comp.members.has(k)).length;
        if (childCount <= FOLDER_THRESHOLD) return false;
        if (_viewMode === 'folder' && !_expandedFolders.has(pid)) return true;
        if (_autoCollapse && _viewMode !== 'folder' && !_expandedFolders.has(pid)) return true;
        return false;
      }

      function getVisibleChildren(pid) {
        if (isCollapsedFolder(pid)) return [];
        const kids = (_childrenByParent.get(pid) || []).filter(k => comp.members.has(k));
        return kids.filter(k => (genCache.get(k) || 0) <= _depthLimit);
      }

      function getChildCount(pid) {
        return (_childrenByParent.get(pid) || []).filter(k => comp.members.has(k)).length;
      }

      // Pass 1: compute subtree widths (post-order)
      const subtreeWidths = new Map();
      const widthInProgress = new Set();
      function computeWidth(pid, visited) {
        if (subtreeWidths.has(pid)) return subtreeWidths.get(pid);
        if (visited.has(pid)) return colWidth;
        visited.add(pid);
        if (widthInProgress.has(pid)) return colWidth;
        widthInProgress.add(pid);
        if (isCollapsedFolder(pid)) {
          subtreeWidths.set(pid, colWidth);
          widthInProgress.delete(pid);
          return colWidth;
        }
        const kids = getVisibleChildren(pid);
        // Include spouse width
        const spouses = (_marriagesByPerson.get(pid) || [])
          .map(m => m.a === pid ? m.b : m.a)
          .filter(sid => comp.members.has(sid));
        const spouseExtra = spouses.length > 0 ? colWidth * 0.8 : 0;
        let w;
        if (kids.length === 0) {
          w = colWidth + spouseExtra;
        } else {
          let kidsW = 0;
          kids.forEach(k => { kidsW += computeWidth(k, visited); });
          kidsW += (kids.length - 1) * hGap;
          w = Math.max(colWidth + spouseExtra, kidsW);
        }
        w = Math.min(w, 5000);
        subtreeWidths.set(pid, w);
        widthInProgress.delete(pid);
        return w;
      }
      const visited = new Set();
      const rootWidth = computeWidth(comp.rootId, visited);

      // Pass 2: assign X and Y (pre-order) — children centered under parent
      const assignInProgress = new Set();
      const occupied = new Set();

      function tryPlace(x, y) {
        let actualX = x;
        const yBucket = Math.round(y / rowHeight);
        let xBucket = Math.round(actualX / colWidth);
        let attempts = 0;
        while (occupied.has(xBucket + '|' + yBucket) && attempts < 100) {
          actualX += colWidth;
          xBucket = Math.round(actualX / colWidth);
          attempts++;
        }
        occupied.add(xBucket + '|' + yBucket);
        return { x: actualX, y: y };
      }

      function assign(pid, leftX, baseY, visited) {
        if (visited.has(pid)) return;
        if (assignInProgress.has(pid)) return;
        assignInProgress.add(pid);
        visited.add(pid);
        const w = subtreeWidths.get(pid) || colWidth;
        const cx = leftX + w / 2;

        // Horizontal stagger — odd generations shifted by half colWidth
        const gen = genCache.get(pid) || 0;
        const stagger = (gen % 2 === 1) ? colWidth * 0.5 : 0;
        const staggeredX = cx + stagger;

        const person = _personsById.get(pid);
        const desiredY = baseY + gen * rowHeight;
        const placed = tryPlace(staggeredX, desiredY);

        const node = {
          id: pid,
          person: person,
          gen: gen,
          x: placed.x,
          y: placed.y,
          isFolder: isCollapsedFolder(pid),
          childCount: getChildCount(pid),
          visible: true,
          isSpouse: false,
          partnerId: null,
          component: comp,
          isRoot: pid === comp.rootId,
          subtreeWidth: w,
        };
        _nodes.push(node);
        _nodesById.set(pid, node);

        if (placed.x - circleR < minAbsX) minAbsX = placed.x - circleR;
        if (placed.x + circleR > maxAbsX) maxAbsX = placed.x + circleR;

        // Place spouse close to partner (horizontally, same Y)
        if (_showSpouses) {
          const spouses = (_marriagesByPerson.get(pid) || [])
            .map(m => m.a === pid ? m.b : m.a)
            .filter(sid => comp.members.has(sid) && !visited.has(sid) && !assignInProgress.has(sid));
          spouses.forEach((sid, idx) => {
            visited.add(sid);
            assignInProgress.add(sid);
            const spousePerson = _personsById.get(sid);
            if (!spousePerson) return;
            const spouseGen = genCache.get(sid) || gen;
            // Spouse right next to partner, same Y
            const spouseX = placed.x + circleR + hGap + idx * (circleR * 2 + hGap);
            const spouseY = placed.y;  // same Y as partner
            const spousePlaced = tryPlace(spouseX, spouseY);
            const sNode = {
              id: sid,
              person: spousePerson,
              gen: spouseGen,
              x: spousePlaced.x,
              y: spousePlaced.y,
              isFolder: false,
              childCount: getChildCount(sid),
              visible: true,
              isSpouse: true,
              partnerId: pid,
              component: comp,
              isRoot: false,
              subtreeWidth: colWidth,
            };
            _nodes.push(sNode);
            _nodesById.set(sid, sNode);
            if (spousePlaced.x + circleR > maxAbsX) maxAbsX = spousePlaced.x + circleR;
            if (spousePlaced.x - circleR < minAbsX) minAbsX = spousePlaced.x - circleR;
          });
        }

        // Place children centered under parent
        const kids = getVisibleChildren(pid);
        if (kids.length > 0) {
          let kidsTotalW = 0;
          kids.forEach(k => { kidsTotalW += subtreeWidths.get(k) || colWidth; });
          kidsTotalW += (kids.length - 1) * hGap;
          let childLeftX = cx - kidsTotalW / 2;  // center under parent
          kids.forEach(k => {
            const kw = subtreeWidths.get(k) || colWidth;
            assign(k, childLeftX, baseY, visited);
            childLeftX += kw + hGap;
          });
        }
        assignInProgress.delete(pid);
      }
      const visited2 = new Set();
      assign(comp.rootId, -rootWidth / 2, cursorY, visited2);

      // Place unplaced members
      const placed = new Set(_nodes.filter(nd => nd.component === comp).map(nd => nd.id));
      const unplaced = Array.from(comp.members).filter(id => !placed.has(id));
      let unplacedCol = 0;
      const unplacedX = (maxAbsX + circleR * 2 + 40);
      unplaced.forEach(pid => {
        const person = _personsById.get(pid);
        if (!person) return;
        const gen = genCache.get(pid) || 0;
        const desiredY = cursorY + gen * rowHeight;
        const x = unplacedX + (unplacedCol % 8) * colWidth;
        const placedPos = tryPlace(x, desiredY);
        const node = {
          id: pid, person, gen, x: placedPos.x, y: placedPos.y,
          isFolder: false, childCount: getChildCount(pid),
          visible: true, isSpouse: false, partnerId: null,
          component: comp, isRoot: false, subtreeWidth: colWidth,
        };
        _nodes.push(node);
        _nodesById.set(pid, node);
        unplacedCol++;
        if (placedPos.x + circleR > maxAbsX) maxAbsX = placedPos.x + circleR;
      });

      // Component height
      let maxYInComp = cursorY;
      _nodes.forEach(nd => {
        if (nd.component !== comp) return;
        if (nd.y > maxYInComp) maxYInComp = nd.y;
      });
      const blockHeight = (maxYInComp - cursorY) + circleR * 2 + 40;
      cursorY += blockHeight + 60;
    });

    // Apply orientation
    if (_treeOrientation === 'up') {
      let minY = Infinity, maxY = -Infinity;
      _nodes.forEach(n => {
        if (n.y < minY) minY = n.y;
        if (n.y > maxY) maxY = n.y;
      });
      if (minY !== Infinity) {
        _nodes.forEach(n => { n.y = maxY - (n.y - minY); });
      }
    }

    // Bounds
    const pad = 80;
    let postMinX = Infinity, postMaxX = -Infinity, postMaxY = -Infinity;
    _nodes.forEach(n => {
      if (n.x - circleR < postMinX) postMinX = n.x - circleR;
      if (n.x + circleR > postMaxX) postMaxX = n.x + circleR;
      if (n.y + circleR > postMaxY) postMaxY = n.y + circleR;
    });
    if (postMinX === Infinity) { postMinX = minAbsX; postMaxX = maxAbsX; }
    if (postMaxY === -Infinity) postMaxY = cursorY;

    _layoutBounds = {
      minX: postMinX - pad,
      minY: -pad,
      maxX: postMaxX + pad,
      maxY: postMaxY + pad,
      width: (postMaxX - postMinX) + pad * 2,
      height: postMaxY + pad * 2,
    };

    _layoutDirty = false;
    _visibilityDirty = true;
  }

  function _resolveOverlaps() { /* no-op */ }
  function _redistributeDenseRows() { /* no-op */ }


  // ============================================================
  // VISIBILITY — apply filters + view modes
  // ============================================================
  function _applyVisibility() {
    if (!_data) return;
    const maxGen = _depthLimit;

    const branchIdByFamily = {};
    _branches.forEach(b => { branchIdByFamily[b.name] = b.id; });

    const hasBloodLink = new Set();
    (_data.links || []).forEach(l => {
      if (l.type !== 'parent_child' || l.source === l.target) return;
      hasBloodLink.add(l.source);
      hasBloodLink.add(l.target);
    });

    // Descendants set for focus mode
    let focusSet = null;
    if (_focusPersonId && _focusMode === 'descendants') {
      focusSet = dataModule.getDescendants(_data.links, _focusPersonId, new Set(), true);
      focusSet.add(_focusPersonId);
    } else if (_focusPersonId && _focusMode === 'ancestors') {
      focusSet = dataModule.getAncestors(_data.links, _focusPersonId, new Set());
      focusSet.add(_focusPersonId);
    } else if (_focusPersonId && _focusMode === 'siblings') {
      // siblings = people who share at least one parent with the focus person
      focusSet = new Set([_focusPersonId]);
      const myParents = (_data.links || [])
        .filter(l => l.type === 'parent_child' && l.target === _focusPersonId && l.source !== _focusPersonId)
        .map(l => l.source);
      myParents.forEach(p => {
        const sibs = (_data.links || [])
          .filter(l => l.type === 'parent_child' && l.source === p && l.target !== _focusPersonId)
          .map(l => l.target);
        sibs.forEach(s => focusSet.add(s));
        focusSet.add(p); // include the shared parent too so the link is visible
      });
    } else if (_focusPersonId && _focusMode === 'spouses') {
      // spouses = the focus person + all their spouses
      focusSet = new Set([_focusPersonId]);
      dataModule.getSpouses(_data.links, _focusPersonId).forEach(s => focusSet.add(s));
    } else if (_viewMode === 'descendants' && _selectedNodeId) {
      focusSet = dataModule.getDescendants(_data.links, _selectedNodeId, new Set(), true);
      focusSet.add(_selectedNodeId);
    }

    _nodes.forEach(n => {
      let visible = true;
      if (n.gen > maxGen) visible = false;
      // v80 #2: filter buttons add colored borders ONLY to directly connected
      // nodes (parents, spouses, children of the selected person). NOT grandchildren
      // or other distant relatives that are in _highlightSet but not directly
      // linked to the selected person.
      n.filterBorder = null;  // reset
      if (_aliveOnly || _deceasedOnly) {
        const hasSelection = _selectedNodeId && _highlightSet && _highlightSet.size > 0;
        if (hasSelection) {
          // Build a set of directly-connected node IDs: the selected person +
          // everyone who shares a highlighted link with them (parent→child where
          // one end is the selected person, or marriage where one end is selected).
          // This EXCLUDES grandchildren (link is parent→child→grandchild, the
          // grandchild link doesn't involve the selected person directly).
          if (!_directConnectionSet || _directConnectionSet._selId !== _selectedNodeId) {
            _directConnectionSet = new Set([_selectedNodeId]);
            _directConnectionSet._selId = _selectedNodeId;
            if (_highlightedLinks) {
              _highlightedLinks.forEach(l => {
                if (l.source === _selectedNodeId) _directConnectionSet.add(l.target);
                if (l.target === _selectedNodeId) _directConnectionSet.add(l.source);
              });
            }
          }
          if (_directConnectionSet.has(n.id)) {
            if (_aliveOnly && dataModule.isAlive(n.person)) {
              n.filterBorder = 'alive';
            } else if (_deceasedOnly && dataModule.isDeceased(n.person)) {
              n.filterBorder = 'deceased';
            }
          }
        }
      }
      if (!_showSpouses) {
        if (n.isSpouse) visible = false;
        else if (!hasBloodLink.has(n.id)) visible = false;
      }
      if (_hideDivorced) {
        const ms = _marriagesByPerson.get(n.id) || [];
        if (ms.some(m => m.divorced)) visible = false;
      }
      const fam = n.person.family || '—';
      const bid = branchIdByFamily[fam];
      if (bid !== undefined && _hiddenBranches.has(bid)) visible = false;
      if (focusSet && !focusSet.has(n.id)) visible = false;
      n.visible = visible;
    });

    // Folder visibility is already handled in layout (children of collapsed
    // folders are not laid out at all). Here we just mark them as folders.
    _nodes.forEach(n => { n.isFolder = n.isFolder && n.visible; });

    _visibilityDirty = false;
    // Invalidate caches
    _visibleNodesCache = null;
    _visibleLinksCache = null;
  }

  // ============================================================
  // VIEWPORT CULLING — only draw nodes/links within visible rect
  // ============================================================
  function _getVisibleWorldRect() {
    const canvasW = _canvas.width / _dpr;
    const canvasH = _canvas.height / _dpr;
    // World coords of viewport corners
    // screen (0,0) → world (-canvasW/2 - offsetX) / scale
    const halfW = canvasW / (2 * _scale);
    const halfH = canvasH / (2 * _scale);
    const cx = -_offsetX / _scale;
    const cy = -_offsetY / _scale;
    // Add margin so cards partially visible are still drawn
    const margin = _effectiveCircleR * 2;
    return {
      minX: cx - halfW - margin,
      maxX: cx + halfW + margin,
      minY: cy - halfH - margin,
      maxY: cy + halfH + margin,
    };
  }

  function _getVisibleNodes() {
    // NEVER cache across frames — viewport changes (pan/zoom) invalidate it.
    // Computing this is cheap (524 iterations × bbox check) compared to drawing.
    if (_visibilityDirty) _applyVisibility();
    const rect = _getVisibleWorldRect();
    const result = [];
    for (const n of _nodes) {
      if (!n.visible) continue;
      if (n.x < rect.minX || n.x > rect.maxX) continue;
      if (n.y < rect.minY || n.y > rect.maxY) continue;
      result.push(n);
    }
    _visibleNodesCache = result;
    return result;
  }

  function _getVisibleLinks(visibleNodes) {
    // Also never cache — visibleNodes changes every frame.
    const visibleIds = new Set(visibleNodes.map(n => n.id));
    const links = _data.links || [];
    const result = [];
    // Parent-child links
    for (const l of links) {
      if (l.type !== 'parent_child') continue;
      if (l.source === l.target) continue;
      if (!visibleIds.has(l.source) || !visibleIds.has(l.target)) continue;
      // Skip if parent is a folder (folder represents all children)
      const parent = _nodesById.get(l.source);
      if (parent && parent.isFolder) continue;
      result.push({ kind: 'parent', source: l.source, target: l.target });
    }
    // Marriage links
    if (_showSpouses) {
      for (const m of _marriages) {
        if (!visibleIds.has(m.a) || !visibleIds.has(m.b)) continue;
        result.push({ kind: 'marriage', source: m.a, target: m.b, divorced: m.divorced });
      }
    }
    return result;
  }

  // ============================================================
  // RENDERING
  // ============================================================
  function _getZoomLevel() {
    if (_scale < 0.22) return 'satellite';
    if (_scale < 0.7) return 'structural';
    return 'working';
  }

  function _draw() {
    if (!_canvas || !_ctx) return;
    if (_layoutDirty) _computeLayout();
    if (_visibilityDirty) _applyVisibility();

    const theme = readTheme();
    const W = _canvas.width / _dpr;
    const H = _canvas.height / _dpr;

    _ctx.save();
    _ctx.fillStyle = theme.bgPrimary;
    _ctx.fillRect(0, 0, W, H);

    // Subtle radial gradient backdrop
    const grad = _ctx.createRadialGradient(W/2, H/2, 0, W/2, H/2, Math.max(W, H) / 1.5);
    grad.addColorStop(0, hexToRgba(theme.accent, 0.04));
    grad.addColorStop(1, 'rgba(0,0,0,0)');
    _ctx.fillStyle = grad;
    _ctx.fillRect(0, 0, W, H);

    _ctx.translate(W / 2 + _offsetX, H / 2 + _offsetY);
    _ctx.scale(_scale, _scale);

    // Draw component headers (always, even if culling skips them — they're small)
    _drawComponentHeaders(theme);

    // Viewport culling — get only visible nodes
    const visibleNodes = _getVisibleNodes();
    const visibleLinks = _getVisibleLinks(visibleNodes);

    // Draw connection lines first (behind cards)
    _drawConnections(theme, visibleLinks);

    // Draw sibling brackets (skip in satellite mode)
    const level = _getZoomLevel();
    if (level !== 'satellite') {
      _drawSiblingBrackets(theme, visibleNodes);
    }

    // Draw nodes
    if (level === 'satellite')      _drawSatelliteDots(theme, visibleNodes);
    else if (level === 'structural') _drawStructuralChips(theme, visibleNodes);
    else                             _drawWorkingChips(theme, visibleNodes);

    _ctx.restore();

    _updateModeUI(level);
    _updateModeBanner();
    _drawMinimap();
  }

  function _drawComponentHeaders(theme) {
    if (_components.length === 0) return;
    _ctx.save();
    _ctx.font = `bold 14px sans-serif`;
    _ctx.fillStyle = theme.textMuted;
    _ctx.textAlign = 'left';
    _ctx.textBaseline = 'top';
    _components.forEach((comp, idx) => {
      // Only draw if roughly in viewport
      const rect = _getVisibleWorldRect();
      if (comp.headerY < rect.minY || comp.headerY > rect.maxY) return;
      const root = _personsById.get(comp.rootId);
      const rootName = root ? (root.lastName || root.firstName || '?') : '?';
      const text = `${i18n.t('tree2.component') || 'Дерево'} ${idx + 1}: ${rootName} (${comp.size} ${i18n.t('tree2.people') || 'чел.'})`;
      _ctx.fillText(text, -_layoutBounds.width / 2 + 20, comp.headerY);
      // Separator line
      _ctx.strokeStyle = hexToRgba(theme.borderColor, 0.6);
      _ctx.lineWidth = 1 / _scale;
      _ctx.setLineDash([8 / _scale, 4 / _scale]);
      _ctx.beginPath();
      _ctx.moveTo(-_layoutBounds.width / 2, comp.headerY + 24);
      _ctx.lineTo(_layoutBounds.width / 2, comp.headerY + 24);
      _ctx.stroke();
      _ctx.setLineDash([]);
    });
    _ctx.restore();
  }

  // compute the point on a card's edge where a line from `from` to the
  // card centre would intersect. This makes connection lines "dock" to the
  // card at the side/corner where they actually approach, instead of always
  // going to top/bottom centre.
  //   `cardX, cardY` = card centre; `cardW, cardH` = card dimensions.
  //   `fromX, fromY` = the other endpoint (also a card centre).
  // Returns {x, y} on the card's border.
  function _dockPointToCard(cardX, cardY, cardW, cardH, fromX, fromY) {
    const halfW = cardW / 2;
    const halfH = cardH / 2;
    const dx = fromX - cardX;
    const dy = fromY - cardY;
    // Handle degenerate case (same point)
    if (Math.abs(dx) < 0.001 && Math.abs(dy) < 0.001) {
      return { x: cardX, y: cardY + halfH }; // bottom centre
    }
    // Compute intersection of the line (cardCentre → from) with the card's
    // rectangle border. We scale (dx, dy) so that it just touches the border.
    // Use the ratio of half-dimensions to find which side we hit.
    const sx = halfW / Math.max(Math.abs(dx), 0.0001);
    const sy = halfH / Math.max(Math.abs(dy), 0.0001);
    const s = Math.min(sx, sy);
    return {
      x: cardX + dx * s,
      y: cardY + dy * s,
    };
  }

  function _drawConnections(theme, visibleLinks) {
    const level = _getZoomLevel();
    // when a card is selected for highlight, the highlighted links are
    // drawn LAST and THICKER so they pop out; non-highlighted links are dimmed.
    const hasHighlight = _highlightedLinks && _highlightedLinks.length > 0;
    // Build a quick lookup of highlighted link keys
    const highlightedParentKeys = new Set();
    const highlightedMarriageKeys = new Set();
    if (hasHighlight) {
      _highlightedLinks.forEach(l => {
        if (l.kind === 'parent') highlightedParentKeys.add(l.source + '|' + l.target);
        else highlightedMarriageKeys.add([l.source, l.target].sort().join('|'));
      });
    }

    // Determine card dimensions based on zoom level
    // Use circle diameter for docking
    let cardW = _effectiveCircleR * 2, cardH = _effectiveCircleR * 2;
    if (level === 'satellite') { cardW = 4; cardH = 4; }
    else if (level === 'structural') { cardW = CARD_W_STRUCT; cardH = CARD_H_STRUCT; }

    // ---- Parent → child (curved, blue solid) ----
    let lineWidth = 1.5, alpha = 0.7;
    if (level === 'satellite') { lineWidth = 0.4; alpha = 0.25; }
    else if (level === 'structural') { lineWidth = 0.8; alpha = 0.45; }
    if (hasHighlight) alpha *= 0.25;

    _ctx.save();
    _ctx.strokeStyle = hexToRgba(theme.connParent, alpha);
    _ctx.lineWidth = lineWidth / _scale;
    _ctx.lineCap = 'round';

    // Pass 1: draw non-highlighted parent links (dimmed)
    // Add slight lateral offset based on link index to separate overlapping lines
    let parentLinkIdx = 0;
    for (const l of visibleLinks) {
      if (l.kind !== 'parent') continue;
      const key = l.source + '|' + l.target;
      if (hasHighlight && highlightedParentKeys.has(key)) continue; // draw later
      const a = _nodesById.get(l.source);
      const b = _nodesById.get(l.target);
      if (!a || !b) continue;
      if (!a.visible || !b.visible) continue;
      const startPt = _dockPointToCard(a.x, a.y, cardW, cardH, b.x, b.y);
      const endPt = _dockPointToCard(b.x, b.y, cardW, cardH, a.x, a.y);
      // Lateral offset to separate overlapping lines — alternate left/right
      const offset = (parentLinkIdx % 3 - 1) * 8 / _scale;  // -8, 0, +8
      parentLinkIdx++;
      _ctx.beginPath();
      _ctx.moveTo(startPt.x + offset, startPt.y);
      const midY = (startPt.y + endPt.y) / 2;
      _ctx.bezierCurveTo(startPt.x + offset, midY, endPt.x + offset, midY, endPt.x + offset, endPt.y);
      _ctx.stroke();
    }

    // Pass 2: draw HIGHLIGHTED parent links thick + accent color
    if (hasHighlight) {
      _ctx.strokeStyle = theme.accent;
      _ctx.lineWidth = (lineWidth * 3.5) / _scale;
      _ctx.shadowColor = theme.accent;
      _ctx.shadowBlur = 8 / _scale;
      for (const l of _highlightedLinks) {
        if (l.kind !== 'parent') continue;
        const a = _nodesById.get(l.source);
        const b = _nodesById.get(l.target);
        if (!a || !b) continue;
        // Draw highlighted links even if endpoint is outside viewport.
        // Previously skipped if !a.visible || !b.visible, which prevented
        // children/grandchildren links from showing when those nodes were
        // culled by viewport. For highlighted links we draw regardless.
        if (a.isFolder || b.isFolder) continue;
        const startPt = _dockPointToCard(a.x, a.y, cardW, cardH, b.x, b.y);
        const endPt = _dockPointToCard(b.x, b.y, cardW, cardH, a.x, a.y);
        _ctx.beginPath();
        _ctx.moveTo(startPt.x, startPt.y);
        const midY = (startPt.y + endPt.y) / 2;
        _ctx.bezierCurveTo(startPt.x, midY, endPt.x, midY, endPt.x, endPt.y);
        _ctx.stroke();
      }
      _ctx.shadowBlur = 0;
    }

    // ---- Marriage (pink dashed) ----
    let mLineWidth = 2.0, mAlpha = 0.85;
    if (level === 'satellite') { mLineWidth = 0.5; mAlpha = 0.3; }
    else if (level === 'structural') { mLineWidth = 1.2; mAlpha = 0.6; }
    if (hasHighlight) mAlpha *= 0.25;

    _ctx.strokeStyle = hexToRgba(theme.connMarriage, mAlpha);
    _ctx.lineWidth = mLineWidth / _scale;
    _ctx.setLineDash([6 / _scale, 4 / _scale]);

    // Pass 1: non-highlighted marriage links (dimmed)
    // Curved marriage lines (bezier) instead of straight — avoids overlapping circles
    for (const l of visibleLinks) {
      if (l.kind !== 'marriage') continue;
      const key = [l.source, l.target].sort().join('|');
      if (hasHighlight && highlightedMarriageKeys.has(key)) continue; // draw later
      const a = _nodesById.get(l.source);
      const b = _nodesById.get(l.target);
      if (!a || !b) continue;
      if (!a.visible || !b.visible) continue;
      const startPt = _dockPointToCard(a.x, a.y, cardW, cardH, b.x, b.y);
      const endPt = _dockPointToCard(b.x, b.y, cardW, cardH, a.x, a.y);
      // Curved path — arc above the midpoint
      _ctx.beginPath();
      _ctx.moveTo(startPt.x, startPt.y);
      const midX = (startPt.x + endPt.x) / 2;
      const midY = (startPt.y + endPt.y) / 2;
      // Perpendicular offset for curve control point
      const dx = endPt.x - startPt.x;
      const dy = endPt.y - startPt.y;
      const dist = Math.sqrt(dx * dx + dy * dy) || 1;
      const perpX = -dy / dist * dist * 0.3;
      const perpY = dx / dist * dist * 0.3;
      _ctx.quadraticCurveTo(midX + perpX, midY + perpY, endPt.x, endPt.y);
      _ctx.stroke();
    }

    // Pass 2: HIGHLIGHTED marriage links (thick pink dashed)
    if (hasHighlight) {
      _ctx.strokeStyle = theme.connMarriage;
      _ctx.lineWidth = (mLineWidth * 2.5) / _scale;
      _ctx.shadowColor = theme.connMarriage;
      _ctx.shadowBlur = 6 / _scale;
      _ctx.setLineDash([8 / _scale, 5 / _scale]);
      for (const l of _highlightedLinks) {
        if (l.kind !== 'marriage') continue;
        const a = _nodesById.get(l.source);
        const b = _nodesById.get(l.target);
        if (!a || !b) continue;
        // Draw marriage links even if endpoint is outside viewport
        if (a.isFolder || b.isFolder) continue;
        const startPt = _dockPointToCard(a.x, a.y, cardW, cardH, b.x, b.y);
        const endPt = _dockPointToCard(b.x, b.y, cardW, cardH, a.x, a.y);
        // Curved marriage line
        _ctx.beginPath();
        _ctx.moveTo(startPt.x, startPt.y);
        const midX = (startPt.x + endPt.x) / 2;
        const midY = (startPt.y + endPt.y) / 2;
        const dx = endPt.x - startPt.x;
        const dy = endPt.y - startPt.y;
        const dist = Math.sqrt(dx * dx + dy * dy) || 1;
        const perpX = -dy / dist * dist * 0.3;
        const perpY = dx / dist * dist * 0.3;
        _ctx.quadraticCurveTo(midX + perpX, midY + perpY, endPt.x, endPt.y);
        _ctx.stroke();
      }
      _ctx.shadowBlur = 0;
    }
    _ctx.setLineDash([]);
    _ctx.restore();

    // v83 #2: Draw HIGHLIGHTED sibling connections — blue curved lines between
    // the selected person and their siblings. ONLY drawn when a person is
    // selected (hasHighlight). When no person is selected, NO sibling lines
    // are drawn at all (user request: "убери серые линии в обычном режиме").
    if (hasHighlight && level !== 'satellite') {
      const highlightedSiblingLinks = (_highlightedLinks || []).filter(l => l.kind === 'sibling');
      if (highlightedSiblingLinks.length > 0) {
        _ctx.save();
        _ctx.strokeStyle = theme.accent;
        _ctx.lineWidth = (lineWidth * 3) / _scale;
        _ctx.shadowColor = theme.accent;
        _ctx.shadowBlur = 6 / _scale;
        _ctx.lineCap = 'round';
        highlightedSiblingLinks.forEach(l => {
          const a = _nodesById.get(l.source);
          const b = _nodesById.get(l.target);
          if (!a || !b) return;
          if (a.isFolder || b.isFolder) return;
          // Dock to circle edges
          const sa = _dockPointToCard(a.x, a.y, cardW, cardH, b.x, b.y);
          const sb = _dockPointToCard(b.x, b.y, cardW, cardH, a.x, a.y);
          // Curved line (bezier) — same style as parent-child highlighted
          _ctx.beginPath();
          _ctx.moveTo(sa.x, sa.y);
          const midY = (sa.y + sb.y) / 2;
          _ctx.bezierCurveTo(sa.x, midY, sb.x, midY, sb.x, sb.y);
          _ctx.stroke();
        });
        _ctx.shadowBlur = 0;
        _ctx.restore();
      }
    }
  }

  // Helper for backward compat — kept for any code that still calls _isInViewport.
  function _isInViewport(n) {
    if (!n) return false;
    const r = _getVisibleWorldRect();
    return n.x >= r.minX && n.x <= r.maxX && n.y >= r.minY && n.y <= r.maxY;
  }

  function _drawSiblingBrackets(theme, visibleNodes) {
    const visibleIds = new Set(visibleNodes.map(n => n.id));
    _ctx.save();
    _ctx.strokeStyle = hexToRgba(theme.textMuted, 0.55);
    _ctx.lineWidth = 1.4 / _scale;

    for (const group of _siblingGroups) {
      const kids = group.childIds.filter(id => visibleIds.has(id));
      if (kids.length < 2) continue;
      const coords = kids.map(id => _nodesById.get(id)).filter(Boolean);
      if (coords.length < 2) continue;
      // Bracket sits ABOVE the siblings (between parents and kids)
      const minX = Math.min(...coords.map(c => c.x)) - _effectiveCardW / 2;
      const maxX = Math.max(...coords.map(c => c.x)) + _effectiveCardW / 2;
      const y = coords[0].y - CARD_H / 2 - 12;
      // Horizontal line
      _ctx.beginPath();
      _ctx.moveTo(minX, y);
      _ctx.lineTo(maxX, y);
      _ctx.stroke();
      // Down-ticks at each child
      coords.forEach(c => {
        _ctx.beginPath();
        _ctx.moveTo(c.x, y);
        _ctx.lineTo(c.x, y + 8);
        _ctx.stroke();
      });
      // Up-tick in the middle (toward parents)
      const midX = (minX + maxX) / 2;
      _ctx.beginPath();
      _ctx.moveTo(midX, y);
      _ctx.lineTo(midX, y - 8);
      _ctx.stroke();
    }
    _ctx.restore();
  }


  // ============================================================
  // CIRCLE-BASED DRAWING
  // ============================================================
  // Replaces rectangular cards with circles containing 3-letter initials.
  // On selection: circle shows "Surname IO" (can extend beyond circle).
  // Highlighted family members get accent border + glow.
  // Labels are staggered (checkerboard) to prevent overlap.

  function _branchColorFor(person) {
    if (!person.family) return null;
    const br = _branches.find(b => b.name === person.family);
    return br ? br.color : null;
  }

  function _drawSatelliteDots(theme, visibleNodes) {
    _ctx.save();
    const r = _effectiveCircleR / _scale * 0.5;
    for (const n of visibleNodes) {
      const color = _branchColorFor(n.person) || (n.person.gender === 'female' ? theme.female : theme.male);
      _ctx.fillStyle = color;
      _ctx.globalAlpha = n.isRoot ? 1.0 : 0.85;
      _ctx.beginPath();
      _ctx.arc(n.x, n.y, Math.max(r, 2), 0, 2 * Math.PI);
      _ctx.fill();
    }
    _ctx.restore();
  }

  function _drawStructuralChips(theme, visibleNodes) {
    _drawCircles(theme, visibleNodes, 'structural');
  }

  function _drawWorkingChips(theme, visibleNodes) {
    _drawCircles(theme, visibleNodes, 'working');
  }

  // Main circle drawing function — handles all 3 zoom levels
  function _drawCircles(theme, visibleNodes, level) {
    _ctx.save();
    const hasHighlight = _highlightSet && _highlightSet.size > 0;
    const r = _effectiveCircleR;
    const fontSize = Math.round(r * 0.65);
    const labelFont = Math.round(r * 0.55);

    // Track label positions for overlap prevention (checkerboard stagger)
    const labelPositions = [];  // {x, y, text}

    // Pass 1: draw non-highlighted circles (dimmed if highlight active)
    for (const n of visibleNodes) {
      if (n.isFolder) {
        _drawFolderCircle(theme, n, r);
        continue;
      }
      if (hasHighlight && _highlightSet.has(n.id) && n.id !== _selectedNodeId) continue;
      if (hasHighlight && n.id !== _selectedNodeId) {
        _ctx.save();
        _ctx.globalAlpha = 0.35;  // increased from 0.25 for visibility
        _drawCircle(theme, n, r, fontSize, level, false, false);
        _ctx.restore();
      } else {
        _drawCircle(theme, n, r, fontSize, level, false, false);
      }
    }

    // Pass 2: draw HIGHLIGHTED circles (except selected) on top, full opacity
    if (hasHighlight) {
      for (const n of _nodes) {
        if (n.isFolder) continue;
        if (!_highlightSet.has(n.id)) continue;
        if (n.id === _selectedNodeId) continue;
        _drawCircle(theme, n, r, fontSize, level, true, false);
      }
    }

    // Pass 3: draw SELECTED circle last with halo + full name label
    if (_selectedNodeId) {
      const sel = _nodesById.get(_selectedNodeId);
      if (sel && !sel.isFolder) {
        _drawCircle(theme, sel, r, fontSize, level, false, true);
        _ctx.save();
        _ctx.strokeStyle = theme.accent;
        _ctx.lineWidth = 3 / _scale;
        _ctx.setLineDash([6 / _scale, 4 / _scale]);
        _ctx.beginPath();
        _ctx.arc(sel.x, sel.y, r + 8, 0, 2 * Math.PI);
        _ctx.stroke();
        _ctx.setLineDash([]);
        _ctx.restore();
      } else if (sel && sel.isFolder) {
        _drawFolderCircle(theme, sel, r);
      }
    }

    // Pass 4: draw labels for highlighted/selected circles (staggered)
    if (hasHighlight || _selectedNodeId) {
      _drawStaggeredLabels(theme, visibleNodes, r, labelFont);
    }

    _ctx.restore();
  }

  // v94: Draw a photo clipped to a circle at (cx, cy) with radius r.
  // v101 FIX П1/Б13: LRU cache with onerror eviction, max 200 entries.
  const _photoImageCache = new Map();
  const _PHOTO_CACHE_MAX = 200;

  function _photoCacheGet(key) {
    if (!_photoImageCache.has(key)) return null;
    const v = _photoImageCache.get(key);
    _photoImageCache.delete(key); // re-insert to mark as recently used
    _photoImageCache.set(key, v);
    return v;
  }
  function _photoCacheSet(key, val) {
    if (_photoImageCache.size >= _PHOTO_CACHE_MAX) {
      const oldest = _photoImageCache.keys().next().value;
      _photoImageCache.delete(oldest);
    }
    _photoImageCache.set(key, val);
  }
  function _clearPhotoCache() { _photoImageCache.clear(); }

  function _drawPhotoInCircle(ctx, dataUrl, cx, cy, r) {
    let img = _photoCacheGet(dataUrl);
    if (!img) {
      img = new Image();
      img.onload = () => {
        if (typeof _requestRender === 'function') _requestRender();
        else _render();
      };
      // v101 FIX Б13: evict broken images so they can be retried
      img.onerror = () => { _photoImageCache.delete(dataUrl); };
      img.src = dataUrl;
      _photoCacheSet(dataUrl, img);
      return false;
    }
    if (!img.complete || img.naturalWidth === 0) {
      return false;
    }
    ctx.save();
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, 2 * Math.PI);
    ctx.closePath();
    ctx.clip();
    const iw = img.naturalWidth, ih = img.naturalHeight;
    const scale = Math.max((r * 2) / iw, (r * 2) / ih);
    const dw = iw * scale, dh = ih * scale;
    ctx.drawImage(img, cx - dw / 2, cy - dh / 2, dw, dh);
    ctx.restore();
    return true;
  }

  // Draw a single circle with initials
  function _drawCircle(theme, n, r, fontSize, zoomLevel, highlighted, selected) {
    const p = n.person;

    // Glow shadow for highlighted/selected
    if (highlighted || selected) {
      _ctx.save();
      _ctx.shadowColor = selected ? theme.accent : theme.accent;
      _ctx.shadowBlur = selected ? 15 : 10;
    }

    // Circle background — gender-tinted
    const bgAlpha = selected ? 0.55 : (highlighted ? 0.45 : 0.40);  // increased for visibility
    const bg = p.gender === 'female' ? hexToRgba(theme.female, bgAlpha) : hexToRgba(theme.male, bgAlpha);
    _ctx.fillStyle = bg;

    // Border
    let border, sw;
    if (selected) { border = theme.accent; sw = 3.5; }
    else if (highlighted) { border = theme.accent; sw = 2.5; }
    else { border = p.status === 'alive' ? theme.success : theme.textMuted; sw = p.status === 'alive' ? 2.5 : 1.5; }

    _ctx.strokeStyle = border;
    _ctx.lineWidth = sw;
    _ctx.beginPath();
    _ctx.arc(n.x, n.y, r, 0, 2 * Math.PI);
    _ctx.fill();
    _ctx.stroke();

    // Root marker — gold ring
    if (n.isRoot && !selected) {
      _ctx.strokeStyle = '#f1c40f';
      _ctx.lineWidth = 2;
      _ctx.beginPath();
      _ctx.arc(n.x, n.y, r + 3, 0, 2 * Math.PI);
      _ctx.stroke();
    }

    // v79 #2: filter border — thick green (alive) or black (deceased) ring
    // around highlighted nodes when filter button is pressed
    if (n.filterBorder) {
      _ctx.strokeStyle = n.filterBorder === 'alive' ? '#28a745' : '#000';
      _ctx.lineWidth = 5;
      _ctx.beginPath();
      _ctx.arc(n.x, n.y, r + 5, 0, 2 * Math.PI);
      _ctx.stroke();
    }

    if (highlighted || selected) {
      _ctx.restore();
    }

    // Family color dot (top-right of circle)
    const fc = _branchColorFor(p);
    if (fc) {
      _ctx.fillStyle = fc;
      _ctx.beginPath();
      _ctx.arc(n.x + r * 0.65, n.y - r * 0.65, r * 0.18, 0, 2 * Math.PI);
      _ctx.fill();
    }

    // v94: Draw photo inside circle if available, otherwise 3-letter initials.
    if (zoomLevel !== 'satellite') {
      // v92: check if person has a photo (person.photo is now a filename or data URL)
      let photoDataUrl = null;
      if (p.photo) {
        if (p.photo.startsWith('data:')) {
          photoDataUrl = p.photo;  // old v91 format (base64 in memory)
        } else if (typeof filesystem !== 'undefined' && filesystem.isConnected()) {
          // v92: person.photo is a filename — check in-memory cache
          photoDataUrl = filesystem.getCachedPhotoDataUrlSync(p.id);
          if (!photoDataUrl) {
            // Not in cache — trigger async load for next render
            if (typeof app !== 'undefined' && app._ensurePhotoCached) {
              app._ensurePhotoCached(p.id);
            }
          }
        }
      }

      if (photoDataUrl) {
        // Draw photo clipped to circle. If image not yet loaded, fall back to initials.
        const drawn = _drawPhotoInCircle(_ctx, photoDataUrl, n.x, n.y, r);
        if (!drawn) {
          // Photo still loading — show initials as temporary fallback
          const fi = (p.firstName || '?')[0] || '';
          const li = (p.lastName || '?')[0] || '';
          const pi = (p.patronymic || '?')[0] || '';
          const initials = (li + fi + pi).toUpperCase();
          _ctx.fillStyle = theme.textPrimary;
          _ctx.font = `bold ${fontSize}px sans-serif`;
          _ctx.textAlign = 'center';
          _ctx.textBaseline = 'middle';
          _ctx.fillText(initials, n.x, n.y);
        }
      } else {
        // No photo — draw 3-letter initials
        const fi = (p.firstName || '?')[0] || '';
        const li = (p.lastName || '?')[0] || '';
        const pi = (p.patronymic || '?')[0] || '';
        const initials = (li + fi + pi).toUpperCase();

        _ctx.fillStyle = theme.textPrimary;
        _ctx.font = `bold ${fontSize}px sans-serif`;
        _ctx.textAlign = 'center';
        _ctx.textBaseline = 'middle';
        _ctx.fillText(initials, n.x, n.y);
      }
    }

    // v94: Show "Surname IO" label for SELECTED AND HIGHLIGHTED nodes
    // (previously highlighted showed only surname).
    if (selected) {
      const surname = (p.lastName || '—');
      const initialsIO = ((p.firstName || '?')[0] || '') + ((p.patronymic || '?')[0] || '');
      const label = `${surname} ${initialsIO.toUpperCase()}`;
      n._label = label;
    } else if (highlighted) {
      // v94: show "Surname IO" for highlighted nodes too (was surname only)
      const surname = (p.lastName || '—');
      const initialsIO = ((p.firstName || '?')[0] || '') + ((p.patronymic || '?')[0] || '');
      const label = `${surname} ${initialsIO.toUpperCase()}`;
      n._label = label;
    } else {
      n._label = null;
    }
  }

  // Draw folder circle (collapsed branch with >3 children)
  function _drawFolderCircle(theme, n, r) {
    _ctx.fillStyle = hexToRgba(theme.warning, 0.22);
    _ctx.strokeStyle = theme.warning;
    _ctx.lineWidth = 2;
    _ctx.setLineDash([4 / _scale, 3 / _scale]);
    _ctx.beginPath();
    _ctx.arc(n.x, n.y, r, 0, 2 * Math.PI);
    _ctx.fill();
    _ctx.stroke();
    _ctx.setLineDash([]);

    _ctx.fillStyle = theme.warning;
    _ctx.font = `bold ${Math.round(r * 0.5)}px sans-serif`;
    _ctx.textAlign = 'center';
    _ctx.textBaseline = 'middle';
    _ctx.fillText('+', n.x, n.y);
  }

  // Draw staggered labels for highlighted/selected circles
  // Uses checkerboard pattern to prevent label overlap
  function _drawStaggeredLabels(theme, visibleNodes, r, fontSize) {
    const hasHighlight = _highlightSet && _highlightSet.size > 0;
    if (!hasHighlight && !_selectedNodeId) return;

    // Collect all nodes that need labels
    const labeledNodes = [];
    for (const n of _nodes) {
      if (n.isFolder) continue;
      if (!n._label) continue;
      labeledNodes.push(n);
    }

    // Sort by Y then X for consistent staggering
    labeledNodes.sort((a, b) => a.y - b.y || a.x - b.x);

    // Assign staggered positions (checkerboard: alternate above/below circle)
    const labelOffsets = [];  // {node, offsetX, offsetY}
    const occupiedLabels = [];  // {x, y, w, h} for collision detection

    labeledNodes.forEach((n, idx) => {
      const text = n._label;
      // Estimate text width (rough: 0.6 * fontSize * text.length)
      const textW = text.length * fontSize * 0.6;
      const textH = fontSize + 4;

      // Checkerboard: even index → above, odd index → below
      const baseOffsetY = (idx % 2 === 0) ? -(r + textH / 2 + 2) : (r + textH / 2 + 2);

      // Try base position first
      let offsetX = 0;
      let offsetY = baseOffsetY;
      let collision = true;
      let attempts = 0;

      while (collision && attempts < 8) {
        collision = false;
        const lx = n.x + offsetX - textW / 2;
        const ly = n.y + offsetY - textH / 2;
        for (const occ of occupiedLabels) {
          if (lx < occ.x + occ.w && lx + textW > occ.x &&
              ly < occ.y + occ.h && ly + textH > occ.y) {
            collision = true;
            break;
          }
        }
        if (collision) {
          // Try shifting: alternate between further up/down and right/left
          if (attempts % 4 === 0) offsetY = baseOffsetY - (attempts / 4 + 1) * (textH + 2);
          else if (attempts % 4 === 1) offsetY = baseOffsetY + (attempts / 4 + 1) * (textH + 2);
          else if (attempts % 4 === 2) { offsetX += textW * 0.7; offsetY = baseOffsetY; }
          else { offsetX -= textW * 0.7; offsetY = baseOffsetY; }
        }
        attempts++;
      }

      occupiedLabels.push({
        x: n.x + offsetX - textW / 2,
        y: n.y + offsetY - textH / 2,
        w: textW, h: textH
      });

      labelOffsets.push({ node: n, offsetX, offsetY, text });
    });

    // Draw labels with background pill for readability
    for (const lo of labelOffsets) {
      const text = lo.text;
      const textW = text.length * fontSize * 0.6;
      const textH = fontSize + 4;
      const lx = lo.node.x + lo.offsetX;
      const ly = lo.node.y + lo.offsetY;

      // Background pill
      _ctx.fillStyle = hexToRgba(theme.bgCard || '#ffffff', 0.85);
      _ctx.beginPath();
      _roundRect(lx - textW / 2 - 3, ly - textH / 2, textW + 6, textH, textH / 2);
      _ctx.fill();

      // Text
      const isSelected = lo.node.id === _selectedNodeId;
      _ctx.fillStyle = isSelected ? theme.accent : theme.textPrimary;
      _ctx.font = `bold ${fontSize}px sans-serif`;
      _ctx.textAlign = 'center';
      _ctx.textBaseline = 'middle';
      _ctx.fillText(text, lx, ly);

      // Connector line from circle to label
      _ctx.strokeStyle = hexToRgba(theme.textMuted, 0.4);
      _ctx.lineWidth = 1 / _scale;
      _ctx.beginPath();
      _ctx.moveTo(lo.node.x, lo.node.y + (lo.offsetY > 0 ? _effectiveCircleR : -_effectiveCircleR));
      _ctx.lineTo(lx, ly + (lo.offsetY > 0 ? -textH / 2 : textH / 2));
      _ctx.stroke();
    }
  }

  function _roundRect(x, y, w, h, r) {
    if (w < r * 2) r = w / 2;
    if (h < r * 2) r = h / 2;
    _ctx.beginPath();
    _ctx.moveTo(x + r, y);
    _ctx.arcTo(x + w, y, x + w, y + h, r);
    _ctx.arcTo(x + w, y + h, x, y + h, r);
    _ctx.arcTo(x, y + h, x, y, r);
    _ctx.arcTo(x, y, x + w, y, r);
    _ctx.closePath();
  }


  function _formatYears(p) {
    const b = p.birthDate || '';
    const d = p.deathDate || '';
    if (b && d) return `${_yearOf(b)}–${_yearOf(d)}`;
    if (b) return `${_yearOf(b)}–…`;
    if (d) return `?–${_yearOf(d)}`;
    if (p.status === 'alive') return i18n.t('card.present') || 'н.в.';
    return '';
  }

  function _yearOf(s) {
    if (!s) return '';
    const m = String(s).match(/(\d{4})/);
    return m ? m[1] : String(s);
  }

  // ============================================================
  // MINIMAP
  // ============================================================
  function _drawMinimap() {
    if (!_mmCanvas || !_mmCtx) return;
    const theme = readTheme();
    const W = _mmCanvas.width;
    const H = _mmCanvas.height;
    _mmCtx.fillStyle = theme.bgInput;
    _mmCtx.fillRect(0, 0, W, H);

    if (_nodes.length === 0) return;

    const pad = 10;
    const bw = _layoutBounds.width || 1;
    const bh = _layoutBounds.height || 1;
    const sx = (W - pad * 2) / bw;
    const sy = (H - pad * 2) / bh;
    const s = Math.min(sx, sy);
    const ox = W / 2 - (_layoutBounds.minX + bw / 2) * s;
    const oy = H / 2 - (_layoutBounds.minY + bh / 2) * s;

    // Draw all nodes as tiny dots (minimap is small, performance is OK)
    for (const n of _nodes) {
      if (!n.visible) continue;
      const x = ox + n.x * s;
      const y = oy + n.y * s;
      const color = _branchColorFor(n.person) || (n.person.gender === 'female' ? theme.female : theme.male);
      _mmCtx.fillStyle = color;
      const r = n.isRoot ? 2.5 : 0.8;
      _mmCtx.globalAlpha = 0.85;
      _mmCtx.beginPath();
      _mmCtx.arc(x, y, r, 0, 2 * Math.PI);
      _mmCtx.fill();
    }
    _mmCtx.globalAlpha = 1;

    // Viewport rectangle
    const canvasW = _canvas.width / _dpr;
    const canvasH = _canvas.height / _dpr;
    const vw = canvasW / _scale;
    const vh = canvasH / _scale;
    const vx = -_offsetX / _scale - vw / 2;
    const vy = -_offsetY / _scale - vh / 2;
    const vpX = ox + vx * s;
    const vpY = oy + vy * s;
    const vpW = vw * s;
    const vpH = vh * s;

    const vpEl = document.getElementById('tree2-minimap-viewport');
    if (vpEl) {
      const parentRect = _mmCanvas.getBoundingClientRect();
      const wrapRect = _mmCanvas.parentElement.getBoundingClientRect();
      vpEl.style.left = (parentRect.left - wrapRect.left + vpX) + 'px';
      vpEl.style.top = (parentRect.top - wrapRect.top + vpY) + 'px';
      vpEl.style.width = Math.max(8, vpW) + 'px';
      vpEl.style.height = Math.max(8, vpH) + 'px';
    }

    const cntEl = document.getElementById('t2-minimap-count');
    if (cntEl) cntEl.textContent = `${_nodes.length} ${i18n.t('tree2.people') || 'точек'}`;
  }

  function _minimapToWorld(clientX, clientY) {
    const rect = _mmCanvas.getBoundingClientRect();
    const W = _mmCanvas.width;
    const H = _mmCanvas.height;
    const px = (clientX - rect.left) * (W / rect.width);
    const py = (clientY - rect.top) * (H / rect.height);

    const pad = 10;
    const bw = _layoutBounds.width || 1;
    const bh = _layoutBounds.height || 1;
    const sx = (W - pad * 2) / bw;
    const sy = (H - pad * 2) / bh;
    const s = Math.min(sx, sy);
    const ox = W / 2 - (_layoutBounds.minX + bw / 2) * s;
    const oy = H / 2 - (_layoutBounds.minY + bh / 2) * s;

    return { x: (px - ox) / s, y: (py - oy) / s };
  }

  function _onMinimapClick(e) {
    const { x, y } = _minimapToWorld(e.clientX, e.clientY);
    _targetOffsetX = -x * _scale;
    _targetOffsetY = -y * _scale;
    _animate();
  }

  function _onMinimapMouseDown(e) {
    _isMinimapDrag = true;
    _onMinimapClick(e);
    e.preventDefault();
  }

  function _onMinimapMouseMove(e) {
    if (_isMinimapDrag) _onMinimapClick(e);
  }

  function _onMinimapMouseUp() { _isMinimapDrag = false; }

  // ============================================================
  // INTERACTION
  // ============================================================
  function _onCanvasMouseDown(e) {
    if (e.button === 2) return;
    _isPanning = true;
    _lastMouseX = e.clientX;
    _lastMouseY = e.clientY;
    _canvas.classList.add('grabbing');
    _hideContextMenu();
  }

  function _onCanvasMouseMove(e) {
    if (_isPanning) {
      _offsetX += (e.clientX - _lastMouseX);
      _offsetY += (e.clientY - _lastMouseY);
      _targetOffsetX = _offsetX;
      _targetOffsetY = _offsetY;
      _lastMouseX = e.clientX;
      _lastMouseY = e.clientY;
      _scheduleRedraw();
    } else {
      _handleHover(e);
    }
  }

  function _onCanvasMouseUp() {
    _isPanning = false;
    _canvas.classList.remove('grabbing');
  }

  function _onCanvasClick(e) {
    if (e.button !== 0) return;
    const node = _pickNode(e);
    if (node) {
      if (node.isFolder) {
        if (_expandedFolders.has(node.id)) {
          _expandedFolders.delete(node.id);
          if (_expandedFolderId === node.id) _expandedFolderId = null;
        } else {
          _expandedFolders.add(node.id);
          _expandedFolderId = node.id;
        }
        // recompute layout so newly-shown children get proper space
        _layoutDirty = true;
        _scheduleRedraw();
      } else {
        // clicking a card toggles connection highlighting AND syncs the
        // selection to app.selectedPersonId so other modes (tree v1, cards,
        // table) inherit the selection when the user switches views.
        // NO detail panel opens on plain left-click (use right-click → "Open card"
        // for that). Second click on the SAME card clears everything.
        if (_selectedNodeId === node.id) {
          // Same card → toggle off
          _selectedNodeId = null;
          _highlightSet = null;
          _highlightedLinks = null;
          _directConnectionSet = null;  // v80 #2: reset direct connections
          _visibilityDirty = true;
          // Sync to app: clear selection too
          if (typeof app !== 'undefined') {
            app.selectedPersonId = null;
            app.highlightedIds = new Set();
            app.dimmed = false;
          }
        } else {
          // New card → compute highlight set
          _selectedNodeId = node.id;
          _computeHighlightSet(node.id);
          _directConnectionSet = null;  // v80 #2: force rebuild for new selection
          _visibilityDirty = true;
          // v75 #4: center on the clicked card so it's at the center of the screen
          _targetOffsetX = -node.x * _targetScale;
          _targetOffsetY = -node.y * _targetScale;
          // Sync to app: set selectedPersonId + highlightedIds (without opening panel)
          if (typeof app !== 'undefined') {
            app.selectedPersonId = node.id;
            app.highlightedIds = new Set(_highlightSet);
            app.dimmed = true;
          }
          _animate();
        }
        _scheduleRedraw();
      }
    }
  }

  // compute the set of nodes and links to highlight for a given person.
  //   Highlighted nodes ("family level"): selected person + their parents +
  //   their spouse(s) + their children (own or shared with spouse) +
  //   their grandchildren (children of children).
  //   Highlighted links: parent→child links between any two highlighted nodes,
  //   PLUS marriage (pink dashed) links between the selected person and spouse(s).
  function _computeHighlightSet(pid) {
    if (!_data) return;
    const links = _data.links || [];
    const nodeSet = new Set([pid]);
    const linkList = [];

    // Parents (1 generation up)
    const parents = (links.filter(l =>
      l.type === 'parent_child' && l.target === pid && l.source !== pid
    )).map(l => l.source);
    parents.forEach(p => {
      nodeSet.add(p);
      linkList.push({ kind: 'parent', source: p, target: pid });
    });

    // Spouse(s) + marriage (pink dashed) links
    const spouses = dataModule.getSpouses(links, pid);
    spouses.forEach(s => {
      nodeSet.add(s);
      // Find the marriage link object (for divorced flag)
      const m = _marriages.find(mm =>
        (mm.a === pid && mm.b === s) || (mm.a === s && mm.b === pid)
      );
      linkList.push({ kind: 'marriage', source: pid, target: s, divorced: m ? m.divorced : false });
    });

    // Children (1 generation down) — own children + children shared with spouse
    // (in this data model, every parent_child link from pid counts, regardless
    // of whether the other parent is the spouse).
    const children = (links.filter(l =>
      l.type === 'parent_child' && l.source === pid && l.target !== pid
    )).map(l => l.target);
    children.forEach(c => {
      nodeSet.add(c);
      linkList.push({ kind: 'parent', source: pid, target: c });
    });
    // Also include children of the spouse (shared or step-children)
    spouses.forEach(s => {
      const spouseChildren = (links.filter(l =>
        l.type === 'parent_child' && l.source === s && l.target !== s && l.target !== pid
      )).map(l => l.target);
      spouseChildren.forEach(c => {
        if (!nodeSet.has(c)) {
          nodeSet.add(c);
          linkList.push({ kind: 'parent', source: s, target: c });
        }
      });
    });

    // Grandchildren (children of children)
    children.forEach(c => {
      const grandKids = (links.filter(l =>
        l.type === 'parent_child' && l.source === c && l.target !== c
      )).map(l => l.target);
      grandKids.forEach(g => {
        nodeSet.add(g);
        linkList.push({ kind: 'parent', source: c, target: g });
      });
    });

    // v83 #2: Siblings — add sibling links to highlighted links so they are
    // drawn as blue curved lines when a person is selected.
    const siblings = dataModule.getSiblings(links, pid);
    siblings.forEach(s => {
      if (!nodeSet.has(s)) nodeSet.add(s);
      linkList.push({ kind: 'sibling', source: pid, target: s });
    });

    _highlightSet = nodeSet;
    _highlightedLinks = linkList;
  }

  function _onCanvasContextMenu(e) {
    e.preventDefault();
    const node = _pickNode(e);
    if (!node) { _hideContextMenu(); return; }
    // don't auto-select on right-click — leave selection as-is so the
    // user can toggle items in the menu without losing their current selection.
    _showContextMenu(node, e);
    _scheduleRedraw();
  }

  function _onCanvasWheel(e) {
    e.preventDefault();
    const rect = _canvas.getBoundingClientRect();
    const mx = e.clientX - rect.left;
    const my = e.clientY - rect.top;
    const worldX = (mx - _canvas.width / _dpr / 2 - _offsetX) / _scale;
    const worldY = (my - _canvas.height / _dpr / 2 - _offsetY) / _scale;

    const factor = e.deltaY < 0 ? 1.15 : 1 / 1.15;
    const newScale = Math.max(MIN_SCALE, Math.min(MAX_SCALE, _scale * factor));
    _targetScale = newScale;

    const newOffsetX = mx - _canvas.width / _dpr / 2 - worldX * newScale;
    const newOffsetY = my - _canvas.height / _dpr / 2 - worldY * newScale;
    _targetOffsetX = newOffsetX;
    _targetOffsetY = newOffsetY;
    _animate();
  }

  function _pickNode(e) {
    const rect = _canvas.getBoundingClientRect();
    const mx = e.clientX - rect.left;
    const my = e.clientY - rect.top;
    const wx = (mx - _canvas.width / _dpr / 2 - _offsetX) / _scale;
    const wy = (my - _canvas.height / _dpr / 2 - _offsetY) / _scale;
    const level = _getZoomLevel();
    // Circle hit detection — use radius
    const hitR = level === 'satellite' ? 10 : (_effectiveCircleR + 6);
    // Iterate ALL nodes (not just visible) so hover/click works on
    // any circle on screen, including those culled by viewport but still drawn
    // (e.g. highlighted nodes outside viewport).
    let best = null, bestDist = Infinity;
    // Use viewport rect to filter — only check nodes near the cursor
    const r = _getVisibleWorldRect();
    for (const n of _nodes) {
      // Quick bounds check — skip nodes far from viewport
      if (n.x < r.minX - hitR || n.x > r.maxX + hitR) continue;
      if (n.y < r.minY - hitR || n.y > r.maxY + hitR) continue;
      // Circle hit test — distance from center <= radius
      const dx = n.x - wx;
      const dy = n.y - wy;
      const d = Math.sqrt(dx * dx + dy * dy);
      if (d > hitR) continue;
      if (d < bestDist) {
        bestDist = d;
        best = n;
      }
    }
    return best;
  }

  function _handleHover(e) {
    // v73 #5: throttle hover handler — avoid running pick+innerHTML on every
    // mousemove (can be 100+ events/sec on fast movement). 30ms throttle =
    // ~33 updates/sec, smooth enough for tooltip.
    const now = performance.now();
    if (now - _lastHoverTime < 30) {
      // Still update tooltip position (cheap) but skip re-pick + innerHTML
      const tip = document.getElementById('tree2-tooltip');
      if (tip && tip.style.display === 'block') {
        const rect = _wrap.getBoundingClientRect();
        tip.style.left = (e.clientX - rect.left + 12) + 'px';
        tip.style.top = (e.clientY - rect.top + 12) + 'px';
      }
      return;
    }
    _lastHoverTime = now;

    const node = _pickNode(e);
    const tip = document.getElementById('tree2-tooltip');
    if (!tip) return;
    if (node !== _hoveredNode) {
      _hoveredNode = node;
    }
    if (node) {
      const p = node.person;
      // v73 #1: escape user-controlled name to prevent XSS in tooltip
      const name = dataModule.escapeHtml(dataModule.getFullName(p));
      const years = dataModule.escapeHtml(_formatYears(p));
      const genLabel = dataModule.escapeHtml(i18n.t('tree2.gen'));
      const childLabel = dataModule.escapeHtml(i18n.t('tree2.children'));
      tip.innerHTML = `<b>${name}</b><br>${years} · ${genLabel} ${node.gen + 1}${node.isFolder ? ` · ${node.childCount} ${childLabel}` : ''}`;
      tip.style.display = 'block';
      const rect = _wrap.getBoundingClientRect();
      tip.style.left = (e.clientX - rect.left + 12) + 'px';
      tip.style.top = (e.clientY - rect.top + 12) + 'px';
    } else {
      tip.style.display = 'none';
    }
  }

  // ============================================================
  // CONTEXT MENU
  // ============================================================
  function _showContextMenu(node, e) {
    const menu = document.getElementById('tree2-context-menu');
    if (!menu) return;
    const p = node.person;
    // v101 FIX С1: escape user-controlled strings to prevent XSS
    const name = dataModule.escapeHtml(dataModule.getFullName(p));
    const years = dataModule.escapeHtml(_formatYears(p));
    const descCount = dataModule.getDescendants(_data.links, node.id, new Set(), false).size;
    const ancCount = dataModule.getAncestors(_data.links, node.id, new Set()).size;
    const sibCount = dataModule.getSiblings(_data.links, node.id).length;
    const spCount = (dataModule.getSpouses(_data.links, node.id) || []).length;
    const t = (k) => i18n.t(k);

    menu.innerHTML = `
      <div class="t2-ctx-header">
        <div class="t2-ctx-name">${name}</div>
        <div class="t2-ctx-meta">${years} · ${i18n.t('tree2.gen')} ${node.gen + 1}</div>
      </div>
      <div class="t2-ctx-item" data-action="descendants">
        <span class="t2-ctx-icon">🌳</span>${t('tree2.showDescendants')}
        <span class="t2-ctx-count">${descCount}</span>
      </div>
      <div class="t2-ctx-item" data-action="ancestors">
        <span class="t2-ctx-icon">⬆️</span>${t('tree2.showAncestors')}
        <span class="t2-ctx-count">${ancCount}</span>
      </div>
      <div class="t2-ctx-item" data-action="siblings">
        <span class="t2-ctx-icon">👥</span>${t('tree2.showSiblings')}
        <span class="t2-ctx-count">${sibCount}</span>
      </div>
      <div class="t2-ctx-item" data-action="spouses">
        <span class="t2-ctx-icon">💑</span>${t('tree2.showSpousesMenu')}
        <span class="t2-ctx-count">${spCount}</span>
      </div>
      <div class="t2-ctx-divider"></div>
      <div class="t2-ctx-item" data-action="center">
        <span class="t2-ctx-icon">🎯</span>${t('tree2.makeCenter')}
      </div>
      <div class="t2-ctx-item" data-action="card">
        <span class="t2-ctx-icon">📄</span>${t('tree2.openCard')}
      </div>
      <div class="t2-ctx-divider"></div>
      <div class="t2-ctx-item" data-action="reset">
        <span class="t2-ctx-icon">↺</span>Сбросить фокус
      </div>
    `;
    menu.style.display = 'block';
    const rect = _wrap.getBoundingClientRect();
    let mx = e.clientX - rect.left;
    let my = e.clientY - rect.top;
    const mw = 280, mh = 320;
    if (mx + mw > rect.width) mx = rect.width - mw - 8;
    if (my + mh > rect.height) my = rect.height - mh - 8;
    menu.style.left = mx + 'px';
    menu.style.top = my + 'px';

    menu.querySelectorAll('.t2-ctx-item').forEach(item => {
      item.onclick = () => {
        _handleContextAction(item.getAttribute('data-action'), node);
        _hideContextMenu();
      };
    });
  }

  function _hideContextMenu() {
    const menu = document.getElementById('tree2-context-menu');
    if (menu) menu.style.display = 'none';
  }

  // All context-menu actions are TOGGLES.
  //   - "Show descendants/ancestors/siblings/spouses": first click focuses the
  //     map on that person's relatives; second click on the same person+action
  //     clears the focus and shows the full tree again.
  //   - "Make center": centers the map on the node. Repeated click re-centers
  //     (idempotent — always re-centers, never toggles off).
  //   - "Open card": opens the right-side detail panel. Repeated click on the
  //     same person closes the panel.
  //   - "Reset": clears all focus/selection/highlight state.
  function _handleContextAction(action, node) {
    switch (action) {
      case 'descendants':
        if (_focusPersonId === node.id && _focusMode === 'descendants') {
          // Toggle OFF
          _focusPersonId = null;
          _focusMode = null;
        } else {
          _focusPersonId = node.id;
          _focusMode = 'descendants';
          _targetOffsetX = -node.x * _targetScale;
          _targetOffsetY = -node.y * _targetScale;
        }
        _layoutDirty = true;
        _animate();
        break;
      case 'ancestors':
        if (_focusPersonId === node.id && _focusMode === 'ancestors') {
          // Toggle OFF
          _focusPersonId = null;
          _focusMode = null;
        } else {
          _focusPersonId = node.id;
          _focusMode = 'ancestors';
          _targetOffsetX = -node.x * _targetScale;
          _targetOffsetY = -node.y * _targetScale;
        }
        _layoutDirty = true;
        _animate();
        break;
      case 'siblings':
        if (_focusPersonId === node.id && _focusMode === 'siblings') {
          _focusPersonId = null;
          _focusMode = null;
        } else {
          _focusPersonId = node.id;
          _focusMode = 'siblings';
          _targetOffsetX = -node.x * _targetScale;
          _targetOffsetY = -node.y * _targetScale;
        }
        _layoutDirty = true;
        _animate();
        break;
      case 'spouses':
        if (_focusPersonId === node.id && _focusMode === 'spouses') {
          _focusPersonId = null;
          _focusMode = null;
        } else {
          _focusPersonId = node.id;
          _focusMode = 'spouses';
          _targetOffsetX = -node.x * _targetScale;
          _targetOffsetY = -node.y * _targetScale;
        }
        _layoutDirty = true;
        _animate();
        break;
      case 'center':
        // "Make center" is idempotent — always re-centers on the node.
        // Clear any focus filter so the whole tree is shown, then pan to node.
        _focusPersonId = null;
        _focusMode = null;
        _layoutDirty = true;
        _targetOffsetX = -node.x * _targetScale;
        _targetOffsetY = -node.y * _targetScale;
        _animate();
        break;
      case 'card':
        // "Open card" ALWAYS opens the detail panel (never closes it).
        // Works regardless of whether the card is already selected/highlighted.
        // To close the panel, use the ✕ button or "Reset focus".
        if (typeof app !== 'undefined') {
          _selectedNodeId = node.id;
          _computeHighlightSet(node.id);
          app.selectedPersonId = node.id;
          app._highlightChain(node.id);
          app._openPersonPanel(node.id);
          app.render();
        }
        _scheduleRedraw();
        break;
      case 'reset':
        _focusPersonId = null;
        _focusMode = null;
        _selectedNodeId = null;
        _highlightSet = null;
        _highlightedLinks = null;
        _layoutDirty = true;
        if (typeof app !== 'undefined') {
          app.selectedPersonId = null;
          app.highlightedIds = new Set();
          app.dimmed = false;
          app.closePanel();
          app.render();
        }
        _scheduleRedraw();
        break;
    }
  }

  // ============================================================
  // SIDEBAR
  // ============================================================
  function _populateSidebar() {
    _populateBranchesUI();
    _populateModeButtons();
  }

  function _populateBranchesUI() {
    const container = document.getElementById('t2-branches');
    if (!container) return;
    container.innerHTML = '';
    _branches.forEach(br => {
      const div = document.createElement('div');
      div.className = 't2-branch' + (_hiddenBranches.has(br.id) ? '' : ' active');
      div.innerHTML = `
        <span class="t2-branch-dot" style="background:${br.color}"></span>
        <span class="t2-branch-name">${br.name === '—' ? (i18n.t('tree2.noData') || '—') : br.name}</span>
        <span class="t2-branch-count">${br.count}</span>
      `;
      div.onclick = () => {
        if (_hiddenBranches.has(br.id)) _hiddenBranches.delete(br.id);
        else _hiddenBranches.add(br.id);
        _populateBranchesUI();
        _visibilityDirty = true;
        _scheduleRedraw();
      };
      container.appendChild(div);
    });
  }

  function _populateModeButtons() {
    const container = document.getElementById('t2-mode-buttons');
    if (!container) return;
    const modes = [
      { id: 'full',       icon: '🌲', label: i18n.t('tree2.modeFull')       || 'Полное дерево' },
      { id: 'folder',     icon: '📁', label: i18n.t('tree2.modeFolder')     || 'Папка' },
      { id: 'descendants',icon: '🌳', label: i18n.t('tree2.modeDescendants')|| 'Потомки' },
    ];
    container.innerHTML = modes.map(m => `
      <button class="t2-mode-btn ${_viewMode === m.id ? 'active' : ''}" data-mode="${m.id}">
        <span class="t2-mode-icon">${m.icon}</span>
        <span class="t2-mode-label">${m.label}</span>
      </button>
    `).join('');
    container.querySelectorAll('.t2-mode-btn').forEach(btn => {
      btn.onclick = () => {
        _viewMode = btn.getAttribute('data-mode');
        if (_viewMode !== 'descendants') {
          _focusPersonId = null;
          _focusMode = null;
        } else if (!_selectedNodeId && _rootIds.length > 0) {
          _selectedNodeId = _rootIds[0];
        }
        // Mode change affects layout (folder mode hides children)
        _layoutDirty = true;
        _populateModeButtons();
        _scheduleRedraw();
      };
    });
  }

  function _updateModeUI(level) {
    const titleEl = document.getElementById('t2-mode-title');
    const descEl = document.getElementById('t2-mode-desc');
    const zoomEl = document.getElementById('t2-zoom-level');
    if (!titleEl || !descEl) return;
    if (level === 'satellite') {
      titleEl.textContent = i18n.t('tree2.modeSatellite');
      descEl.textContent = i18n.t('tree2.modeSatDesc');
    } else if (level === 'structural') {
      titleEl.textContent = i18n.t('tree2.modeStruct');
      descEl.textContent = i18n.t('tree2.modeStructDesc');
    } else {
      titleEl.textContent = i18n.t('tree2.modeWork');
      descEl.textContent = i18n.t('tree2.modeWorkDesc');
    }
    if (zoomEl) zoomEl.textContent = Math.round(_scale * 100) + '%';
  }

  function _updateModeBanner() {
    const banner = document.getElementById('tree2-mode-banner');
    if (!banner) return;
    const labelEl = banner.querySelector('.t2-banner-label');
    const titleEl = banner.querySelector('.t2-banner-title');
    const descEl  = banner.querySelector('.t2-banner-desc');
    if (!labelEl || !titleEl || !descEl) return;

    let label = (i18n.t('tree2.mode') || 'Режим').toUpperCase();
    let title = '';
    let desc = '';
    let cls = 't2-banner-info';

    if (_viewMode === 'folder') {
      if (_expandedFolderId && _expandedFolders.has(_expandedFolderId)) {
        label = (i18n.t('tree2.folderExpanded') || 'Папка развернута').toUpperCase();
        title = i18n.t('tree2.folderExpandedTitle') || 'Папка развернута';
        desc = i18n.t('tree2.folderExpandedDesc') || 'Главная ветвь раскрыта. Видно детей и их потомков. Остальные ветви остаются папками.';
        cls = 't2-banner-success';
      } else {
        label = (i18n.t('tree2.folderMode') || 'Режим «Папка»').toUpperCase();
        title = i18n.t('tree2.folderModeTitle') || 'Режим «Папка»';
        desc = i18n.t('tree2.folderModeDesc') || 'Ветви с >3 детей свёрнуты в узлы [+N детей]. Кликните по узлу, чтобы развернуть.';
        cls = 't2-banner-warning';
      }
    } else if (_viewMode === 'descendants') {
      if (_selectedNodeId) {
        const p = _personsById.get(_selectedNodeId);
        if (p) {
          label = (i18n.t('tree2.descendantsMode') || 'Режим «Потомки»').toUpperCase();
          title = i18n.t('tree2.descendantsModeTitle') || 'Режим «Потомки»';
          const descCount = dataModule.getDescendants(_data.links, _selectedNodeId, new Set(), false).size;
          desc = (i18n.t('tree2.descendantsModeDesc') || 'Показаны потомки выбранного человека и их супруги.') + ` (${descCount})`;
          cls = 't2-banner-info';
        }
      } else {
        label = (i18n.t('tree2.descendantsMode') || 'Режим «Потомки»').toUpperCase();
        title = i18n.t('tree2.descendantsModeTitle') || 'Режим «Потомки»';
        desc = i18n.t('tree2.descHint') || 'Выберите человека на карте, чтобы увидеть его потомков.';
        cls = 't2-banner-info';
      }
    } else {
      if (_depthLimit < 10) {
        label = (i18n.t('tree2.filterActive') || 'Фильтр активен').toUpperCase();
        title = i18n.t('tree2.filterActiveTitle') || 'Фильтр активен';
        desc = (i18n.t('tree2.filterActiveDesc') || 'Затенены поколения') + ' ' + (_depthLimit + 1) + '-10. ' + (i18n.t('tree2.filterActiveHint') || 'Ползунок глубины');
        cls = 't2-banner-warning';
      } else {
        label = (i18n.t('tree2.fullMode') || 'Полное дерево').toUpperCase();
        title = i18n.t('tree2.fullModeTitle') || 'Полное дерево';
        desc = i18n.t('tree2.fullModeDesc') || 'Все поколения, все люди. Используйте папки для разгрузки.';
        cls = 't2-banner-info';
      }
    }

    labelEl.textContent = label;
    titleEl.textContent = title;
    descEl.textContent = desc;
    banner.className = '';
    banner.classList.add(cls);
  }

  // ============================================================
  // ANIMATION + SCHEDULING
  // ============================================================
  let _animFrame = null;
  function _animate() {
    if (_animFrame) cancelAnimationFrame(_animFrame);
    const step = () => {
      const lerp = 0.25;
      const dS = _targetScale - _scale;
      const dX = _targetOffsetX - _offsetX;
      const dY = _targetOffsetY - _offsetY;
      if (Math.abs(dS) < 0.001 && Math.abs(dX) < 0.5 && Math.abs(dY) < 0.5) {
        _scale = _targetScale;
        _offsetX = _targetOffsetX;
        _offsetY = _targetOffsetY;
        _draw();
        _animFrame = null;
        return;
      }
      _scale += dS * lerp;
      _offsetX += dX * lerp;
      _offsetY += dY * lerp;
      _draw();
      _animFrame = requestAnimationFrame(step);
    };
    _animFrame = requestAnimationFrame(step);
  }

  function _scheduleRedraw() {
    if (_redrawScheduled) return;
    _redrawScheduled = true;
    requestAnimationFrame(() => {
      _redrawScheduled = false;
      _draw();
    });
  }

  // ============================================================
  // RESIZE
  // ============================================================
  function handleResize() {
    if (!_canvas) return;
    _resizeCanvas();
    _scheduleRedraw();
  }

  function _resizeCanvas() {
    if (!_canvas || !_wrap) return;
    let rect = _wrap.getBoundingClientRect();
    // If wrap has zero size (display:none ancestor, etc.), fall back to
    // window dimensions. Without this, _resizeCanvas creates a 0×0 canvas and
    // the tree never renders — which was the cause of the "demo button shows
    // blank tree" bug. We then re-trigger a resize on the next frame.
    let w = rect.width, h = rect.height;
    if (w < 10 || h < 10) {
      w = window.innerWidth  - 40;
      h = window.innerHeight - 80;
      if (w < 100) w = 1000;
      if (h < 100) h = 600;
      // Schedule another resize shortly — wrap may become measurable soon
      setTimeout(() => { _resizeCanvas(); _scheduleRedraw(); }, 50);
    }
    _dpr = window.devicePixelRatio || 1;
    _canvas.width  = w * _dpr;
    _canvas.height = h * _dpr;
    _canvas.style.width  = w + 'px';
    _canvas.style.height = h + 'px';
    _ctx.setTransform(1, 0, 0, 1, 0, 0);
    _ctx.scale(_dpr, _dpr);
  }

  // ============================================================
  // PUBLIC API
  // ============================================================
  function attach(data, familyColors) {
    _canvas = document.getElementById('tree2-canvas');
    _mmCanvas = document.getElementById('tree2-minimap-canvas');
    _wrap = document.getElementById('tree2-canvas-wrap');
    _sidebar = document.getElementById('tree2-sidebar');
    if (!_canvas || !_mmCanvas || !_wrap) return;

    _ctx = _canvas.getContext('2d');
    _mmCtx = _mmCanvas.getContext('2d');

    setData(data, familyColors);

    _resizeCanvas();

    if (!_canvas._t2wired) {
      _canvas._t2wired = true;
      _canvas.addEventListener('mousedown', _onCanvasMouseDown);
      _canvas.addEventListener('mousemove', _onCanvasMouseMove);
      _canvas.addEventListener('mouseup', _onCanvasMouseUp);
      _canvas.addEventListener('mouseleave', () => {
        _isPanning = false;
        _canvas.classList.remove('grabbing');
        const tip = document.getElementById('tree2-tooltip');
        if (tip) tip.style.display = 'none';
      });
      _canvas.addEventListener('click', _onCanvasClick);
      _canvas.addEventListener('contextmenu', _onCanvasContextMenu);
      _canvas.addEventListener('wheel', _onCanvasWheel, { passive: false });

      // Touch
      let lastTouchDist = 0;
      _canvas.addEventListener('touchstart', (e) => {
        if (e.touches.length === 1) {
          _isPanning = true;
          _lastMouseX = e.touches[0].clientX;
          _lastMouseY = e.touches[0].clientY;
        } else if (e.touches.length === 2) {
          const dx = e.touches[0].clientX - e.touches[1].clientX;
          const dy = e.touches[0].clientY - e.touches[1].clientY;
          lastTouchDist = Math.sqrt(dx * dx + dy * dy);
        }
      }, { passive: true });
      // v73 #16: passive:false is required here because we call preventDefault().
      // However, we only preventDefault when _isPanning (single touch pan) or
      // 2-finger pinch — so native scrolling still works when not interacting.
      // Combined with CSS `touch-action: none` on #tree2-canvas, this prevents
      // scroll-jank on mobile while allowing page scroll outside the canvas.
      _canvas.addEventListener('touchmove', (e) => {
        if (e.touches.length === 1 && _isPanning) {
          // v73 #16: preventDefault ONLY when actually panning — let page scroll otherwise
          if (e.cancelable) e.preventDefault();
          _offsetX += (e.touches[0].clientX - _lastMouseX);
          _offsetY += (e.touches[0].clientY - _lastMouseY);
          _targetOffsetX = _offsetX;
          _targetOffsetY = _offsetY;
          _lastMouseX = e.touches[0].clientX;
          _lastMouseY = e.touches[0].clientY;
          _scheduleRedraw();
        } else if (e.touches.length === 2) {
          if (e.cancelable) e.preventDefault();
          const dx = e.touches[0].clientX - e.touches[1].clientX;
          const dy = e.touches[0].clientY - e.touches[1].clientY;
          const dist = Math.sqrt(dx * dx + dy * dy);
          // v101 FIX Б7: Guard against division by zero in touch-pinch
          if (lastTouchDist > 0) {
            const factor = dist / lastTouchDist;
            _targetScale = Math.max(MIN_SCALE, Math.min(MAX_SCALE, _scale * factor));
            _scale = _targetScale;
          }
          lastTouchDist = dist;
          _scheduleRedraw();
        }
      }, { passive: false });
      _canvas.addEventListener('touchend', () => { _isPanning = false; });

      // Minimap events
      _mmCanvas.addEventListener('mousedown', _onMinimapMouseDown);
      window.addEventListener('mousemove', _onMinimapMouseMove);
      window.addEventListener('mouseup', _onMinimapMouseUp);

      // Click outside context menu to close
      document.addEventListener('click', (e) => {
        const menu = document.getElementById('tree2-context-menu');
        if (menu && menu.style.display === 'block' && !menu.contains(e.target)) {
          _hideContextMenu();
        }
      });

      // Sidebar controls
      const depthSlider = document.getElementById('t2-depth-slider');
      const depthValue = document.getElementById('t2-depth-value');
      if (depthSlider) {
        depthSlider.addEventListener('input', () => {
          _depthLimit = parseInt(depthSlider.value);
          if (depthValue) depthValue.textContent = _depthLimit;
          _layoutDirty = true;
          _scheduleRedraw();
        });
      }
      const cbSpouses = document.getElementById('t2-filter-spouses');
      if (cbSpouses) cbSpouses.addEventListener('change', () => {
        _showSpouses = cbSpouses.checked;
        _layoutDirty = true;
        _scheduleRedraw();
      });
      const cbCollapse = document.getElementById('t2-filter-collapse');
      if (cbCollapse) cbCollapse.addEventListener('change', () => {
        _autoCollapse = cbCollapse.checked;
        _layoutDirty = true;
        _scheduleRedraw();
      });
      const cbAlive = document.getElementById('t2-filter-alive');
      if (cbAlive) cbAlive.addEventListener('change', () => {
        _aliveOnly = cbAlive.checked;
        _visibilityDirty = true;
        _scheduleRedraw();
      });
      const cbDivorced = document.getElementById('t2-filter-divorced');
      if (cbDivorced) cbDivorced.addEventListener('change', () => {
        _hideDivorced = cbDivorced.checked;
        _visibilityDirty = true;
        _scheduleRedraw();
      });

      // Quick presets
      const presetAnc = document.getElementById('t2-preset-ancestors');
      if (presetAnc) presetAnc.onclick = () => {
        _depthLimit = 3;
        if (depthSlider) depthSlider.value = 3;
        if (depthValue) depthValue.textContent = 3;
        _viewMode = 'full';
        _layoutDirty = true;
        _populateModeButtons();
        _scheduleRedraw();
      };
      const presetDesc = document.getElementById('t2-preset-descendants');
      if (presetDesc) presetDesc.onclick = () => {
        _depthLimit = 5;
        if (depthSlider) depthSlider.value = 5;
        if (depthValue) depthValue.textContent = 5;
        _viewMode = 'descendants';
        if (!_selectedNodeId && _rootIds.length > 0) _selectedNodeId = _rootIds[0];
        _layoutDirty = true;
        _populateModeButtons();
        _scheduleRedraw();
      };
      const presetFull = document.getElementById('t2-preset-full');
      if (presetFull) presetFull.onclick = () => {
        _depthLimit = 10;
        if (depthSlider) depthSlider.value = 10;
        if (depthValue) depthValue.textContent = 10;
        _viewMode = 'full';
        _focusPersonId = null;
        _focusMode = null;
        _layoutDirty = true;
        _populateModeButtons();
        _scheduleRedraw();
      };

      // Expand all / collapse all folders
      const expandAllBtn = document.getElementById('t2-expand-all');
      if (expandAllBtn) expandAllBtn.onclick = () => {
        _nodes.forEach(n => {
          if (n.childCount > FOLDER_THRESHOLD) {
            _expandedFolders.add(n.id);
            _expandedFolderId = n.id;
          }
        });
        _layoutDirty = true;
        _scheduleRedraw();
      };
      const collapseAllBtn = document.getElementById('t2-collapse-all');
      if (collapseAllBtn) collapseAllBtn.onclick = () => {
        _expandedFolders.clear();
        _expandedFolderId = null;
        _layoutDirty = true;
        _scheduleRedraw();
      };

      window.addEventListener('resize', _resizeCanvas);
    }

    // v74 #1: default to "working 100%" zoom (scale=1.0) instead of fit-to-screen.
    // User explicitly requested cards at their natural size on initial load.
    // v76 #2: if a person is already selected (e.g. switching from cards/table),
    // center on THEM instead of the root — don't override the selection centre.
    if (_selectedNodeId && _nodesById.has(_selectedNodeId)) {
      _setWorkingZoom();  // sets scale=1.0
      _centerOnNode(_nodesById.get(_selectedNodeId));  // override offset to selected
    } else {
      _setWorkingZoom();
    }
    _scheduleRedraw();
    // If wrap was zero-sized at attach time, _resizeCanvas scheduled a
    // retry in 50ms. After that retry, working-zoom must run again so the
    // tree is properly framed. Without this, demo tree could render but stay
    // off-screen / poorly scaled on first load.
    // v76 #2: same logic — preserve selection centre if set.
    setTimeout(() => {
      _resizeCanvas();
      if (_selectedNodeId && _nodesById.has(_selectedNodeId)) {
        _setWorkingZoom();
        _centerOnNode(_nodesById.get(_selectedNodeId));
      } else {
        _setWorkingZoom();
      }
      _scheduleRedraw();
    }, 80);
  }

  function _fitToScreen() {
    if (!_wrap || _nodes.length === 0) return;
    const wrapRect = _wrap.getBoundingClientRect();
    const viewportW = wrapRect.width || 1000;
    const viewportH = wrapRect.height || 700;
    const boundsW = _layoutBounds.width || 1;
    const boundsH = _layoutBounds.height || 1;
    const fitScale = Math.max(MIN_SCALE, Math.min(MAX_SCALE,
      Math.min(viewportW / boundsW, viewportH / boundsH) * 0.9));
    _targetScale = fitScale;
    _scale = fitScale;
    const cx = (_layoutBounds.minX + _layoutBounds.maxX) / 2;
    const cy = (_layoutBounds.minY + _layoutBounds.maxY) / 2;
    _targetOffsetX = -cx * fitScale;
    _targetOffsetY = -cy * fitScale;
    _offsetX = _targetOffsetX;
    _offsetY = _targetOffsetY;
  }

  // v74 #1: set "working 100%" zoom — scale=1.0 (cards at their natural size).
  // v94: default zoom changed to 1.43 (143%) per user request.
  // v100 (запрос пользователя #3): масштаб по умолчанию увеличен до 1.70 (170%) —
  // применяется при каждом переключении в режим «Дерево» (attach → _setWorkingZoom).
  // Centers on the first root node so the user sees the top of the tree.
  const DEFAULT_WORKING_SCALE = 1.70;
  function _setWorkingZoom() {
    if (_nodes.length === 0) return;
    _targetScale = DEFAULT_WORKING_SCALE;
    _scale = DEFAULT_WORKING_SCALE;
    // Center on the first root node (top of the tree)
    const root = _rootIds && _rootIds.length > 0
      ? _nodesById.get(_rootIds[0])
      : _nodes[0];
    if (root) {
      _targetOffsetX = -root.x * _scale;
      _targetOffsetY = -root.y * _scale;
      _offsetX = _targetOffsetX;
      _offsetY = _targetOffsetY;
    }
  }

  // v76 #2: centre the viewport on a specific node (used when a person is
  // selected and we switch into tree2 from cards/table). Sets both target and
  // current offset so there's no animation drift.
  function _centerOnNode(node) {
    if (!node) return;
    _targetOffsetX = -node.x * _targetScale;
    _targetOffsetY = -node.y * _targetScale;
    _offsetX = _targetOffsetX;
    _offsetY = _targetOffsetY;
  }

  function requestRedraw() { _scheduleRedraw(); }

  function zoomBy(factor) {
    _targetScale = Math.max(MIN_SCALE, Math.min(MAX_SCALE, _scale * factor));
    _animate();
  }

  function zoomTo(scale, animate) {
    _targetScale = Math.max(MIN_SCALE, Math.min(MAX_SCALE, scale));
    if (animate) _animate();
    else { _scale = _targetScale; _draw(); }
  }

  function resetView() {
    _focusPersonId = null;
    _focusMode = null;
    _fitToScreen();
    _scheduleRedraw();
  }

  function setSelectedPerson(pid) {
    if (!pid) {
      _selectedNodeId = null;
      _highlightSet = null;
      _highlightedLinks = null;
      _directConnectionSet = null;  // v80 #2: reset
      _visibilityDirty = true;
      _scheduleRedraw();
      return;
    }
    _selectedNodeId = pid;
    // rebuild highlight set so when switching INTO tree2 from another mode
    // (where the user selected a person), tree2 shows the family-level highlight.
    _computeHighlightSet(pid);
    _directConnectionSet = null;  // v80 #2: force rebuild for new selection
    _visibilityDirty = true;
    if (_viewMode === 'descendants' && pid) {
      _focusPersonId = pid;
      _focusMode = 'descendants';
    }
    // v75 #4 / v76 #2: center on the selected person in ALL view modes.
    // Use _centerOnNode so both target and current offset are set — prevents
    // drift when attach()'s setTimeout fires later and overrides target.
    const node = _nodesById.get(pid);
    if (node) {
      _centerOnNode(node);
      _animate();
      return;
    }
    _scheduleRedraw();
  }

  return {
    attach, setData, requestRedraw, handleResize,
    zoomBy, zoomTo, resetView, fitToScreen: _fitToScreen,
    setWorkingZoom: _setWorkingZoom,  // v74 #1: working 100% zoom
    setSelectedPerson,
    // v71: filter status API — 'all' | 'alive' | 'deceased'
    setFilterStatus: (status) => {
      if (status === 'alive') {
        _aliveOnly = true;
        _deceasedOnly = false;
      } else if (status === 'deceased') {
        _aliveOnly = false;
        _deceasedOnly = true;
      } else {
        // 'all' or any other value = no filter
        _aliveOnly = false;
        _deceasedOnly = false;
      }
      // Sync the sidebar checkbox (if present) so UI stays consistent
      const cbAlive = document.getElementById('t2-filter-alive');
      if (cbAlive) cbAlive.checked = _aliveOnly;
      _visibilityDirty = true;
      _scheduleRedraw();
    },
    getFilterStatus: () => {
      if (_aliveOnly) return 'alive';
      if (_deceasedOnly) return 'deceased';
      return 'all';
    },
    // tree orientation API
    getTreeOrientation: () => _treeOrientation,
    toggleTreeOrientation: () => {
      _treeOrientation = _treeOrientation === 'up' ? 'down' : 'up';
      _layoutDirty = true;
      _scheduleRedraw();
    },
    setViewMode: (m) => {
      _viewMode = m;
      if (m !== 'descendants') { _focusPersonId = null; _focusMode = null; }
      else if (!_selectedNodeId && _rootIds.length > 0) _selectedNodeId = _rootIds[0];
      _layoutDirty = true;
      _populateModeButtons();
      _scheduleRedraw();
    },
    expandAllFolders: () => {
      _nodes.forEach(n => {
        if (n.childCount > FOLDER_THRESHOLD) {
          _expandedFolders.add(n.id);
          _expandedFolderId = n.id;
        }
      });
      _layoutDirty = true;
      _scheduleRedraw();
    },
    collapseAllFolders: () => {
      _expandedFolders.clear();
      _expandedFolderId = null;
      _layoutDirty = true;
      _scheduleRedraw();
    },
    _debug: () => ({
      nodesCount: _nodes.length,
      components: _components.length,
      rootIds: _rootIds,
      scale: _scale,
      offsetX: _offsetX,
      offsetY: _offsetY,
      viewMode: _viewMode,
      treeOrientation: _treeOrientation,
      expandedFolders: _expandedFolders.size,
      selectedNodeId: _selectedNodeId,
      focusPersonId: _focusPersonId,
      focusMode: _focusMode,
      bounds: _layoutBounds,
      componentSizes: _components.map(c => c.size),
      visibleNodesCount: _visibleNodesCache ? _visibleNodesCache.length : -1,
      xRange: _nodes.length ? { min: Math.min(..._nodes.map(n => n.x)), max: Math.max(..._nodes.map(n => n.x)) } : null,
      // gen distribution for debugging Y-ordering
      genDist: _nodes.reduce((acc, n) => { const g = n.gen || 0; acc[g] = (acc[g]||0)+1; return acc; }, {}),
      // genRemap info (computed in _computeLayout, stored here for debug)
      _genRemapInfo: _genRemapInfo || null,
      // sample nodes sorted by Y with birth years
      nodesByY: _nodes.map(n => ({ id: n.id, x: Math.round(n.x), y: Math.round(n.y), gen: n.gen, name: n.person.lastName, birthYear: dataModule.getBirthYear(n.person) })).sort((a,b)=>a.y-b.y).slice(0, 15),
      // find specific nodes by ID
      findNode: (id) => { const n = _nodes.find(nn => nn.id === id); return n ? {id: n.id, x: Math.round(n.x), y: Math.round(n.y), gen: n.gen, name: n.person.lastName, birthYear: dataModule.getBirthYear(n.person)} : null; },
      extremeNodes: _nodes.filter(n => Math.abs(n.x) > 5000).slice(0, 5).map(n => ({ id: n.id, x: n.x, y: n.y, name: n.person.lastName })),
      folderNodes: _nodes.filter(n => n.isFolder).slice(0, 5).map(n => ({ id: n.id, x: n.x, y: n.y, childCount: n.childCount, name: n.person.lastName })),
      folderCount: _nodes.filter(n => n.isFolder).length,
      highlightSetSize: _highlightSet ? _highlightSet.size : 0,
      highlightedLinksCount: _highlightedLinks ? _highlightedLinks.length : 0,
      // First 5 visible nodes (for debugging click positions)
      firstVisibleNodes: (_visibleNodesCache || []).slice(0, 5).map(n => ({ id: n.id, x: Math.round(n.x), y: Math.round(n.y), name: n.person.lastName })),
    }),
    _showContextMenuAt: (nodeId, screenX, screenY) => {
      const node = _nodesById.get(nodeId);
      if (!node) return false;
      _showContextMenu(node, { clientX: screenX, clientY: screenY });
      return true;
    },
  };
})();

if (typeof window !== 'undefined') {
  window.tree2 = tree2;
}
