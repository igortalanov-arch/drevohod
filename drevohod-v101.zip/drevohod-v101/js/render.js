// render.js — Tree, Cards, Table rendering + SVG connections
// Drevohod v4.5 Arena Edition

const renderer = {

  // ---- Shared card HTML ----
  personCardHTML(person, options = {}) {
    const {
      selected = false, highlighted = false, dimmed = false,
      familyColors = {}, size = 'normal', label = null, width = null,
      filterHighlight = null  // v78 #3: 'alive' | 'deceased' | null — adds colored border
    } = options;
    const genderClass  = person.gender === 'female' ? 'female' : 'male';
    const statusClass  = person.status || 'unknown';
    const deceasedCls  = person.status === 'deceased' ? 'deceased-card' : '';
    const selectedCls  = selected    ? 'selected'    : '';
    const highlightCls = highlighted ? 'highlighted' : '';
    const dimmedCls    = dimmed      ? 'dimmed'      : '';
    // v78 #3: filter highlight classes for cards mode
    const filterAliveCls    = filterHighlight === 'alive'    ? 'filter-alive'    : '';
    const filterDeceasedCls = filterHighlight === 'deceased' ? 'filter-deceased' : '';
    const familyColor  = person.family ? (familyColors[person.family] || '#888') : 'transparent';
    // v92: Photo rendering — person.photo now stores a FILENAME (not base64).
    // For rendering, we check the in-memory cache (filesystem.getCachedPhotoDataUrlSync).
    // If cached, use the data URL. If not cached but person.photo is a filename,
    // we show a placeholder and trigger async loading.
    // Backward compat: if person.photo starts with "data:", it's old v91 format — use directly.
    let photoSrc = '';
    let hasRealPhoto = false;
    if (person.photo) {
      if (person.photo.startsWith('data:')) {
        // Old v91 format — base64 data URL stored directly
        photoSrc = person.photo;
        hasRealPhoto = true;
      } else if (typeof filesystem !== 'undefined') {
        // v92: person.photo is a filename — check cache for data URL
        // v100 (аудит #5): без isConnected() — работает и через IndexedDB fallback
        const cached = filesystem.getCachedPhotoDataUrlSync(person.id);
        if (cached) {
          photoSrc = cached;
          hasRealPhoto = true;
        } else {
          // Not in cache yet — trigger async load, show placeholder for now.
          // The async load will re-render once the photo is cached.
          app._ensurePhotoCached(person.id);
        }
      }
    }
    const photoClickAttr = hasRealPhoto
      ? `onclick='event.stopPropagation();app.showPhotoFullscreen(${JSON.stringify(person.id)})' style="cursor:zoom-in"`
      : '';
    // v98: add left/right arrows for photo switching if person has multiple photos
    const hasMultiplePhotos = hasRealPhoto && !!(person.photo2 || person.photo3);
    const arrowLeft = hasMultiplePhotos
      ? `<div onclick='event.stopPropagation();app._cyclePhoto(${JSON.stringify(person.id)},-1)' style="position:absolute;left:-8px;top:50%;transform:translateY(-50%);width:24px;height:24px;border-radius:50%;background:var(--accent);color:#fff;display:flex;align-items:center;justify-content:center;cursor:pointer;font-size:14px;z-index:5;box-shadow:0 1px 3px rgba(0,0,0,0.3)">◀</div>`
      : '';
    const arrowRight = hasMultiplePhotos
      ? `<div onclick='event.stopPropagation();app._cyclePhoto(${JSON.stringify(person.id)},1)' style="position:absolute;right:-8px;top:50%;transform:translateY(-50%);width:24px;height:24px;border-radius:50%;background:var(--accent);color:#fff;display:flex;align-items:center;justify-content:center;cursor:pointer;font-size:14px;z-index:5;box-shadow:0 1px 3px rgba(0,0,0,0.3)">▶</div>`
      : '';
    const photoHtml    = hasRealPhoto
      ? `<div style="position:relative;width:100%;height:100%">${arrowLeft}<img src="${photoSrc}" alt="" ${photoClickAttr} style="width:100%;height:100%;object-fit:cover">${arrowRight}</div>`
      : (typeof MALE_ICON !== 'undefined'
          ? `<img src="${person.gender === 'female' ? FEMALE_ICON : MALE_ICON}" alt="" class="gender-icon-img">`
          : (person.gender === 'female' ? '♀' : '♂'));
    const years  = dataModule.formatYears(person);
    const age    = dataModule.calculateAge(person);
    const ageStr = age !== null ? `${i18n.t('card.age')} ${age} ${dataModule.ageWord(age, i18n.currentLang)}` : '';
    const statusIcon = statusClass === 'alive' ? '🍃' : statusClass === 'deceased' ? '✝' : '?';
    const genderIcon = person.gender === 'female' ? '♀' : '♂';
    const cardWidth  = width ? `width:${width}px;` : '';
    const marginTop  = label ? 'margin-top:14px;' : '';
    const labelHtml  = label
      ? `<div style="position:absolute;top:-10px;left:50%;transform:translateX(-50%);background:var(--accent);color:#fff;font-size:11px;padding:2px 10px;border-radius:10px;white-space:nowrap;z-index:10">${label}</div>`
      : '';
    // v94: increased photo size — "almost touching card borders".
    // Was 48/72, now 110/130 for a much more prominent photo.
    const photoSize = size === 'large' ? 130 : 110;
    const fontSize  = size === 'large' ? 16 : 14;

    // FIX #1/#2: card click = open/close detail panel (toggleDetailPanel).
    // In card mode selected card click still opens panel — not re-selects another card.
    // We use toggleDetailPanel for ALL card clicks (not toggleHighlight).
    return `<div class="person-card ${genderClass} ${selectedCls} ${highlightCls} ${dimmedCls} ${deceasedCls} ${filterAliveCls} ${filterDeceasedCls}"
         data-id="${dataModule.escapeHtml(person.id)}"
         data-pid="${dataModule.escapeHtml(person.id)}"
         onclick='app.onCardClick(${JSON.stringify(person.id)})'
         style="border-left:4px solid ${familyColor};${cardWidth}${marginTop}position:relative;cursor:pointer">
      ${labelHtml}
      <span class="card-status ${statusClass}">${statusIcon}</span>
      <span class="card-gender ${genderClass}">${genderIcon}</span>
      <div class="card-top">
        <div class="card-photo" style="width:${photoSize}px;height:${photoSize}px">${photoHtml}</div>
        <div class="card-info">
          <div class="card-name ${genderClass}" style="font-size:${fontSize}px">${dataModule.escapeHtml(dataModule.getFullName(person))}</div>
          <div class="card-years">${years}</div>
          ${ageStr ? `<div class="card-age">${ageStr}</div>` : ''}
        </div>
      </div>
      ${person.family ? `<div class="card-family-bottom">${dataModule.escapeHtml(person.family)}</div>` : ''}
    </div>`;
  },

  // ---- TREE MODE (v5.2: tree v1.0 removed; this function is kept for
  // backward compat but should never be called from app.js). ----
  renderTree(state) {
    // tree v1.0 removed — guard against missing state fields.
    const data = state.data;
    const filterStatus = state.filterStatus;
    const treeFilterPerson = state.treeFilterPerson || null;
    const treeFilterDepth = state.treeFilterDepth || 'all';
    const treeOrientation = state.treeOrientation || 'down';
    const collapsedGenerations = state.collapsedGenerations || new Set();
    const selectedPersonId = state.selectedPersonId;
    const highlightedIds = state.highlightedIds || new Set();
    const dimmed = state.dimmed || false;
    const familyColors = state.familyColors || {};

    const container = document.getElementById('tree-content');
    if (!container) return;  // #tree-content was removed — bail out silently

    let persons = this._getFilteredTreePersons(data, filterStatus, treeFilterPerson, treeFilterDepth);

    // Group by generation
    const generations = {};
    persons.forEach(p => {
      const gen = dataModule.getGeneration(data.persons, data.links, p.id);
      if (!generations[gen]) generations[gen] = [];
      generations[gen].push(p);
    });

    let sortedGens = Object.keys(generations).map(Number).sort((a, b) =>
      treeOrientation === 'up' ? b - a : a - b
    );

    let html = '';
    sortedGens.forEach(gen => {
      const genPersons = generations[gen];
      const genLabel   = dataModule.getGenerationLabel(gen);
      const isCollapsed = collapsedGenerations.has(String(gen));

      html += `<div class="gen-shelf ${isCollapsed ? 'collapsed' : ''}" data-gen="${dataModule.escapeHtml(gen)}">`;
      html += `<div class="gen-header" onclick='app.toggleGeneration(${JSON.stringify(String(gen))})' data-gen="${dataModule.escapeHtml(gen)}">`;
      html += `<span class="gen-chevron">▼</span>`;
      html += `<span class="gen-label">${dataModule.escapeHtml(genLabel)}</span>`;
      html += `<span class="gen-count">${genPersons.length}</span>`;
      html += `</div>`;
      // FIX #4: no carousel arrows; FIX #2: no data-carousel (it was blocking wheel scroll)
      html += `<div class="gen-content">`;

      // Group by family
      const familyGroups = {}, noFamily = [];
      genPersons.forEach(p => {
        if (p.family) {
          if (!familyGroups[p.family]) familyGroups[p.family] = [];
          familyGroups[p.family].push(p);
        } else { noFamily.push(p); }
      });

      // Sort by vertical alignment
      const sortOrder = this._calcVerticalSort(genPersons, data.links);

      Object.keys(familyGroups).sort().forEach(fName => {
        const color = familyColors[fName] || '#888';
        html += `<div class="family-group">`;
        html += `<div class="family-group-header"><span class="family-color-dot" style="background:${color}"></span><span class="family-group-name">${fName}</span></div>`;
        html += `<div class="family-group-cards">`;
        familyGroups[fName].sort((a, b) => (sortOrder[a.id] || 0) - (sortOrder[b.id] || 0)).forEach(p => {
          html += this.personCardHTML(p, {
            selected: selectedPersonId === p.id,
            highlighted: highlightedIds.has(p.id),
            dimmed: dimmed && !highlightedIds.has(p.id),
            familyColors
          });
        });
        html += `</div></div>`;
      });

      if (noFamily.length > 0) {
        html += `<div class="family-group"><div class="family-group-cards">`;
        noFamily.sort((a, b) => (sortOrder[a.id] || 0) - (sortOrder[b.id] || 0)).forEach(p => {
          html += this.personCardHTML(p, {
            selected: selectedPersonId === p.id,
            highlighted: highlightedIds.has(p.id),
            dimmed: dimmed && !highlightedIds.has(p.id),
            familyColors
          });
        });
        html += `</div></div>`;
      }

      html += `</div></div>`;
    });

    container.innerHTML = html;
  },

  _getFilteredTreePersons(data, filterStatus, treeFilterPerson, treeFilterDepth) {
    const isVisible = (p) => {
      if (filterStatus === 'all') return true;
      if (filterStatus === 'alive') return dataModule.isAlive(p);
      if (filterStatus === 'deceased') return dataModule.isDeceased(p);
      return true;
    };
    if (!treeFilterPerson) return data.persons.filter(isVisible);

    const pid = treeFilterPerson;
    const depth = treeFilterDepth;
    let related = new Set([pid]);

    if (depth === 'ancestors') {
      dataModule.getAncestors(data.links, pid, related);
    } else if (depth === 'descendants') {
      dataModule.getDescendants(data.links, pid, related, true);
    } else if (!isNaN(parseInt(depth))) {
      const maxDepth = parseInt(depth);
      let frontier = [pid];
      for (let i = 0; i < maxDepth; i++) {
        const next = [];
        frontier.forEach(id => {
          [...dataModule.getParents(data.links, id),
           ...dataModule.getChildren(data.links, id),
           ...dataModule.getSpouses(data.links, id)]
            .forEach(rid => { if (!related.has(rid)) { related.add(rid); next.push(rid); } });
        });
        frontier = next;
      }
    } else {
      dataModule.getAncestors(data.links, pid, related);
      dataModule.getDescendants(data.links, pid, related, true);
      dataModule.getSpouses(data.links, pid).forEach(s => related.add(s));
    }

    return data.persons.filter(p => related.has(p.id) && isVisible(p));
  },

  _calcVerticalSort(persons, links) {
    const order = {};
    persons.forEach((p, i) => {
      const parents = dataModule.getParents(links, p.id).filter(pid => persons.find(pp => pp.id === pid));
      if (parents.length > 0) {
        const pidx = persons.findIndex(pp => pp.id === parents[0]);
        order[p.id] = pidx * 100 + 10;
      } else {
        order[p.id] = i * 100;
      }
    });
    return order;
  },

  // ---- SVG CONNECTIONS (v5.2: tree v1.0 removed; this function is kept
  // for backward compat but #connections-svg / #tree-timeline no longer exist
  // — it will bail out silently at the guard below). ----
  drawConnections(state) {
    const svg    = document.getElementById('connections-svg');
    const layer  = document.getElementById('connections-layer');
    const hsvg   = document.getElementById('connections-highlight-svg');
    const hlayer = document.getElementById('connections-highlight-layer');
    if (!svg || !layer) return;  // bail out — elements removed

    const data = state.data;
    const selectedPersonId = state.selectedPersonId;
    const highlightedIds = state.highlightedIds || new Set();
    const dimmed = state.dimmed || false;
    const hasHighlight = selectedPersonId && dimmed;
    const timeline = document.getElementById('tree-timeline');
    if (!timeline) return;  // bail out — element removed

    svg.style.cssText  = `width:${timeline.scrollWidth}px;height:${timeline.scrollHeight}px;position:absolute;top:0;left:0;`;
    if (hsvg) hsvg.style.cssText = svg.style.cssText;

    layer.innerHTML = '';
    if (hlayer) hlayer.innerHTML = '';

    const tScroll = timeline.getBoundingClientRect();
    const treeContent = document.getElementById('tree-content');

    const getCard = (id) => treeContent ? treeContent.querySelector(`.person-card[data-id="${id}"]`) : null;

    // Parent-child lines
    data.links.filter(l => l.type === 'parent_child').forEach(link => {
      const srcEl = getCard(link.source);
      const tgtEl = getCard(link.target);
      if (!srcEl || !tgtEl || srcEl.offsetParent === null || tgtEl.offsetParent === null) return;
      const sR = srcEl.getBoundingClientRect();
      const tR = tgtEl.getBoundingClientRect();

      const sx = sR.left - tScroll.left + timeline.scrollLeft + sR.width / 2;
      const tx = tR.left - tScroll.left + timeline.scrollLeft + tR.width / 2;
      const sourceAbove = sR.top < tR.top;
      const sy = sourceAbove
        ? sR.top - tScroll.top + timeline.scrollTop + sR.height
        : sR.top - tScroll.top + timeline.scrollTop;
      const ty = sourceAbove
        ? tR.top - tScroll.top + timeline.scrollTop
        : tR.top - tScroll.top + timeline.scrollTop + tR.height;
      const midY = (sy + ty) / 2;
      const isHL = hasHighlight && highlightedIds.has(link.source) && highlightedIds.has(link.target);
      const targetLayer = (isHL && hlayer) ? hlayer : layer;

      const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
      path.setAttribute('d', `M${sx},${sy} C${sx},${midY} ${tx},${midY} ${tx},${ty}`);
      path.setAttribute('class', isHL ? 'conn-parent-highlight' : 'conn-parent');
      targetLayer.appendChild(path);

      [{ cx: sx, cy: sy }, { cx: tx, cy: ty }].forEach(({ cx, cy }) => {
        const dot = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        dot.setAttribute('cx', cx); dot.setAttribute('cy', cy);
        dot.setAttribute('r', isHL ? '5' : '3');
        dot.setAttribute('fill', 'var(--conn-parent)');
        dot.setAttribute('opacity', isHL ? '1' : '0.4');
        targetLayer.appendChild(dot);
      });
    });

    // Marriage lines
    data.links.filter(l => l.type === 'marriage').forEach(link => {
      const srcEl = getCard(link.source);
      const tgtEl = getCard(link.target);
      if (!srcEl || !tgtEl || srcEl.offsetParent === null || tgtEl.offsetParent === null) return;
      const sR = srcEl.getBoundingClientRect();
      const tR = tgtEl.getBoundingClientRect();

      const sy = sR.top - tScroll.top + timeline.scrollTop + sR.height / 2;
      const ty = tR.top - tScroll.top + timeline.scrollTop + tR.height / 2;
      let sx, tx;
      if (sR.left < tR.left) {
        sx = sR.right - tScroll.left + timeline.scrollLeft;
        tx = tR.left  - tScroll.left + timeline.scrollLeft;
      } else {
        sx = sR.left  - tScroll.left + timeline.scrollLeft;
        tx = tR.right - tScroll.left + timeline.scrollLeft;
      }
      const midX = (sx + tx) / 2;
      const isHL = hasHighlight && highlightedIds.has(link.source) && highlightedIds.has(link.target);
      const targetLayer = (isHL && hlayer) ? hlayer : layer;

      const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
      path.setAttribute('d', `M${sx},${sy} C${midX},${sy} ${midX},${ty} ${tx},${ty}`);
      path.setAttribute('class', isHL ? 'conn-marriage-highlight' : 'conn-marriage');
      targetLayer.appendChild(path);
    });
  },

  // ---- CARDS MODE ----
  renderCards(state) {
    const container = document.getElementById('card-mode');
    if (!container) return;
    const { data, filterStatus, selectedPersonId, familyColors, sidebarVisible } = state;
    // collapsedConnLevels removed (was tree v1.0). Default to empty Set.
    const collapsedConnLevels = state.collapsedConnLevels || new Set();

    // v78 #3: in cards mode, do NOT filter out persons. Show ALL persons,
    // but add a colored border to those matching the filter:
    //   - filterStatus === 'alive'    → green border on alive cards
    //   - filterStatus === 'deceased' → black border on deceased cards
    //   - filterStatus === 'all'      → no extra border
    const visiblePersons = data.persons;

    let selId = selectedPersonId;
    if (!selId && visiblePersons.length > 0) selId = visiblePersons[0].id;
    let person = visiblePersons.find(p => p.id === selId);
    if (!person && visiblePersons.length > 0) { person = visiblePersons[0]; selId = person.id; }
    if (!person) {
      container.innerHTML = `<div style="text-align:center;padding:60px;color:var(--text-muted)">${i18n.t('cardMode.selectPerson')}</div>`;
      return;
    }

    const parents      = dataModule.getParents(data.links, person.id).map(id => data.persons.find(p => p.id === id)).filter(p => p && visiblePersons.includes(p));
    const spouses      = dataModule.getSpouses(data.links, person.id).map(id => data.persons.find(p => p.id === id)).filter(p => p && visiblePersons.includes(p));
    const children     = dataModule.getChildren(data.links, person.id).map(id => data.persons.find(p => p.id === id)).filter(p => p && visiblePersons.includes(p));
    const siblingIds   = new Set();
    parents.forEach(par => dataModule.getChildren(data.links, par.id).forEach(cid => { if (cid !== person.id) siblingIds.add(cid); }));
    const siblings     = [...siblingIds].map(id => data.persons.find(p => p.id === id)).filter(p => p && visiblePersons.includes(p));
    const grandchildren = [];
    children.forEach(ch => {
      dataModule.getChildren(data.links, ch.id).forEach(gcid => {
        const gc = data.persons.find(p => p.id === gcid);
        if (gc && visiblePersons.includes(gc) && !grandchildren.find(g => g.id === gc.id)) grandchildren.push(gc);
      });
    });

    const displayedPeople = [person, ...spouses, ...parents, ...siblings, ...children, ...grandchildren].filter(Boolean);

    // Build card fn (for card mode)
    // v78 #3: determine filterHighlight per card based on filterStatus
    const getFilterHighlight = (p) => {
      if (filterStatus === 'alive'    && dataModule.isAlive(p))    return 'alive';
      if (filterStatus === 'deceased' && dataModule.isDeceased(p)) return 'deceased';
      return null;
    };
    const cardFn = (p, size, label) => this.personCardHTML(p, {
      selected: p.id === selId,
      highlighted: false, dimmed: false,
      familyColors, size, label,
      filterHighlight: getFilterHighlight(p)
    });

    // ---- Left panel ----
    let leftPanel = `<div id="card-left-panel" style="position:fixed;top:var(--toolbar-h,112px);left:0;width:280px;bottom:28px;background:var(--bg-secondary);border-right:1px solid var(--border-color);z-index:80;overflow-y:auto;display:${sidebarVisible ? 'flex' : 'none'};flex-direction:column">`;
    leftPanel += `<div style="padding:12px 16px;border-bottom:1px solid var(--border-color);position:sticky;top:0;background:var(--bg-secondary);z-index:2"><div style="font-size:13px;font-weight:600;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.5px">${i18n.t('cardMode.peopleOnCard')}</div></div>`;
    leftPanel += `<div style="padding:8px;flex:1;overflow-y:auto">`;
    displayedPeople.forEach(p => {
      const gColor = `var(--${p.gender === 'female' ? 'female' : 'male'}-color)`;
      const isSel  = p.id === selId;
      leftPanel += `<div onclick='app.selectPerson(${JSON.stringify(p.id)})' data-pid="${dataModule.escapeHtml(p.id)}" style="padding:6px 10px;cursor:pointer;border-radius:var(--radius-sm);font-size:13px;color:${gColor};${isSel ? 'background:var(--accent-light);font-weight:600;' : ''}transition:background 0.15s" onmouseover="this.style.background='var(--accent-light)'" onmouseout="this.style.background='${isSel ? 'var(--accent-light)' : ''}'">
        ${dataModule.escapeHtml(dataModule.getFullName(p))}</div>`;
    });
    leftPanel += `</div>`;

    // Connection tree
    const levels = [
      { key: 'parents', icon: '↑', label: i18n.t('cardMode.parents'), people: parents },
      { key: 'spouse',  icon: '💍', label: i18n.t('cardMode.spouseLabel'), people: spouses },
      { key: 'siblings',icon: '↔', label: i18n.t('cardMode.siblings'), people: siblings },
      { key: 'children',icon: '↓', label: i18n.t('cardMode.children'), people: children },
      { key: 'grandchildren', icon: '↓↓', label: i18n.t('cardMode.grandchildren'), people: grandchildren },
    ].filter(lv => lv.people.length > 0);

    const connName = (p) => {
      const gColor = `var(--${p.gender === 'female' ? 'female' : 'male'}-color)`;
      return `<span style="color:${gColor};cursor:pointer" onclick='event.stopPropagation();app.selectPerson(${JSON.stringify(p.id)})' data-pid="${dataModule.escapeHtml(p.id)}">${dataModule.escapeHtml(dataModule.getFullName(p))}</span>`;
    };

    leftPanel += `<div style="border-top:1px solid var(--border-color);padding:8px;max-height:45%;overflow-y:auto">`;
    leftPanel += `<div style="font-size:13px;font-weight:600;color:var(--text-muted);margin-bottom:6px;display:flex;align-items:center;justify-content:space-between">`;
    leftPanel += `<span style="cursor:pointer" onclick="app.toggleConnTreeAll()">${i18n.t('cardMode.connectionTree')}</span>`;
    leftPanel += `<span style="font-size:11px;color:var(--text-muted)">(${displayedPeople.length})</span></div>`;
    leftPanel += `<div style="font-size:13px;line-height:1.8;padding:2px 0">★ ${connName(person)}</div>`;
    levels.forEach(lv => {
      const collapsed = collapsedConnLevels.has(lv.key);
      leftPanel += `<div style="margin-top:4px">`;
      leftPanel += `<div onclick="app.toggleConnTreeLevel('${lv.key}')" style="cursor:pointer;font-size:12px;font-weight:600;color:var(--text-secondary);padding:3px 0;display:flex;align-items:center;gap:6px">`;
      leftPanel += `<span style="display:inline-block;width:12px;color:var(--accent)">${collapsed ? '▶' : '▼'}</span>`;
      leftPanel += `<span>${lv.icon}</span><span>${lv.label}</span>`;
      leftPanel += `<span style="margin-left:auto;color:var(--text-muted);font-weight:400">${lv.people.length}</span></div>`;
      if (!collapsed) {
        leftPanel += `<div style="font-size:13px;line-height:1.8;padding:2px 0 2px 18px">`;
        lv.people.forEach(p => { leftPanel += `${connName(p)}<br>`; });
        leftPanel += `</div>`;
      }
      leftPanel += `</div>`;
    });
    leftPanel += `</div></div>`;

    // ---- Main area ----
    const personIdx = visiblePersons.findIndex(p => p.id === selId);
    const prevPerson = personIdx > 0 ? visiblePersons[personIdx - 1] : null;
    const nextPerson = personIdx < visiblePersons.length - 1 ? visiblePersons[personIdx + 1] : null;
    const marginLeft = sidebarVisible ? '280px' : '0';

    let html = leftPanel;
    html += `<div style="margin-left:${marginLeft};height:100%;overflow-y:auto;padding:30px;display:flex;flex-direction:column;align-items:center">`;
    // Navigation
    html += `<div style="margin-bottom:16px;display:flex;gap:12px;align-items:center;flex-wrap:wrap;justify-content:center">`;
    const prevName = prevPerson ? dataModule.escapeHtml(dataModule.getFullName(prevPerson).slice(0, 20)) : '';
    const nextName = nextPerson ? dataModule.escapeHtml(dataModule.getFullName(nextPerson).slice(0, 20)) : '';
    html += prevPerson ? `<button class="btn btn-sm" onclick='app.selectPerson(${JSON.stringify(prevPerson.id)})' data-pid="${dataModule.escapeHtml(prevPerson.id)}">◀ ${prevName}</button>` : '<span></span>';
    html += `<span style="color:var(--text-muted);font-size:13px">${personIdx + 1} / ${visiblePersons.length}</span>`;
    html += nextPerson ? `<button class="btn btn-sm" onclick='app.selectPerson(${JSON.stringify(nextPerson.id)})' data-pid="${dataModule.escapeHtml(nextPerson.id)}">${nextName} ▶</button>` : '<span></span>';
    html += `</div>`;

    if (parents.length > 0) {
      html += `<div style="width:100%;text-align:center;font-size:16px;font-weight:600;color:var(--text-secondary);margin-bottom:8px">${i18n.t('cardMode.parents')}</div>`;
      html += `<div style="display:flex;gap:20px;justify-content:center;margin-bottom:30px;position:relative;flex-wrap:wrap">`;
      html += `<div style="position:absolute;bottom:-15px;left:50%;transform:translateX(-50%);color:var(--conn-parent);font-size:20px">│</div>`;
      parents.forEach(p => { html += cardFn(p, 'normal', p.gender === 'male' ? i18n.t('cardMode.father') : i18n.t('cardMode.mother')); });
      html += `</div>`;
    }

    html += `<div style="display:flex;gap:30px;justify-content:center;align-items:center;margin-bottom:30px;position:relative;flex-wrap:wrap">`;
    html += `<div style="display:flex;align-items:center;gap:0;position:relative">`;
    html += `<div style="font-size:48px;color:var(--accent);line-height:1;margin-right:-4px;filter:drop-shadow(0 0 6px var(--accent-light));flex-shrink:0" title="${i18n.t('cardMode.selected')}">▶</div>`;
    html += cardFn(person, 'large', i18n.t('cardMode.selected'));
    html += `</div>`;
    if (spouses.length > 0) {
      html += `<div style="color:var(--conn-marriage);font-size:24px">💍</div>`;
      spouses.forEach(s => { html += cardFn(s, 'normal', s.gender === 'male' ? i18n.t('cardMode.spouseM') : i18n.t('cardMode.spouseF')); });
    }
    if (children.length > 0) {
      html += `<div style="position:absolute;bottom:-15px;left:50%;transform:translateX(-50%);color:var(--conn-parent);font-size:20px">│</div>`;
    }
    html += `</div>`;  // close flex row (person + spouses)

    if (siblings.length > 0) {
      html += `<div style="display:flex;gap:14px;justify-content:center;flex-wrap:wrap;margin-bottom:24px">`;
      html += `<div style="width:100%;text-align:center;font-size:16px;font-weight:600;color:var(--text-secondary);margin-bottom:8px">${i18n.t('cardMode.siblings')}</div>`;
      siblings.forEach(s => { html += cardFn(s, 'normal', s.gender === 'male' ? i18n.t('cardMode.brother') : i18n.t('cardMode.sister')); });
      html += `</div>`;
    }
    if (children.length > 0) {
      html += `<div style="display:flex;gap:14px;justify-content:center;flex-wrap:wrap;margin-bottom:24px">`;
      html += `<div style="width:100%;text-align:center;font-size:16px;font-weight:600;color:var(--text-secondary);margin-bottom:8px">${i18n.t('cardMode.children')}</div>`;
      children.forEach(c => { html += cardFn(c, 'normal', c.gender === 'male' ? i18n.t('cardMode.son') : i18n.t('cardMode.daughter')); });
      html += `</div>`;
    }
    if (grandchildren.length > 0) {
      html += `<div style="display:flex;gap:14px;justify-content:center;flex-wrap:wrap;margin-bottom:24px">`;
      html += `<div style="width:100%;text-align:center;font-size:16px;font-weight:600;color:var(--text-secondary);margin-bottom:8px">${i18n.t('cardMode.grandchildren')}</div>`;
      grandchildren.forEach(gc => { html += cardFn(gc, 'normal', gc.gender === 'male' ? i18n.t('cardMode.grandson') : i18n.t('cardMode.granddaughter')); });
      html += `</div>`;
    }

    html += `</div>`;
    container.innerHTML = html;

    return selId; // return resolved selected id
  },

  // ---- TABLE MODE ----
  renderTable(state) {
    const container = document.getElementById('table-mode');
    if (!container) return;
    const { data, filterStatus, sortColumn, sortDirection } = state;

    let persons = data.persons.filter(p => {
      if (filterStatus === 'alive') return dataModule.isAlive(p);
      if (filterStatus === 'deceased') return dataModule.isDeceased(p);
      return true;
    });

    if (sortColumn) {
      persons = [...persons].sort((a, b) => {
        let va = (a[sortColumn] || '').toString().toLowerCase();
        let vb = (b[sortColumn] || '').toString().toLowerCase();
        if (va < vb) return sortDirection === 'asc' ? -1 : 1;
        if (va > vb) return sortDirection === 'asc' ? 1 : -1;
        return 0;
      });
    }

    const sortIcon = (col) => sortColumn === col ? (sortDirection === 'asc' ? ' ▲' : ' ▼') : '';
    const th = (col, label) => `<th onclick='app.sortTable(${JSON.stringify(col)})' data-col="${dataModule.escapeHtml(col)}">${label}${sortIcon(col)}</th>`;

    // v75 #1: precompute children count for each person (O(n) pass over links)
    const childrenCount = new Map();
    (data.links || []).forEach(l => {
      if (l.type !== 'parent_child') return;
      childrenCount.set(l.source, (childrenCount.get(l.source) || 0) + 1);
    });

    let html = `<table class="data-table"><thead><tr>
      <th style="text-align:center">Фото</th>
      ${th('lastName',   i18n.t('table.lastName'))}
      ${th('firstName',  i18n.t('table.firstName'))}
      ${th('patronymic', i18n.t('table.patronymic'))}
      ${th('gender',     i18n.t('table.gender'))}
      ${th('birthDate',  i18n.t('table.birth'))}
      ${th('deathDate',  i18n.t('table.death'))}
      ${th('family',     i18n.t('table.family'))}
      ${th('status',     i18n.t('table.status'))}
      ${th('children',   i18n.t('table.children'))}
    </tr></thead><tbody>`;

    persons.forEach(p => {
      const gc = p.gender === 'female' ? 'female' : 'male';
      const statusLabel = p.status === 'alive' ? i18n.t('table.alive')
        : p.status === 'deceased' ? i18n.t('table.deceased') : '?';
      // add data-pid + selected-row class so cross-mode selection can scroll/highlight
      const isSelected = state.selectedPersonId === p.id;
      // v75 #1: children count for this person
      const childCount = childrenCount.get(p.id) || 0;

      // v99: photo column — show main photo as circle.
      // v100 (запрос пользователя #2): фото в таблице увеличено в 2 раза — 60px вместо 30px.
      const PHOTO_D = 60;  // диаметр кружка фото в таблице
      let photoCellHtml = '';
      if (p.photo) {
        let photoSrc = '';
        if (p.photo.startsWith('data:')) {
          photoSrc = p.photo;
        } else if (typeof filesystem !== 'undefined') {
          // v100 (аудит #5): убрана жёсткая привязка к isConnected() —
          // getCachedPhotoDataUrlSync/ensurePhotoCached сами делают fallback на IndexedDB.
          const cached = filesystem.getCachedPhotoDataUrlSync(p.id);
          if (cached) {
            photoSrc = cached;
          } else {
            if (typeof app !== 'undefined' && app._ensurePhotoCached) {
              app._ensurePhotoCached(p.id);
            }
          }
        }
        if (photoSrc) {
          photoCellHtml = `<td style="text-align:center;padding:4px"><img src="${photoSrc}" style="width:${PHOTO_D}px;height:${PHOTO_D}px;border-radius:50%;object-fit:cover;border:1.5px solid var(--border-color);cursor:zoom-in" onclick='event.stopPropagation();app.showPhotoFullscreen(${JSON.stringify(p.id)})'></td>`;
        } else {
          // Photo loading — show initials circle as placeholder
          const fi = (p.firstName || '?')[0] || '';
          const li = (p.lastName || '?')[0] || '';
          const pi = (p.patronymic || '?')[0] || '';
          const initials = (li + fi + pi).toUpperCase();
          const bg = p.gender === 'female' ? 'rgba(214,51,132,0.4)' : 'rgba(59,125,216,0.4)';
          photoCellHtml = `<td style="text-align:center;padding:4px"><div style="width:${PHOTO_D}px;height:${PHOTO_D}px;border-radius:50%;background:${bg};border:1.5px solid var(--border-color);display:inline-flex;align-items:center;justify-content:center;font-size:16px;font-weight:700;color:var(--text-primary)">${initials}</div></td>`;
        }
      } else {
        // No photo — show initials circle
        const fi = (p.firstName || '?')[0] || '';
        const li = (p.lastName || '?')[0] || '';
        const pi = (p.patronymic || '?')[0] || '';
        const initials = (li + fi + pi).toUpperCase();
        const bg = p.gender === 'female' ? 'rgba(214,51,132,0.4)' : 'rgba(59,125,216,0.4)';
        photoCellHtml = `<td style="text-align:center;padding:4px"><div style="width:${PHOTO_D}px;height:${PHOTO_D}px;border-radius:50%;background:${bg};border:1.5px solid var(--border-color);display:inline-flex;align-items:center;justify-content:center;font-size:16px;font-weight:700;color:var(--text-primary)">${initials}</div></td>`;
      }

      // FIX #2: click on name in table opens detail panel (toggleDetailPanel)
      html += `<tr data-pid="${dataModule.escapeHtml(p.id)}"${isSelected ? ' class="selected-row"' : ''}>
        ${photoCellHtml}
        <td class="td-name ${gc}" onclick='app.toggleDetailPanel(${JSON.stringify(p.id)})' data-pid="${dataModule.escapeHtml(p.id)}" title="Открыть карточку">${dataModule.escapeHtml(p.lastName || '')}</td>
        <td>${dataModule.escapeHtml(p.firstName || '')}</td>
        <td>${dataModule.escapeHtml(p.patronymic || '')}</td>
        <td>${p.gender === 'male' ? i18n.t('table.male') : i18n.t('table.female')}</td>
        <td>${dataModule.escapeHtml(p.birthDate || '')}</td>
        <td>${dataModule.escapeHtml(p.deathDate || '')}</td>
        <td>${dataModule.escapeHtml(p.family || '')}</td>
        <td>${statusLabel}</td>
        <td style="text-align:center">${childCount}</td>
      </tr>`;
    });

    html += `</tbody></table>`;
    container.innerHTML = html;
  },

  // ---- Person panel ----
  renderPersonPanel(person, data, familyColors) {
    // Fix #3: compact panel — photo + name on one line; no scroll needed
    // v92: person.photo is a filename — get cached data URL for rendering
    let photoSrc = '';
    if (person.photo) {
      if (person.photo.startsWith('data:')) {
        photoSrc = person.photo;  // old v91 format
      } else if (typeof filesystem !== 'undefined') {
        // v100 (аудит #5): без isConnected() — работает и через IndexedDB fallback
        const cached = filesystem.getCachedPhotoDataUrlSync(person.id);
        if (cached) photoSrc = cached;
        else app._ensurePhotoCached(person.id);  // trigger async load
      }
    }
    const photoHtml = photoSrc
      ? `<img src="${photoSrc}" style="width:72px;height:72px;border-radius:50%;object-fit:cover;border:2px solid var(--border-color);cursor:zoom-in;flex-shrink:0" onclick='app.showPhotoFullscreen(${JSON.stringify(person.id)})' data-pid="${dataModule.escapeHtml(person.id)}" title="${i18n.t('card.viewDetails')}">`
      : `<div style="width:72px;height:72px;border-radius:50%;background:var(--bg-input);display:flex;align-items:center;justify-content:center;border:2px solid var(--border-color);overflow:hidden;flex-shrink:0">${typeof MALE_ICON !== 'undefined' ? `<img src="${person.gender === 'female' ? FEMALE_ICON : MALE_ICON}" alt="" style="width:100%;height:100%;object-fit:contain">` : ''}</div>`;

    const genderStr = person.gender === 'male' ? i18n.t('panel.male') : i18n.t('panel.female');
    const statusStr = person.status === 'alive' ? i18n.t('panel.alive') : person.status === 'deceased' ? i18n.t('panel.deceased') : i18n.t('panel.statusUnknown');
    const genderColor = person.gender === 'female' ? 'var(--female-color)' : 'var(--male-color)';
    const statusColor = person.status === 'alive' ? 'var(--success)' : person.status === 'deceased' ? 'var(--text-muted)' : 'var(--warning)';

    // Full name block
    const fullNameHtml = `<div style="font-size:15px;font-weight:700;color:${genderColor};line-height:1.3;margin-bottom:2px">${dataModule.escapeHtml(dataModule.getFullName(person))}</div>`;
    const maidenPart = (person.gender === 'female' && person.maidenName) ? `<div style="font-size:11px;color:var(--text-muted)">${i18n.t('panel.maidenName')}: ${dataModule.escapeHtml(person.maidenName)}</div>` : '';
    const familyPart = person.family ? `<div style="font-size:11px;color:var(--text-muted)">${i18n.t('panel.family')}: <span style="color:var(--accent)">${dataModule.escapeHtml(person.family)}</span></div>` : '';

    // Row: gender | status | birthDate
    const infoRow1Parts = [
      genderStr,
      `<span style="color:${statusColor}">${statusStr}</span>`,
      person.birthDate ? person.birthDate + (person.deathDate ? ' — ' + person.deathDate : '') : ''
    ].filter(Boolean);

    // Secondary info
    const rows = [];
    if (person.birthPlace) rows.push([i18n.t('panel.birthPlace'), dataModule.escapeHtml(person.birthPlace)]);
    if (person.deathDate && !person.birthDate) rows.push([i18n.t('panel.deathDate'), dataModule.escapeHtml(person.deathDate)]);
    if (person.deathPlace) rows.push([i18n.t('panel.deathPlace'), dataModule.escapeHtml(person.deathPlace)]);

    let html = `<div class="panel-section" style="margin-bottom:12px">
      <div style="display:flex;gap:10px;align-items:flex-start;margin-bottom:8px">
        ${photoHtml}
        <div style="min-width:0;flex:1">
          ${fullNameHtml}
          ${maidenPart}${familyPart}
          <div style="font-size:12px;color:var(--text-secondary);margin-top:4px;display:flex;flex-wrap:wrap;gap:6px">
            ${infoRow1Parts.map(p=>`<span>${p}</span>`).join('<span style="color:var(--border-color)">·</span>')}
          </div>
          ${rows.map(([l,v])=>`<div style="font-size:11px;color:var(--text-muted);margin-top:2px"><span style="color:var(--text-muted)">${l}:</span> ${v}</div>`).join('')}
        </div>
      </div>`;
    if (person.bio) html += `<div style="padding:8px;background:var(--bg-input);border-radius:var(--radius-sm);font-size:12px;line-height:1.5;color:var(--text-secondary)">${dataModule.escapeHtml(person.bio)}</div>`;
    html += `</div>`;

    // Relatives
    html += `<div class="panel-section"><div class="panel-section-title">${i18n.t('panel.relatives')}</div>`;
    const parents  = dataModule.getParents(data.links, person.id);
    const children = dataModule.getChildren(data.links, person.id);
    const spouses  = dataModule.getSpouses(data.links, person.id);
    const relRow   = (relType, id) => {
      const p = data.persons.find(x => x.id === id);
      if (!p) return '';
      return `<div class="relative-item"><span class="rel-type">${relType}</span><span class="rel-name" onclick='app.selectPerson(${JSON.stringify(p.id)})' data-pid="${dataModule.escapeHtml(p.id)}" style="cursor:pointer">${dataModule.escapeHtml(dataModule.getFullName(p))}</span></div>`;
    };
    parents.forEach(id  => { html += relRow(i18n.t('panel.parentRel'), id); });
    spouses.forEach(id  => { html += relRow(i18n.t('panel.spouseRel'), id); });
    children.forEach(id => { html += relRow(i18n.t('panel.childRel'), id); });
    // FIX #9: show sibling links
    const siblings_p = dataModule.getSiblings(data.links, person.id);
    siblings_p.forEach(sibId => {
      const sib = data.persons.find(x => x.id === sibId);
      if (!sib) return;
      const label = sib.gender === 'female' ? i18n.t('panel.sisterRel') : i18n.t('panel.brotherRel');
      html += relRow(label, sibId);
    });
    if (!parents.length && !children.length && !spouses.length && !siblings_p.length) {
      html += `<div style="font-size:13px;color:var(--text-muted)">${i18n.t('panel.noLinks')}</div>`;
    }
    html += `</div>`;

    // Actions
    html += `<div class="panel-section"><div class="panel-section-title">${i18n.t('panel.actions')}</div>
      <div style="display:flex;flex-direction:column;gap:8px">
        <button class="btn btn-primary btn-lg" data-pid="${dataModule.escapeHtml(person.id)}" onclick='app.editPerson(${JSON.stringify(person.id)})'>✏️ ${i18n.t('panel.edit')}</button>
        <button class="btn btn-lg" data-pid="${dataModule.escapeHtml(person.id)}" onclick='app.addRelativeTo(${JSON.stringify(person.id)})'>➕ ${i18n.t('panel.addRelative')}</button>
        <button class="btn btn-lg" data-pid="${dataModule.escapeHtml(person.id)}" onclick='app.mergeCards(${JSON.stringify(person.id)})'>🔗 ${i18n.t('panel.mergeCards')}</button>
        <button class="btn btn-lg" data-pid="${dataModule.escapeHtml(person.id)}" onclick='app.showTreeFrom(${JSON.stringify(person.id)})'>🌲 ${i18n.t('panel.treeFrom')}</button>
        <button class="btn btn-lg" data-pid="${dataModule.escapeHtml(person.id)}" onclick='app.changePhoto(${JSON.stringify(person.id)})'>📷 ${i18n.t('panel.changePhoto')}</button>
        ${person.photo ? `<button class="btn btn-lg" data-pid="${dataModule.escapeHtml(person.id)}" onclick='app.deletePhoto(${JSON.stringify(person.id)})'>🗑️ ${i18n.t('panel.deletePhoto')}</button>` : ''}
        <button class="btn btn-danger btn-lg" data-pid="${dataModule.escapeHtml(person.id)}" onclick='app.deletePerson(${JSON.stringify(person.id)})'>🗑️ ${i18n.t('panel.delete')}</button>
      </div></div>`;

    return html;
  }
};
