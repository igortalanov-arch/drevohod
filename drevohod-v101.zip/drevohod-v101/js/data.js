// data.js — Data model, migration, GEDCOM parser, validation, generation calc
// Drevohod v83 Arena Edition

const dataModule = {

  // v73 #1: HTML escape helper — protects against XSS when user-controlled
  // data (names, bios, places, IDs from GEDCOM) is inserted via innerHTML.
  escapeHtml(s) {
    if (s == null) return '';
    return String(s).replace(/[&<>"']/g, c => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    })[c]);
  },

  // v73 #19: Schema validation for parsed JSON data — guards against
  // corrupted or malicious files with unexpected structure.
  validateData(data) {
    const errors = [];
    if (!data || typeof data !== 'object') {
      errors.push('Data is not an object');
      return { valid: false, errors };
    }
    if (!Array.isArray(data.persons)) {
      errors.push('persons is not an array');
      data.persons = [];
    }
    if (!Array.isArray(data.links)) {
      errors.push('links is not an array');
      data.links = [];
    }
    if (!Array.isArray(data.families)) {
      errors.push('families is not an array');
      data.families = [];
    }
    // Validate each person has required fields with correct types
    data.persons.forEach((p, i) => {
      if (!p || typeof p !== 'object') {
        errors.push(`person[${i}] is not an object`);
        return;
      }
      if (typeof p.id !== 'string' && typeof p.id !== 'number') {
        errors.push(`person[${i}].id missing or invalid`);
      }
      if (typeof p.firstName !== 'string') p.firstName = String(p.firstName || '');
      if (typeof p.lastName !== 'string') p.lastName = String(p.lastName || '');
      if (typeof p.gender !== 'string') p.gender = 'male';
      if (typeof p.status !== 'string') p.status = 'unknown';
      if (typeof p.birthDate !== 'string') p.birthDate = String(p.birthDate || '');
      if (typeof p.deathDate !== 'string') p.deathDate = String(p.deathDate || '');
      if (typeof p.bio !== 'string') p.bio = String(p.bio || '');
    });
    // Validate each link
    data.links.forEach((l, i) => {
      if (!l || typeof l !== 'object') {
        errors.push(`link[${i}] is not an object`);
        return;
      }
      if (l.type !== 'parent_child' && l.type !== 'marriage') {
        errors.push(`link[${i}].type invalid: ${l.type}`);
      }
      if (!l.source || !l.target) {
        errors.push(`link[${i}] missing source/target`);
      }
    });
    return { valid: errors.length === 0, errors };
  },

  emptyData(lang) {
    return {
      persons: [],
      links: [],
      families: [],
      meta: {
        name: lang === 'en' ? 'My Tree' : 'Моё древо',
        created: new Date().toISOString(),
        modified: new Date().toISOString()
      }
    };
  },

  generateId() {
    // Use crypto.randomUUID if available, otherwise counter+random
    if (typeof crypto !== 'undefined' && crypto.randomUUID) {
      return 'p' + crypto.randomUUID().replace(/-/g, '').slice(0, 12);
    }
    return 'p' + Date.now().toString(36) + '_' + (++this._idCounter).toString(36);
  },
  _idCounter: 0,

  // ---- Migration ----
  migratePerson(p) {
    // v1 format support
    if (p.name && !p.firstName) {
      const parts = (p.name || '').trim().split(/\s+/);
      p.firstName = parts[0] || '';
      p.patronymic = parts[1] || '';
    }
    if (p.surname && !p.lastName) p.lastName = p.surname;
    if (p.birthYear && !p.birthDate) p.birthDate = String(p.birthYear);
    if (p.deathYear && !p.deathDate) p.deathDate = String(p.deathYear);
    if (p.isAlive !== undefined && !p.status) p.status = p.isAlive ? 'alive' : 'deceased';
    if (p.nee && !p.maidenName) { p.maidenName = p.nee; delete p.nee; }
    // Ensure all fields exist
    const defaults = {
      id: this.generateId(),
      firstName: '', lastName: '', patronymic: '', maidenName: '',
      gender: 'male', status: 'unknown',
      birthDate: '', birthDateApprox: false,
      deathDate: '', birthPlace: '', deathPlace: '',
      bio: '', photo: '', photo2: '', photo3: '', photoFileName: '', family: '', position: ''
    };
    return Object.assign({}, defaults, p);
  },

  migrateLinks(links) {
    return links
      .map(l => {
        if (l.type === 'spouse') l.type = 'marriage';
        if (!l.id) l.id = this.generateId();
        // 'sibling' type is valid — keep as-is
        return l;
      })
      // Defensive: drop self-loops (source === target) — they are always data errors
      // and would otherwise cause infinite recursion in graph algorithms.
      .filter(l => l.source !== l.target);
  },

  migrateData(data) {
    if (!data) return null;
    data.persons = (data.persons || []).map(p => this.migratePerson(p));
    data.links   = this.migrateLinks(data.links || []);
    data.families = data.families || [];
    data.meta = data.meta || { name: 'Моё древо' };
    // v77 #5: synchronise links (double-entry principle) on every import
    this.syncLinks(data);
    // v100 FIX (аудит #10): migrateData вызывается при ЛЮБОЙ замене данных
    // (загрузка, импорт, недавние древа) — централизованно сбрасываем кеш
    // поколений, чтобы не показывать номера поколений от предыдущего древа.
    this.clearGenCache();
    return data;
  },

  // ---- Graph helpers ----
  getParents(links, pid) {
    return links.filter(l => l.type === 'parent_child' && l.target === pid).map(l => l.source);
  },

  getChildren(links, pid) {
    return links.filter(l => l.type === 'parent_child' && l.source === pid).map(l => l.target);
  },

  getSpouses(links, pid) {
    return links
      .filter(l => l.type === 'marriage' && (l.source === pid || l.target === pid))
      .map(l => l.source === pid ? l.target : l.source);
  },

  // FIX #9: get siblings (via sibling links)
  getSiblings(links, pid) {
    return links
      .filter(l => l.type === 'sibling' && (l.source === pid || l.target === pid))
      .map(l => l.source === pid ? l.target : l.source);
  },

  getAncestors(links, pid, set = new Set()) {
    this.getParents(links, pid).forEach(parentId => {
      if (!set.has(parentId)) {
        set.add(parentId);
        this.getAncestors(links, parentId, set);
      }
    });
    return set;
  },

  getDescendants(links, pid, set = new Set(), includeSpouses = false) {
    this.getChildren(links, pid).forEach(childId => {
      if (!set.has(childId)) {
        set.add(childId);
        if (includeSpouses) {
          this.getSpouses(links, childId).forEach(s => set.add(s));
        }
        this.getDescendants(links, childId, set, includeSpouses);
      }
    });
    return set;
  },

  ensureLink(links, type, source, target, generateId) {
    const exists = links.some(l =>
      l.type === type &&
      ((l.source === source && l.target === target) ||
       (l.source === target && l.target === source))
    );
    if (!exists) {
      links.push({ id: generateId(), type, source, target });
    }
  },

  // v77 #5: Synchronise all links — principle of double entry.
  //   - Remove duplicates (same type + same source/target pair)
  //   - Remove self-loops (source === target)
  //   - For parent_child: if both A→B and B→A exist (cycle), keep only A→B
  //   - For sibling: ensure symmetry — if A-B exists, B-A is the same link (already
  //     handled by ensureLink, but dedup catches raw duplicates from import)
  //   - Auto-create sibling links for children of the same parent (so "brother"
  //     relationship is bidirectional and explicit, not just computed)
  syncLinks(data) {
    if (!data || !data.links) return;
    // v101: build personsById for cycle resolution by birth year
    const personsById = {};
    (data.persons || []).forEach(p => { personsById[p.id] = p; });
    const links = data.links;
    const seen = new Set();
    const deduped = [];
    links.forEach(l => {
      // Skip self-loops
      if (l.source === l.target) return;
      // Build canonical key (for symmetric types, order doesn't matter)
      let key;
      if (l.type === 'marriage' || l.type === 'sibling') {
        // Symmetric: A-B same as B-A
        key = l.type + ':' + [l.source, l.target].sort().join('|');
      } else {
        // Directed: parent_child — A→B different from B→A
        key = l.type + ':' + l.source + '|' + l.target;
      }
      if (seen.has(key)) return;  // duplicate
      seen.add(key);
      deduped.push(l);
    });
    // v101 FIX Б5: Remove parent_child cycles by comparing birth years, not string IDs.
    // Keep the link where source (parent) has an EARLIER birth year than target (child).
    // Fallback: keep the first-encountered direction.
    const pcLinks = deduped.filter(l => l.type === 'parent_child');
    const pcSet = new Set(pcLinks.map(l => l.source + '|' + l.target));
    const cycleWinners = new Set(); // keys of links to KEEP
    const cycleProcessed = new Set(); // keys already decided
    pcLinks.forEach(l => {
      const key = l.source + '|' + l.target;
      const reverse = l.target + '|' + l.source;
      if (pcSet.has(reverse) && !cycleProcessed.has(key) && !cycleProcessed.has(reverse)) {
        cycleProcessed.add(key);
        cycleProcessed.add(reverse);
        // Compare birth years
        const pSrc = personsById[l.source];
        const pTgt = personsById[l.target];
        const ySrc = pSrc ? this.getBirthYear(pSrc) : null;
        const yTgt = pTgt ? this.getBirthYear(pTgt) : null;
        if (ySrc !== null && yTgt !== null) {
          // Keep the one where source is older (parent should be older)
          if (ySrc <= yTgt) cycleWinners.add(key);
          else cycleWinners.add(reverse);
        } else {
          // Can't determine — keep lexicographically smaller as fallback
          cycleWinners.add(l.source < l.target ? key : reverse);
        }
      }
    });
    const finalLinks = deduped.filter(l => {
      if (l.type !== 'parent_child') return true;
      const key = l.source + '|' + l.target;
      const reverse = l.target + '|' + l.source;
      if (pcSet.has(reverse)) {
        // This is a cycle link — keep only if it's the winner
        return cycleWinners.has(key);
      }
      return true;
    });
    data.links = finalLinks;

    // v77 #5: auto-create sibling links for children sharing a parent.
    // This ensures that if A has children B and C, then B-C sibling link exists.
    // Uses the updated data.links (after dedup).
    const childrenByParent = new Map();
    (data.links || []).forEach(l => {
      if (l.type !== 'parent_child') return;
      if (!childrenByParent.has(l.source)) childrenByParent.set(l.source, []);
      childrenByParent.get(l.source).push(l.target);
    });
    const existingSibling = new Set();
    (data.links || []).forEach(l => {
      if (l.type === 'sibling') {
        existingSibling.add([l.source, l.target].sort().join('|'));
      }
    });
    let sibIdx = 0;
    childrenByParent.forEach(kids => {
      for (let i = 0; i < kids.length; i++) {
        for (let j = i + 1; j < kids.length; j++) {
          const key = [kids[i], kids[j]].sort().join('|');
          if (!existingSibling.has(key)) {
            data.links.push({
              id: 'syncsib' + (sibIdx++),
              type: 'sibling',
              source: kids[i],
              target: kids[j]
            });
            existingSibling.add(key);
          }
        }
      }
    });
  },

  // ---- Generation calculation (cached) ----
  _genCache: new Map(),

  clearGenCache() {
    this._genCache.clear();
  },

  getGeneration(persons, links, pid) {
    if (this._genCache.has(pid)) return this._genCache.get(pid);
    const gen = this._calcGen(persons, links, pid, new Set());
    this._genCache.set(pid, gen);
    return gen;
  },

  _calcGen(persons, links, pid, visited) {
    if (visited.has(pid)) return 0;
    visited.add(pid);
    const parents = this.getParents(links, pid);
    if (parents.length === 0) {
      const person = persons.find(p => p.id === pid);
      const year = this.getBirthYear(person);
      if (year) return Math.floor((new Date().getFullYear() - year) / 30);
      return 0;
    }
    let max = 0;
    parents.forEach(pId => {
      const g = this._calcGen(persons, links, pId, visited);
      if (g > max) max = g;
    });
    return max + 1;
  },

  getBirthYear(person) {
    if (!person || !person.birthDate) return null;
    const m = person.birthDate.match(/(\d{4})/);
    return m ? parseInt(m[1]) : null;
  },

  // v77 #4: determine if a person is "alive" for the filter.
  // Rules (per user request):
  //   - If person has a deathDate year → deceased (not alive)
  //   - If person.status === 'deceased' → not alive
  //   - If person has a birthDate year AND (currentYear - birthYear) >= 120 → not alive
  //   - Otherwise → alive (includes people with no dates at all)
  isAlive(person) {
    if (!person) return false;
    // Explicit deceased status
    if (person.status === 'deceased') return false;
    // Has death date with a year → deceased
    if (person.deathDate) {
      const m = String(person.deathDate).match(/(\d{4})/);
      if (m) return false;
    }
    // Age check: if 120+ years since birth → presumed deceased
    if (person.birthDate) {
      const m = String(person.birthDate).match(/(\d{4})/);
      if (m) {
        const birthYear = parseInt(m[1]);
        const currentYear = new Date().getFullYear();
        if (currentYear - birthYear >= 120) return false;
      }
    }
    return true;
  },

  // v77 #4: determine if a person is "deceased" for the filter (inverse of isAlive
  // but explicit — only those who are clearly deceased).
  isDeceased(person) {
    return !this.isAlive(person);
  },

  // ---- Validation ----
  // v90 FIX: validation now normalizes field values before checking emptiness.
  // Previously, values like "//" or "  " (whitespace) passed the `!person.firstName`
  // check incorrectly (treated as truthy non-empty). Now we trim and reject
  // "/", "//", and pure-whitespace values.
  // Also: nameless GenoPro placeholders (no FIO at all) are NOT flagged — they're
  // link anchors, not real persons. The validation panel only flags persons who
  // have SOME name data but are missing required fields.
  validatePerson(person, lang) {
    const errors = [];
    const t = (key) => i18n.t(key);

    // v90: normalize field — treat "/", "//", pure whitespace as empty.
    const isEmpty = (v) => {
      if (v == null) return true;
      const s = String(v).trim();
      return s === '' || s === '/' || s === '//';
    };

    const fn = !isEmpty(person.firstName);
    const ln = !isEmpty(person.lastName);
    const mn = !isEmpty(person.maidenName);
    const pt = !isEmpty(person.patronymic);

    // v90: if person is completely nameless (no FIO at all), skip validation —
    // it's a GenoPro placeholder, not a real person. Don't clutter the validation
    // panel with these.
    if (!fn && !ln && !mn && !pt) {
      return errors;  // empty errors array
    }

    if (!fn) errors.push(t('validation.noFirstName'));
    // For females check both lastName and maidenName; for males only lastName
    if (person.gender === 'female') {
      if (!ln && !mn) errors.push(t('validation.noLastName'));
    } else {
      if (!ln) errors.push(t('validation.noLastName'));
    }
    if (person.status === 'deceased' && !person.deathDate) errors.push(t('validation.deceasedNoDeathDate'));
    if (person.status === 'alive' && person.deathDate) errors.push(t('validation.aliveWithDeathDate'));
    if (person.birthDate && person.deathDate) {
      const bYear = this.getBirthYear(person);
      const m = (person.deathDate || '').match(/(\d{4})/);
      const dYear = m ? parseInt(m[1]) : null;
      if (bYear && dYear && dYear < bYear) errors.push(t('validation.deathBeforeBirth'));
    }
    return errors;
  },

  validateAll(data) {
    const issues = [];

    // v90: helper — treat "/", "//", whitespace as empty (same as validatePerson)
    const isEmpty = (v) => {
      if (v == null) return true;
      const s = String(v).trim();
      return s === '' || s === '/' || s === '//';
    };
    // v90: check if person is completely nameless (GenoPro placeholder)
    const isNameless = (p) => isEmpty(p.firstName) && isEmpty(p.lastName) &&
                        isEmpty(p.patronymic) && isEmpty(p.maidenName);

    data.persons.forEach(p => {
      // v90: skip nameless persons entirely — they're link anchors, not real people
      if (isNameless(p)) return;

      const errs = this.validatePerson(p);
      errs.forEach(e => issues.push({ person: p, error: e }));
      // Isolated person check
      const hasLinks = data.links.some(l => l.source === p.id || l.target === p.id);
      if (!hasLinks && data.persons.length > 1) {
        issues.push({ person: p, error: i18n.t('validation.noLinks') });
      }
    });

    // Broken links
    data.links.forEach(l => {
      if (!data.persons.find(p => p.id === l.source))
        issues.push({ error: i18n.t('validation.brokenLink') + ': ' + l.source });
      if (!data.persons.find(p => p.id === l.target))
        issues.push({ error: i18n.t('validation.brokenLink') + ': ' + l.target });
    });

    // Duplicate detection — by name + birth year (not just name)
    // v90: skip nameless persons (they all share key "_noYear" and create false dupes)
    const nameYearMap = {};
    data.persons.forEach(p => {
      if (isNameless(p)) return;
      const name = [p.lastName, p.firstName, p.patronymic].filter(s => s && !isEmpty(s)).join(' ').toLowerCase();
      if (!name) return;  // skip if no name at all
      const year = this.getBirthYear(p) || 'noYear';
      const key = name + '_' + year;
      if (nameYearMap[key]) {
        issues.push({ person: p, error: i18n.t('validation.possibleDuplicate') + ': ' + this.getFullName(nameYearMap[key]) });
      }
      nameYearMap[key] = p;
    });

    return issues;
  },

  // ---- Name helpers ----
  getFullName(p) {
    if (!p) return '';
    let name = '';
    if (p.lastName) name += p.lastName + ' ';
    if (p.firstName) name += p.firstName + ' ';
    if (p.patronymic) name += p.patronymic;
    return name.trim() || p.firstName || i18n.t('card.noName');
  },

  formatYears(person) {
    const b = person.birthDate || '?';
    const bSuffix = person.birthDateApprox ? ' (?)' : '';  // v96: mark approximate dates
    const d = person.deathDate || (person.status === 'alive' ? i18n.t('card.present') : '?');
    if (!person.birthDate && !person.deathDate && person.status !== 'alive') return '';
    return `${b}${bSuffix} — ${d}`;
  },

  calculateAge(person) {
    // v100 FIX (аудит #2): parseInt("15.03.1990") === 15, что давало абсурдный
    // возраст для полных дат. Теперь используем getBirthYear() (регулярка по 4 цифрам)
    // и такое же извлечение года из deathDate.
    const bYear = this.getBirthYear(person);
    if (bYear === null || isNaN(bYear)) return null;
    let dYear;
    if (person.deathDate) {
      const m = String(person.deathDate).match(/(\d{4})/);
      if (!m) return null;
      dYear = parseInt(m[1]);
    } else {
      dYear = new Date().getFullYear();
    }
    if (isNaN(dYear)) return null;
    return dYear - bYear;
  },

  ageWord(age, lang) {
    if (lang === 'en') return age === 1 ? 'year' : 'years';
    const lastTwo = age % 100;
    const lastOne = age % 10;
    if (lastTwo >= 11 && lastTwo <= 14) return 'лет';
    if (lastOne === 1) return 'год';
    if (lastOne >= 2 && lastOne <= 4) return 'года';
    return 'лет';
  },

  // ---- GEDCOM parser ----
  // v73 #7: async wrapper for parseGEDCOM — yields to the event loop before
  // parsing so the UI can show a loading indicator. For very large GEDCOM
  // files (1000+ lines), parsing takes 100-500ms on main thread, freezing
  // the UI. A proper Web Worker would be better, but requires a separate
  // file + server; this is a lightweight improvement that at least lets
  // the loading toast render before parsing starts.
  async parseGEDCOMAsync(text, onProgress) {
    if (typeof onProgress === 'function') onProgress('parsing');
    // Yield to the event loop so the loading indicator can paint
    await new Promise(r => setTimeout(r, 0));
    return this.parseGEDCOM(text);
  },

  // ---- v86 duplicate detection helpers ----
  // User criteria (v86): a duplicate is detected when ALL THREE of the following
  // "compatible" criteria match between two person records:
  //   1. FIO compatible — at least 2 of {firstName, lastName, patronymic} tokens
  //      match (in any position, case-insensitive). This catches cases like
  //      "Дзех Владимир Александрович" vs "Александрович Владимир Дзех" (tokens
  //      in different order) and "Ирина Кутасова" vs "Ирина Журавлева" (same
  //      first+patronymic, different last name due to marriage).
  //   2. Birth year compatible — both missing, OR one missing, OR exactly equal.
  //      NOT compatible if both years are known and differ.
  //   3. Relatives compatible — at least one named relative in common, OR at
  //      least one side has no NAMED relatives (so we can't disprove duplicate).
  //
  // "Compatible" rather than "strictly equal" is used because GenoPro's GEDCOM
  // export represents one person via multiple INDI records (one per family
  // they belong to) — some records have birth year, others don't; some have
  // spouse, others have parents. We must still merge them.

  // Returns sorted unique lowercased non-empty name tokens from a person.
  _nameTokens(p) {
    if (!p) return [];
    const raw = [
      p.firstName || '',
      p.lastName || '',
      p.patronymic || '',
      p.maidenName || ''
    ];
    const tokens = new Set();
    raw.forEach(s => {
      const t = (s || '').toLowerCase().trim();
      if (t && t !== '/' && t !== '//') tokens.add(t);
    });
    return [...tokens].sort();
  },

  // FIO match: SAME set of name tokens (allowing different positions).
  // User's example: "Дзех Владимир Александрович" matches "Александрович Владимир Дзех"
  // (same 3 tokens in different positions). Does NOT match "Николай Александрович Панфилов"
  // vs "Никита Александрович Панфилов" (different first name → different token sets).
  // We use a "subset" rule: the smaller token set must be a subset of the larger one.
  // This handles cases where one record has fewer tokens (e.g., missing patronymic).
  // Maiden name is included in the token set, so "Ирина Кутасова" (maiden) can match
  // "Ирина Журавлева" (married) IF maidenName="Кутасова" is recorded on the married side.
  _fioMatches(p1, p2) {
    if (!p1 || !p2) return false;
    const t1 = this._mainNameTokens(p1);
    const t2 = this._mainNameTokens(p2);
    if (t1.length < 2 || t2.length < 2) return false;  // not enough info to claim duplicate
    const s1 = new Set(t1);
    const s2 = new Set(t2);
    // Smaller set must be subset of larger set.
    const [smaller, larger] = s1.size <= s2.size ? [s1, s2] : [s2, s1];
    for (const t of smaller) {
      if (!larger.has(t)) return false;
    }
    return true;
  },

  // Collect lowercased non-empty name tokens from firstName, lastName, patronymic, maidenName.
  _mainNameTokens(p) {
    if (!p) return [];
    const tokens = new Set();
    [
      p.firstName || '',
      p.lastName || '',
      p.patronymic || '',
      p.maidenName || ''
    ].forEach(s => {
      const t = (s || '').toLowerCase().trim();
      if (t && t !== '/' && t !== '//') tokens.add(t);
    });
    return [...tokens];
  },

  // Birth year compatible: not contradictory.
  _yearCompatible(p1, p2) {
    const y1 = this.getBirthYear(p1);
    const y2 = this.getBirthYear(p2);
    if (y1 === null || y2 === null) return true;  // one or both unknown → can't disprove
    return y1 === y2;
  },

  // Compute relatives (as person objects) for a person based on families array.
  // Used during parseGEDCOM where we have families[] with HUSB/WIFE/CHIL refs.
  // Returns array of relative person objects (parents, spouses, children, siblings).
  _relativesFromFamilies(pid, families, personMap) {
    // v95: delegate to role-aware version, then strip roles.
    return this._relativesFromFamiliesWithRoles(pid, families, personMap).map(r => r.person);
  },

  // v95: Same as _relativesFromFamilies but returns [{person, role}] where role is
  // 'parent' | 'spouse' | 'child' | 'sibling'. Used by _relativesCompatible to
  // require role-matching (a common relative must be in the SAME role for both
  // persons — e.g., if ind00032 is a parent of p1, it must also be a parent of p2,
  // not a sibling). This prevents merging uncle+nephew who share a relative but
  // in different roles.
  _relativesFromFamiliesWithRoles(pid, families, personMap) {
    const result = [];
    const seen = new Set();  // key: role + '|' + personId
    const push = (id, role) => {
      if (!id || !personMap[id] || id === pid) return;
      const key = role + '|' + id;
      if (seen.has(key)) return;
      seen.add(key);
      result.push({ person: personMap[id], role });
    };
    families.forEach(f => {
      const isHusb = f.husband === pid;
      const isWife = f.wife === pid;
      const isChild = f.children.indexOf(pid) !== -1;
      if (isHusb || isWife) {
        push(isHusb ? f.wife : f.husband, 'spouse');
        f.children.forEach(cid => push(cid, 'child'));
      }
      if (isChild) {
        push(f.husband, 'parent');
        push(f.wife, 'parent');
        f.children.forEach(cid => { if (cid !== pid) push(cid, 'sibling'); });
      }
    });
    return result;
  },

  // Relatives compatible: at least one NAMED relative in common IN THE SAME ROLE,
  // OR one side has no NAMED relatives (so we can't disprove duplicate).
  // v95: added role check — previously a shared relative in different roles
  // (e.g., parent of one, sibling of other) counted as "compatible", causing
  // false merges of uncle/nephew pairs.
  _relativesCompatible(rels1, rels2) {
    // v95: accept role-aware input OR plain person arrays (for backward compat).
    // If elements have .person, use role-aware matching; otherwise fallback to plain.
    const hasRoles = rels1.length > 0 && rels1[0] && rels1[0].role !== undefined;
    if (!hasRoles) {
      // Legacy path (plain persons) — no role info, use old logic.
      const named1 = rels1.filter(r => this._nameTokens(r).length >= 2);
      const named2 = rels2.filter(r => this._nameTokens(r).length >= 2);
      if (named1.length === 0 || named2.length === 0) return true;
      for (const r1 of named1) {
        for (const r2 of named2) {
          if (this._fioMatches(r1, r2)) return true;
        }
      }
      return false;
    }
    // v95: role-aware path — require same role for common relative.
    const named1 = rels1.filter(r => this._nameTokens(r.person).length >= 2);
    const named2 = rels2.filter(r => this._nameTokens(r.person).length >= 2);
    if (named1.length === 0 || named2.length === 0) return true;  // can't disprove
    for (const r1 of named1) {
      for (const r2 of named2) {
        if (r1.role !== r2.role) continue;  // v95: different role → not the same relationship
        if (this._fioMatches(r1.person, r2.person)) return true;
      }
    }
    return false;
  },

  // Combined duplicate check using user's 3-criteria rule.
  // `families1`/`families2` and `personMap1`/`personMap2` are needed to compute relatives.
  //
  // v87 STRONG MATCH exception: if both persons have the EXACT same set of name tokens
  // (≥2 tokens, same set — not just subset) AND the exact same birth year (both known,
  // equal), we merge them even if their relatives don't overlap. This handles the case
  // where GenoPro exports the same person in multiple sub-trees with different subsets
  // of their spouses/children listed. Example: "Евгений Дзех Александрович (1951)"
  // appears twice — once with spouses Людмила+Марина, once with spouse Маргарита.
  // These are the same person with 3 marriages, split across sub-trees.
  _isDuplicate(p1, p2, families1, families2, personMap1, personMap2) {
    if (!p1 || !p2 || p1.id === p2.id) return false;
    if (!this._fioMatches(p1, p2)) return false;
    if (!this._yearCompatible(p1, p2)) return false;

    // v87 strong match check: exact token set + year compatible → merge without relatives check
    // Applies when both have the exact same name token set (≥2 tokens) AND:
    //   - both years known and equal, OR
    //   - both years unknown (can't contradict)
    // This handles GenoPro's pattern of splitting one person across sub-trees with
    // different spouse/parent subsets. The exact full-name match makes false positives
    // very unlikely (would need two different people with identical 3-token names).
    if (this._isStrongNameMatch(p1, p2)) {
      const y1 = this.getBirthYear(p1);
      const y2 = this.getBirthYear(p2);
      if (y1 === null && y2 === null) {
        return true;  // both unknown — can't contradict, strong name match suffices
      }
      if (y1 !== null && y2 !== null && y1 === y2) {
        return true;  // both known and equal
      }
      // If one is known and the other isn't, fall through to relatives check
    }

    // v95: use role-aware relatives for compatibility check.
    const rels1 = this._relativesFromFamiliesWithRoles(p1.id, families1 || [], personMap1 || {});
    const rels2 = this._relativesFromFamiliesWithRoles(p2.id, families2 || [], personMap2 || {});
    if (!this._relativesCompatible(rels1, rels2)) return false;
    return true;
  },

  // v87: Check if two persons have the EXACT same set of name tokens (≥2 tokens).
  // This is a stronger check than _fioMatches (which uses subset matching).
  // v95 FIX: Strong name match now requires MINIMUM 3 tokens (full FIO) OR
  // 2 tokens + matching birth year (both known and equal). Previously 2 tokens
  // alone was enough, which caused false positives when multiple people in a
  // family share the same first+last name (e.g., "Владимир Дзех" appears as
  // both a named record with patronymic+year AND as a nameless placeholder
  // without patronymic — they were incorrectly merged, giving the merged
  // person the wrong family links from the placeholder).
  _isStrongNameMatch(p1, p2) {
    const t1 = this._mainNameTokens(p1);
    const t2 = this._mainNameTokens(p2);
    if (t1.length < 2 || t2.length < 2) return false;
    if (t1.length !== t2.length) return false;
    const s2 = new Set(t2);
    for (const t of t1) if (!s2.has(t)) return false;
    // v95: 2-token match is NOT strong enough on its own — require known+equal year.
    if (t1.length === 2) {
      const y1 = this.getBirthYear(p1);
      const y2 = this.getBirthYear(p2);
      if (y1 === null || y2 === null) return false;  // can't confirm without year
      if (y1 !== y2) return false;
    }
    // 3+ tokens (full FIO) — strong enough, proceed.
    return true;
  },

  // Merge source person fields into target. Non-empty source fields overwrite target.
  // Used both within parseGEDCOM (intra-file dedup) and _mergeGEDCOM (cross-file).
  // "More actual data" interpretation: prefer non-empty over empty; if both non-empty,
  // source (incoming/newer) overwrites target (existing/older).
  mergePersonData(target, source) {
    if (!target || !source) return target;
    const fields = ['firstName','lastName','patronymic','maidenName','gender',
                    'birthDate','deathDate','birthPlace','deathPlace','bio','photo','photo2','photo3','photoFileName','family','position','birthDateApprox'];
    fields.forEach(f => {
      const sv = source[f];
      if (sv !== undefined && sv !== null && String(sv).trim() !== '') {
        target[f] = sv;
      }
    });
    // Status: prefer the more specific one.
    if (source.status === 'deceased' || target.status === 'deceased') {
      target.status = 'deceased';
    } else if (source.status === 'alive' && target.status !== 'alive') {
      target.status = 'alive';
    } else if (target.status !== 'alive' && source.status) {
      target.status = source.status;
    }
    return target;
  },

  // Score a person record by how complete its data is. Used to pick the canonical
  // record when merging duplicates — the most complete one becomes the base.
  _completenessScore(p) {
    if (!p) return 0;
    let score = 0;
    if ((p.firstName || '').trim()) score += 1;
    if ((p.lastName || '').trim())  score += 1;
    if ((p.patronymic || '').trim()) score += 1;
    if ((p.maidenName || '').trim()) score += 1;
    if (this.getBirthYear(p))   score += 5;  // birth year is the most identifying field
    if ((p.deathDate || '').trim())   score += 2;
    if ((p.birthPlace || '').trim())  score += 1;
    if ((p.deathPlace || '').trim())  score += 1;
    if ((p.bio || '').trim())         score += 1;
    if ((p.photo || '').trim())       score += 1;
    return score;
  },

  // Cross-file duplicate detection: find an existing person that matches the
  // candidate. Used by _mergeGEDCOM (app.js) when importing into existing data.
  // `existingLinks` is the existing data.links array (used to compute existing
  // person's relatives). `incomingLinks` is the incoming data.links array
  // (used to compute candidate's relatives with roles).
  findDuplicate(existingPersons, candidate, existingLinks, incomingLinks, incomingPersons) {
    if (!existingPersons || !candidate) return null;
    const candRelsWithRoles = this._relativesWithRolesFromLinks(
      candidate.id, incomingLinks || [], incomingPersons || []
    );
    const candRels = candRelsWithRoles.map(r => r.person);
    const candTokens = this._mainNameTokens(candidate);
    const candIsNameless = candTokens.length < 2;  // nameless or single-token

    // Standard path: candidate has ≥2 name tokens — apply 3-criteria rule.
    if (!candIsNameless) {
      for (const p of existingPersons) {
        if (!this._fioMatches(p, candidate)) continue;
        if (!this._yearCompatible(p, candidate)) continue;

        // v87 strong match: exact token set + year compatible → merge without relatives check
        if (this._isStrongNameMatch(p, candidate)) {
          const y1 = this.getBirthYear(p);
          const y2 = this.getBirthYear(candidate);
          if (y1 === null && y2 === null) {
            return p;  // both unknown — strong name match suffices
          }
          if (y1 !== null && y2 !== null && y1 === y2) {
            return p;  // both known and equal
          }
          // If one is known and the other isn't, fall through to relatives check
        }

        const existRels = this._relativesFromLinks(p.id, existingLinks || [], existingPersons);
        if (!this._relativesCompatible(existRels, candRels)) continue;
        return p;
      }
      return null;
    }

    // Nameless/single-token candidate: fall back to relatives-based matching.
    // Look for existing nameless persons (also <2 tokens) who share at least 1
    // NAMED relative IN THE SAME ROLE with the candidate. The role check is
    // critical: a nameless child of Anna must not merge with a nameless spouse
    // of Anna — they have different relationships to the same named person.
    const candNamedRelsWithRoles = candRelsWithRoles.filter(
      r => this._mainNameTokens(r.person).length >= 2
    );
    if (candNamedRelsWithRoles.length === 0) return null;  // can't safely identify — skip

    for (const p of existingPersons) {
      const existTokens = this._mainNameTokens(p);
      if (existTokens.length >= 2) continue;  // only match nameless with nameless
      if (!this._yearCompatible(p, candidate)) continue;
      const existRelsWithRoles = this._relativesWithRolesFromLinks(p.id, existingLinks || [], existingPersons);
      const existNamedRelsWithRoles = existRelsWithRoles.filter(
        r => this._mainNameTokens(r.person).length >= 2
      );
      if (existNamedRelsWithRoles.length === 0) continue;
      // Check if any named relative overlaps IN THE SAME ROLE (by FIO match).
      let overlap = false;
      for (const r1 of candNamedRelsWithRoles) {
        for (const r2 of existNamedRelsWithRoles) {
          if (r1.role !== r2.role) continue;  // different roles → not the same person
          if (this._fioMatches(r1.person, r2.person)) { overlap = true; break; }
        }
        if (overlap) break;
      }
      if (overlap) return p;
    }
    return null;
  },

  // Compute relatives (as person objects) for a person based on data.links array.
  // Used by findDuplicate for cross-file dedup.
  _relativesFromLinks(pid, links, persons) {
    return this._relativesWithRolesFromLinks(pid, links, persons).map(r => r.person);
  },

  // Same as _relativesFromLinks but returns [{person, role}] where role is
  // 'parent' | 'spouse' | 'child' | 'sibling'. Used by findDuplicate's nameless
  // path to avoid merging a nameless child with a nameless spouse of the same
  // named person (different roles → not the same person).
  _relativesWithRolesFromLinks(pid, links, persons) {
    const map = {};
    (persons || []).forEach(p => { map[p.id] = p; });
    const result = [];
    const seen = new Set();  // key: roleId
    const push = (id, role) => {
      if (!id || !map[id] || id === pid) return;
      const key = role + '|' + id;
      if (seen.has(key)) return;
      seen.add(key);
      result.push({ person: map[id], role });
    };
    (links || []).forEach(l => {
      if (l.type === 'parent_child') {
        if (l.target === pid) push(l.source, 'parent');
        if (l.source === pid) push(l.target, 'child');
      } else if (l.type === 'marriage') {
        if (l.source === pid) push(l.target, 'spouse');
        if (l.target === pid) push(l.source, 'spouse');
      } else if (l.type === 'sibling') {
        if (l.source === pid) push(l.target, 'sibling');
        if (l.target === pid) push(l.source, 'sibling');
      }
    });
    return result;
  },

  // v87: Check if a person is "nameless" (no real name tokens).
  // Nameless persons have NAME "//" or empty — they're GenoPro placeholders.
  _isNameless(p) {
    if (!p) return true;
    const fn = (p.firstName || '').trim();
    const ln = (p.lastName || '').trim();
    const pt = (p.patronymic || '').trim();
    const hasReal = (t => t && t !== '/' && t !== '//');
    return !hasReal(fn) && !hasReal(ln) && !hasReal(pt);
  },

  // v87: Pre-merge nameless placeholders with named persons by POSITION.
  // See detailed comment in parseGEDCOM above.
  //
  // Strategy:
  // 1. Build position → [persons] map for ALL persons (named and nameless).
  // 2. For each nameless person at position P:
  //    a. Find named persons at the same position P.
  //    b. Determine the nameless person's role(s) in families (HUSB, WIFE, CHIL).
  //    c. If nameless is HUSB in some fam: find named MALE at P → remap.
  //       If nameless is WIFE in some fam: find named FEMALE at P → remap.
  //       If nameless is CHIL in some fam:
  //         - If exactly 1 named person at P → remap.
  //         - If multiple named persons at P → expand fam.children to include ALL
  //           named persons at P (and remove the nameless from children).
  //    d. If no named person at P, keep the nameless as-is (link anchor).
  // 3. Apply the remap to all family references (HUSB, WIFE, CHIL).
  // 4. Remove merged nameless persons from the persons array.
  _preMergeNamelessByPosition(persons, families) {
    if (!persons || !families) return;

    // Build position → persons map
    const byPos = {};
    persons.forEach(p => {
      if (!p.position) return;
      if (!byPos[p.position]) byPos[p.position] = [];
      byPos[p.position].push(p);
    });

    // Build family-role index for each person: which families reference them as HUSB/WIFE/CHIL
    const famRoles = {};  // personId → [{famId, role: 'HUSB'|'WIFE'|'CHIL'}]
    families.forEach(f => {
      if (f.husband) {
        if (!famRoles[f.husband]) famRoles[f.husband] = [];
        famRoles[f.husband].push({ famId: f.id, role: 'HUSB' });
      }
      if (f.wife) {
        if (!famRoles[f.wife]) famRoles[f.wife] = [];
        famRoles[f.wife].push({ famId: f.id, role: 'WIFE' });
      }
      (f.children || []).forEach(cid => {
        if (!famRoles[cid]) famRoles[cid] = [];
        famRoles[cid].push({ famId: f.id, role: 'CHIL' });
      });
    });

    // idRemap: namelessId → namedId (to replace references)
    const idRemap = {};
    // namelessIdsToRemove: set of nameless IDs that were merged into named persons
    const namelessIdsToRemove = new Set();
    // For each nameless person, try to find a named match at the same position
    persons.forEach(nameless => {
      if (!this._isNameless(nameless)) return;
      if (!nameless.position) return;  // nameless without position can't be matched
      const same = byPos[nameless.position] || [];
      const named = same.filter(p => !this._isNameless(p) && p.id !== nameless.id);
      if (named.length === 0) return;  // no named person at this position

      const roles = famRoles[nameless.id] || [];
      if (roles.length === 0) return;  // nameless not referenced in any family

      // Determine which role(s) the nameless plays
      const isHusb = roles.some(r => r.role === 'HUSB');
      const isWife = roles.some(r => r.role === 'WIFE');
      const isChil = roles.some(r => r.role === 'CHIL');

      if (isHusb || isWife) {
        // Find named person of matching gender at same position
        const wantGender = isHusb ? 'male' : 'female';
        const match = named.find(p => p.gender === wantGender);
        if (match) {
          idRemap[nameless.id] = match.id;
          namelessIdsToRemove.add(nameless.id);
          // Merge any data from nameless into match (though nameless usually has none)
          this.mergePersonData(match, nameless);
        }
      } else if (isChil) {
        // Nameless child: if exactly 1 named at same position, merge.
        // If multiple named, expand each family's children list to include ALL named.
        if (named.length === 1) {
          idRemap[nameless.id] = named[0].id;
          namelessIdsToRemove.add(nameless.id);
          this.mergePersonData(named[0], nameless);
        } else {
          // Multiple named persons at same position — expand families
          // For each family that has this nameless as a child, add ALL named persons
          // as children (and remove the nameless).
          roles.filter(r => r.role === 'CHIL').forEach(({ famId }) => {
            const fam = families.find(f => f.id === famId);
            if (!fam) return;
            // Remove nameless from children
            fam.children = fam.children.filter(cid => cid !== nameless.id);
            // Add all named persons at this position (avoiding duplicates)
            named.forEach(np => {
              if (!fam.children.includes(np.id)) {
                fam.children.push(np.id);
              }
            });
          });
          namelessIdsToRemove.add(nameless.id);
        }
      }
    });

    if (Object.keys(idRemap).length === 0 && namelessIdsToRemove.size === 0) return;

    // Apply idRemap to all family references
    families.forEach(f => {
      if (f.husband && idRemap[f.husband]) f.husband = idRemap[f.husband];
      if (f.wife && idRemap[f.wife]) f.wife = idRemap[f.wife];
      f.children = (f.children || []).map(cid => idRemap[cid] || cid);
      // Dedupe children after remap
      const seen = new Set();
      f.children = f.children.filter(cid => {
        if (seen.has(cid)) return false;
        seen.add(cid);
        return true;
      });
      // Self-marriage guard
      if (f.husband && f.husband === f.wife) f.wife = '';
    });

    // Remove merged nameless persons from the array (in-place filter)
    for (let i = persons.length - 1; i >= 0; i--) {
      if (namelessIdsToRemove.has(persons[i].id)) {
        persons.splice(i, 1);
      }
    }
  },

  // v87: Link orphaned named children (no FAMC) to families by position match.
  // Some GenoPro exports have named persons with a real name and position but NO
  // FAMC link. These are children whose family link was lost in export. We find
  // nameless CHIL placeholders in families and check if any named orphan shares
  // the same position — if so, the orphan is linked as a child of that family.
  //
  // This is a SECOND PASS after _preMergeNamelessByPosition, so nameless CHIL
  // placeholders that were already expanded are skipped. We look for REMAINING
  // nameless CHIL placeholders (those with no named person at exact same position)
  // and try to match nearby orphans.
  _linkOrphanedChildrenByPosition(persons, families) {
    if (!persons || !families) return;

    // Build position → named persons map
    const namedByPos = {};
    persons.forEach(p => {
      if (this._isNameless(p)) return;
      if (!p.position) return;
      if (!namedByPos[p.position]) namedByPos[p.position] = [];
      namedByPos[p.position].push(p);
    });

    // Find orphaned named persons: have a name, have a position, but are NOT
    // referenced in any family (no HUSB/WIFE/CHIL reference).
    const referencedIds = new Set();
    families.forEach(f => {
      if (f.husband) referencedIds.add(f.husband);
      if (f.wife) referencedIds.add(f.wife);
      (f.children || []).forEach(cid => referencedIds.add(cid));
    });

    const orphans = persons.filter(p =>
      !this._isNameless(p) &&
      p.position &&
      !referencedIds.has(p.id)
    );

    if (orphans.length === 0) return;

    // For each orphan, find a family that has a nameless CHIL at the same position
    // OR a family where the orphan's position matches a child position pattern.
    orphans.forEach(orphan => {
      // Find families with a nameless CHIL at the orphan's position
      families.forEach(fam => {
        const namelessChilAtSamePos = (fam.children || []).filter(cid => {
          const child = persons.find(p => p.id === cid);
          return child && this._isNameless(child) && child.position === orphan.position;
        });
        if (namelessChilAtSamePos.length > 0) {
          // Link orphan as child of this family (if not already)
          if (!fam.children.includes(orphan.id)) {
            fam.children.push(orphan.id);
            referencedIds.add(orphan.id);
          }
        }
      });
    });
  },

  // v100 (аудит #6): отчёт о последней дедупликации при импорте GEDCOM.
  // Заполняется в parseGEDCOM, читается вызывающим кодом (app.js) для показа
  // пользователю списка объединённых записей.
  _lastMergeReport: [],

  parseGEDCOM(text) {
    this._lastMergeReport = [];  // v100: сбрасываем отчёт перед новым парсингом
    const lines = text.split(/\r?\n/);
    const persons = [];
    const families = [];
    const personMap = {};
    const familyMap = {};
    let currentIndi = null;
    let currentFam  = null;
    let currentTag  = '';
    let currentNameTag = '';
    // v88: picture records (GenoPro PIC entries). Each PIC has id, fileName, name.
    const pictures = {};      // picId → { id, fileName, name, path }
    let currentPic = null;
    // v88: per-INDI list of PIC xrefs + which is PRIMARY
    const indiPictures = {};   // indiId → [{ picId, primary }]

    const makeIndi = (id) => ({
      id, gender: 'male', firstName: '', lastName: '',
      patronymic: '', maidenName: '', status: 'unknown',
      birthDate: '', birthDateApprox: false,
      deathDate: '', birthPlace: '', deathPlace: '',
      bio: '', photo: '', photo2: '', photo3: '', photoFileName: '', family: '',
      position: ''  // v87: GenoPro POSITION tag (x,y) — used for merging nameless placeholders
    });

    lines.forEach(rawLine => {
      const line = rawLine.trim();
      if (!line) return;
      const parts = line.split(/\s+/);
      const level = parseInt(parts[0]);
      if (isNaN(level)) return;

      let xref = '', tag = '', value = '';
      if (parts[1] && parts[1].startsWith('@') && parts[1].endsWith('@')) {
        xref = parts[1].replace(/@/g, '');
        tag  = parts[2] || '';
        value = parts.slice(3).join(' ');
      } else {
        tag   = parts[1] || '';
        value = parts.slice(2).join(' ');
      }

      if (level === 0) {
        if (currentIndi) { persons.push(currentIndi); currentIndi = null; }
        if (currentFam)  { families.push(currentFam); currentFam = null; }
        if (currentPic)  { pictures[currentPic.id] = currentPic; currentPic = null; }
        currentTag = '';

        if (tag === 'INDI' || value === 'INDI') {
          const id = xref || this.generateId();
          currentIndi = makeIndi(id);
          personMap[id] = currentIndi;
        } else if (tag === 'FAM' || value === 'FAM') {
          const id = xref || ('F' + families.length);
          currentFam = { id, husband: '', wife: '', children: [] };
          familyMap[id] = currentFam;
        } else if (tag === 'Picture' || value === 'Picture') {
          // v88: GenoPro Picture record (e.g. "0 @pic00001@ Picture")
          currentPic = { id: xref || ('pic' + Object.keys(pictures).length), fileName: '', name: '', path: '' };
        }
        return;
      }

      // v88: parse PIC record fields
      if (currentPic) {
        if (level === 1) {
          if (tag === 'PATH') currentPic.path = value;
          else if (tag === 'NAME') currentPic.name = value;
        } else if (level === 2) {
          if (tag === 'FILEUNIQUE') currentPic.fileName = value;
          else if (tag === 'RELATIVE' && !currentPic.path) currentPic.path = value;
        }
        return;  // PIC records don't have other meaningful subfields for our purposes
      }

      if (currentIndi) {
        if (level === 1) {
          currentNameTag = '';
          // v101 FIX Б6: Reset currentTag (BIRT/DEAT context) on every level-1 tag
          // to prevent DATE from a different event (OCCU, RESI, etc.) being
          // mis-attributed to BIRT/DEAT.
          if (tag !== 'BIRT' && tag !== 'DEAT') currentTag = '';
          if (tag === 'NAME') {
            // v87 FIX: improved NAME parsing for GenoPro's empty-surname format.
            // GenoPro exports names like "Бахтиярова Елена //" (surname field empty,
            // lastName put in firstPart before firstName) and "Екатерина //" (single
            // token, surname empty). The v85/v86 regex `/^(.*?)\s*\/(.+?)\//` required
            // ≥1 char between slashes, so these fell to the else branch where
            // "Бахтиярова Елена //" was mis-parsed as firstName="Бахтиярова",
            // patronymic="Елена", lastName="//".
            //
            // v87 strategy:
            // 1. Try normal slash regex `/Surname/` (≥1 char) — handles standard format
            // 2. If no match, try empty-slash regex `//` at end — handles GenoPro's
            //    empty-surname export. For these, parse firstPart as:
            //    - 1 token → firstName only
            //    - 2 tokens → [lastName, firstName] (GenoPro puts surname first)
            //    - 3+ tokens → [firstName, patronymic..., lastName] (standard Russian order)
            // 3. If neither matches, fall back to v85 space-split logic.
            const slashMatch = value.match(/^(.*?)\s*\/(.+?)\//);
            if (slashMatch) {
              const firstPart = slashMatch[1].trim();
              currentIndi.lastName = slashMatch[2].trim();
              const nameParts = firstPart.split(/\s+/).filter(Boolean);
              currentIndi.firstName = nameParts[0] || '';
              currentIndi.patronymic = nameParts.slice(1).join(' ').trim();
            } else {
              // v87: check for empty-surname pattern (trailing //)
              const emptySlashMatch = value.match(/^(.*?)\s*\/\/\s*$/);
              if (emptySlashMatch) {
                const firstPart = emptySlashMatch[1].trim();
                const nameParts = firstPart.split(/\s+/).filter(Boolean);
                if (nameParts.length === 0) {
                  // NAME " //" — truly nameless, leave empty
                } else if (nameParts.length === 1) {
                  currentIndi.firstName = nameParts[0];
                } else if (nameParts.length === 2) {
                  // GenoPro style: [lastName, firstName] — e.g. "Бахтиярова Елена"
                  currentIndi.lastName = nameParts[0];
                  currentIndi.firstName = nameParts[1];
                } else {
                  // 3+ tokens: standard Russian [firstName, patronymic..., lastName]
                  // e.g. "Татьяна ВикторовнаСолдатова Панфилова"
                  currentIndi.firstName = nameParts[0];
                  currentIndi.lastName = nameParts[nameParts.length - 1];
                  currentIndi.patronymic = nameParts.slice(1, -1).join(' ').trim();
                }
              } else {
                // v85 fallback: no slashes at all, split by spaces
                const nameParts = value.trim().split(/\s+/).filter(Boolean);
                if (nameParts.length >= 3) {
                  currentIndi.firstName = nameParts[0];
                  currentIndi.patronymic = nameParts[1];
                  currentIndi.lastName = nameParts[2];
                } else if (nameParts.length === 2) {
                  currentIndi.firstName = nameParts[0];
                  currentIndi.lastName = nameParts[1];
                } else {
                  currentIndi.firstName = value;
                }
              }
            }
            currentNameTag = 'NAME';
          } else if (tag === 'SEX') {
            currentIndi.gender = (value === 'F' || value === 'f') ? 'female' : 'male';
          } else if (tag === 'BIRT') { currentTag = 'BIRT'; }
          else if (tag === 'DEAT') { currentTag = 'DEAT'; if (value.trim()) currentIndi.status = 'deceased'; }
          else if (tag === 'POSITION') {
            // v87: store GenoPro POSITION (x,y) for nameless-placeholder merging
            currentIndi.position = value.trim();
          }
          else if (tag === 'PICTURES') {
            // v88: GenoPro PICTURES tag references one or more @picXXXX@ records.
            // Value format: "@pic00001@" or "@pic00001@, @pic00002@"
            // The PRIMARY picture is indicated by a "2 PRIMARY @picX@" sub-tag.
            const picIds = value.split(',').map(s => s.replace(/@/g, '').trim()).filter(Boolean);
            if (!indiPictures[currentIndi.id]) indiPictures[currentIndi.id] = [];
            picIds.forEach(picId => {
              if (!indiPictures[currentIndi.id].find(p => p.picId === picId)) {
                indiPictures[currentIndi.id].push({ picId, primary: false });
              }
            });
          }
          else if (tag === 'NOTE' && value) {
            currentIndi.bio = (currentIndi.bio ? currentIndi.bio + ' ' : '') + value.replace(/@/g, '');
          }
        } else if (level === 2) {
          // v88: PRIMARY tag under PICTURES indicates which picture is the main one
          if (tag === 'PRIMARY' && currentIndi.id && value) {
            const primaryPicId = value.replace(/@/g, '').trim();
            if (indiPictures[currentIndi.id]) {
              indiPictures[currentIndi.id].forEach(p => {
                if (p.picId === primaryPicId) p.primary = true;
              });
            }
          }
          if (tag === 'DATE') {
            // v100 FIX (аудит #1): раньше парсер извлекал ТОЛЬКО год (\d{4}),
            // из-за чего полная дата «15.03.1990» после round-trip через work.ged
            // превращалась в «1990». Теперь сохраняем полную дату как есть,
            // если в значении есть что-то кроме года (день/месяц).
            const yr = value.match(/(\d{4})/);
            const trimmed = value.trim();
            // Полная дата = значение содержит больше, чем просто 4-значный год
            const dateVal = (yr && trimmed !== yr[1]) ? trimmed : (yr ? yr[1] : trimmed);
            if (currentTag === 'BIRT' && !currentIndi.birthDate) currentIndi.birthDate = dateVal;
            if (currentTag === 'DEAT' && !currentIndi.deathDate) { currentIndi.deathDate = dateVal; currentIndi.status = 'deceased'; }
          } else if (tag === 'PLAC') {
            if (currentTag === 'BIRT') currentIndi.birthPlace = value;
            if (currentTag === 'DEAT') currentIndi.deathPlace = value;
          // v96: _APPROX tag marks birth date as approximate (computed from relatives)
          } else if (tag === '_APPROX') {
            if (currentTag === 'BIRT') currentIndi.birthDateApprox = true;
          // v87 FIX: GIVN/SURN only set the field if NAME parsing left it empty.
          // GenoPro sometimes puts wrong values in GIVN (e.g., surname in GIVN field
          // for "Бахтиярова Елена //" where GIVN="Бахтиярова" but firstName should be
          // "Елена" from NAME parsing). By only applying GIVN/SURN as fallback, we
          // keep the NAME tag as the authoritative source.
          } else if (tag === 'GIVN') {
            if (!currentIndi.firstName) currentIndi.firstName = value;
          }
          else if (tag === 'SURN') {
            if (!currentIndi.lastName) currentIndi.lastName = value;
          }
          // v86 NOTE: MIDDLE tag intentionally NOT parsed — in this GEDCOM it
          // contains malformed values like "ВикторовнаСолдатова  Панфилова"
          // (patronymic + lastName concatenated), which would overwrite the
          // correctly-parsed patronymic from the NAME tag. v85 doesn't parse
          // MIDDLE either; we preserve that behavior.
          else if (tag === '_PATN' || tag === '_PATR') { currentIndi.patronymic = value; }
          else if (tag === '_MAID') { currentIndi.maidenName = value; }
          else if (tag === 'CONT' && currentIndi.bio) { currentIndi.bio += '\n' + value; }
          else if (tag === 'NOTE' && value) { currentIndi.bio = (currentIndi.bio ? currentIndi.bio + ' ' : '') + value; }
        }
      } else if (currentFam) {
        if (level === 1) {
          if (tag === 'HUSB') currentFam.husband = value.replace(/@/g, '');
          else if (tag === 'WIFE') currentFam.wife = value.replace(/@/g, '');
          else if (tag === 'CHIL') currentFam.children.push(value.replace(/@/g, ''));
        }
      }
    });

    if (currentIndi) persons.push(currentIndi);
    if (currentFam)  families.push(currentFam);
    if (currentPic)  pictures[currentPic.id] = currentPic;

    // v88: assign photoFileName to each person based on their PRIMARY picture (or first picture).
    // The "photoFileName" stores the original GEDCOM file name so users can later
    // match it against local photo files via the "Загрузить фото" button in Settings.
    persons.forEach(p => {
      const pics = indiPictures[p.id];
      if (!pics || pics.length === 0) return;
      // Prefer PRIMARY picture; fall back to first listed.
      const primary = pics.find(x => x.primary) || pics[0];
      const pic = pictures[primary.picId];
      if (!pic) return;
      // Prefer the human-readable NAME from PIC record (matches the user's example
      // "1955 dzekh vlad1 copy.jpg"). If NAME is missing, fall back to fileName
      // (the FILEUNIQUE field, which strips spaces — e.g. "1955dzekhVlad1Copy.jpg").
      // If both are missing, use the basename of PATH.
      let photoName = pic.name;
      if (!photoName) {
        photoName = pic.fileName;
      }
      if (!photoName && pic.path) {
        // Extract basename from PATH like "\\Marcus\d\!Photo-scan\История\Дзех\1955 dzekh vlad1 copy.jpg"
        const m = pic.path.match(/[^\\/]+$/);
        if (m) photoName = m[0];
      }
      if (photoName) {
        // Normalize: ensure it has a file extension; if not, leave as-is (NAME may be just a label)
        p.photoFileName = photoName.trim();
      }
    });

    // Mark status
    persons.forEach(p => {
      if (p.status === 'deceased') return;
      p.status = (!p.deathDate && p.birthDate) ? 'alive' : 'unknown';
    });

    // ---- v87 PRE-MERGE: merge nameless placeholders with named persons by POSITION ----
    // GenoPro exports ONE person as multiple INDI records: a NAMED record (with real
    // name, birth year, etc.) and one or more NAMELESS records (NAME="//") that serve
    // as link anchors in FAM records. The nameless records share the same POSITION
    // (x,y canvas coordinate) as the named record.
    //
    // Example from "Поповы 1 + Кутасовы" file:
    //   ind00055 "Ирина Владимировна Журавлева Афиногенова" at position -30,-230
    //     → FAMS=[fam00024] (she's WIFE in fam00024)
    //   ind00076 "//" (nameless) at position -30,-230
    //     → FAMS=[fam00025] (she's WIFE in fam00025)
    //   fam00025: HUSB=ind00036 (Андрей Журавлев), WIFE=ind00076 (nameless), CHIL=ind00077 (nameless)
    //
    // Without pre-merge, fam00025's WIFE is a nameless placeholder, so Ирина is not
    // recognized as Андрей's wife. Pre-merge remaps ind00076 → ind00055 so fam00025
    // becomes: HUSB=Андрей, WIFE=Ирина, CHIL=[expanded children].
    //
    // For nameless CHIL placeholders: if multiple named persons share the same
    // position, ALL of them are added as children of that family (GenoPro stacks
    // siblings at the same position).
    this._preMergeNamelessByPosition(persons, families);

    // v87: also link orphaned named children (no FAMC) to families by position match.
    // Some GenoPro exports have named children with NO FAMC tag whose POSITION matches
    // a nameless CHIL in some family. We link them as additional children.
    this._linkOrphanedChildrenByPosition(persons, families);

    // ---- v86 DEDUPLICATION ----
    // Replaces v5.4 strict key-based dedup with user's 3-criteria rule:
    //   1. FIO compatible (≥2 of firstName/lastName/patronymic tokens shared)
    //   2. Birth year compatible (not contradictory)
    //   3. Relatives compatible (overlap or one side has no named relatives)
    // GenoPro exports one person as multiple INDI records (one per family they
    // belong to). v5.4 missed these because strict key required exact name+year.
    // Result: Anna Panfilova 1985 (only marriage family) and Anna Panfilova
    // (only parents family) appeared as two separate cards with broken links.
    // v86 merges them so the merged person has BOTH parents and marriage links.

    // Build a personMap for relatives lookup.
    const fullPersonMap = {};
    persons.forEach(p => { fullPersonMap[p.id] = p; });

    // Union-Find structure for grouping duplicates.
    const parent = {};
    persons.forEach(p => { parent[p.id] = p.id; });
    const find = x => {
      while (parent[x] !== x) {
        parent[x] = parent[parent[x]];  // path compression
        x = parent[x];
      }
      return x;
    };
    const union = (a, b) => {
      const ra = find(a), rb = find(b);
      if (ra !== rb) parent[ra] = rb;
    };

    // Skip nameless persons (no firstName AND no lastName) from dedup — they
    // are GEDCOM artifacts and should stay as separate link anchors.
    const dedupCandidates = persons.filter(p =>
      (p.firstName && p.firstName.trim() && p.firstName !== '/' && p.firstName !== '//') ||
      (p.lastName  && p.lastName.trim()  && p.lastName  !== '/' && p.lastName  !== '//')
    );

    // v100 PERF (аудит Perf #2): вместо честного O(n²)-перебора всех пар —
    // блокировка кандидатов по общему токену имени. Дубликаты по определению
    // обязаны иметь ≥2 общих токена ФИО (_fioMatches), поэтому достаточно
    // сравнивать только людей, у которых есть хотя бы один общий токен.
    // Для 500 человек это сокращает 125 000 сравнений до нескольких сотен.
    // Токены кешируются один раз на человека (раньше пересчитывались в каждой паре).
    const tokenCache = new Map();  // personId → tokens[]
    dedupCandidates.forEach(p => tokenCache.set(p.id, this._mainNameTokens(p)));

    const tokenBuckets = new Map();  // token → [person, ...]
    dedupCandidates.forEach(p => {
      tokenCache.get(p.id).forEach(t => {
        if (!tokenBuckets.has(t)) tokenBuckets.set(t, []);
        tokenBuckets.get(t).push(p);
      });
    });

    const comparedPairs = new Set();  // "idA|idB" — чтобы не сравнивать пару дважды
    tokenBuckets.forEach(bucket => {
      if (bucket.length < 2) return;
      for (let i = 0; i < bucket.length; i++) {
        for (let j = i + 1; j < bucket.length; j++) {
          const p1 = bucket[i];
          const p2 = bucket[j];
          const pairKey = p1.id < p2.id ? p1.id + '|' + p2.id : p2.id + '|' + p1.id;
          if (comparedPairs.has(pairKey)) continue;
          comparedPairs.add(pairKey);
          if (find(p1.id) === find(p2.id)) continue;  // already in same group
          if (this._isDuplicate(p1, p2, families, families, fullPersonMap, fullPersonMap)) {
            union(p1.id, p2.id);
          }
        }
      }
    });

    // Build idRemap: every original ID → canonical ID of its group.
    // Canonical ID = the ID of the group member with the MOST non-empty fields
    // (so the most complete record becomes the base for merging).
    const groupMembers = {};  // canonicalId → [person, ...]
    persons.forEach(p => {
      const root = find(p.id);
      if (!groupMembers[root]) groupMembers[root] = [];
      groupMembers[root].push(p);
    });

    const idRemap = {};  // oldId → canonicalId
    Object.keys(groupMembers).forEach(root => {
      const members = groupMembers[root];
      // Pick canonical = member with most non-empty fields (prefer one with birthDate).
      let best = members[0];
      let bestScore = this._completenessScore(best);
      for (let i = 1; i < members.length; i++) {
        const score = this._completenessScore(members[i]);
        if (score > bestScore) {
          best = members[i];
          bestScore = score;
        }
      }
      const canonicalId = best.id;
      members.forEach(m => { idRemap[m.id] = canonicalId; });
      // v100 (аудит #6): собираем отчёт о слияниях — раньше дедупликация была
      // «тихой», и пользователь не знал, что записи были объединены.
      if (members.length > 1) {
        this._lastMergeReport.push({
          kept: this.getFullName(best) || best.id,
          mergedCount: members.length - 1,
          merged: members.filter(m => m.id !== canonicalId)
                         .map(m => this.getFullName(m) || m.id)
        });
      }
      // Merge all other members' data INTO the canonical person.
      members.forEach(m => {
        if (m.id === canonicalId) return;
        this.mergePersonData(best, m);
      });
    });

    // Remap family references to canonical IDs.
    // Also handle side effects: if HUSB and WIFE both remap to same canonical ID
    // (self-marriage), drop one. Dedupe children list.
    families.forEach(f => {
      f.husband = f.husband ? (idRemap[f.husband] || f.husband) : '';
      f.wife    = f.wife    ? (idRemap[f.wife]    || f.wife)    : '';
      f.children = f.children.map(cid => idRemap[cid] || cid);
      // Dedupe children (a person might be listed twice after remap).
      const seen = new Set();
      f.children = f.children.filter(cid => {
        if (seen.has(cid)) return false;
        seen.add(cid);
        return true;
      });
      // Self-marriage guard: if husband and wife are the same person, clear wife.
      if (f.husband && f.husband === f.wife) f.wife = '';
    });

    // Remove duplicate persons (keep only canonical IDs).
    const canonicalIds = new Set(Object.values(idRemap));
    const dedupedPersons = persons.filter(p => canonicalIds.has(p.id) && idRemap[p.id] === p.id);

    // Rebuild personMap with deduped persons (includes nameless ones for link resolution).
    const dedupedPersonMap = {};
    dedupedPersons.forEach(p => { dedupedPersonMap[p.id] = p; });

    // Build links from remapped families.
    // v5.3/v5.4 limits retained: max 2 parents per child, max 3 spouses per person.
    const links = [];
    let linkId = 0;
    const seenMarriages = new Set();
    const seenParentChild = new Set();
    const parentsPerChild = {};
    const spousesPerPerson = {};

    families.forEach(f => {
      // Marriage link (dedup + spouse limit)
      if (f.husband && f.wife && dedupedPersonMap[f.husband] && dedupedPersonMap[f.wife] && f.husband !== f.wife) {
        const mkey = [f.husband, f.wife].sort().join('|');
        if (!seenMarriages.has(mkey)) {
          if (!spousesPerPerson[f.husband]) spousesPerPerson[f.husband] = 0;
          if (!spousesPerPerson[f.wife]) spousesPerPerson[f.wife] = 0;
          if (spousesPerPerson[f.husband] < 3 && spousesPerPerson[f.wife] < 3) {
            seenMarriages.add(mkey);
            spousesPerPerson[f.husband]++;
            spousesPerPerson[f.wife]++;
            links.push({ id: 'gl' + (linkId++), type: 'marriage', source: f.husband, target: f.wife });
          }
        }
      }
      // Parent-child links (dedup + 2-parent limit)
      const parents = [f.husband, f.wife].filter(id => id && dedupedPersonMap[id]);
      f.children.forEach(childId => {
        if (!dedupedPersonMap[childId]) return;
        if (!parentsPerChild[childId]) parentsPerChild[childId] = 0;
        parents.forEach(parentId => {
          if (parentId === childId) return;
          if (parentsPerChild[childId] >= 2) return;
          const pkey = parentId + '|' + childId;
          if (seenParentChild.has(pkey)) return;
          seenParentChild.add(pkey);
          parentsPerChild[childId]++;
          links.push({ id: 'gl' + (linkId++), type: 'parent_child', source: parentId, target: childId });
        });
      });
    });

    // v87: filter out only fully-nameless persons who are NOT referenced by any link.
    // v85/v86 kept "//" names because the old regex parsed them as firstName="//" (truthy).
    // v87's improved NAME parsing correctly produces empty strings for "//", so we need
    // to explicitly check: keep a person if they have a real name OR are a link endpoint.
    const linkedIds = new Set();
    links.forEach(l => { linkedIds.add(l.source); linkedIds.add(l.target); });
    const validPersons = dedupedPersons.filter(p => {
      // Has a real name (not just "/" or "//")
      const fn = (p.firstName || '').trim();
      const ln = (p.lastName || '').trim();
      const pt = (p.patronymic || '').trim();
      const hasName = (fn && fn !== '/' && fn !== '//') ||
                      (ln && ln !== '/' && ln !== '//') ||
                      (pt && pt !== '/' && pt !== '//');
      if (hasName) return true;
      // Nameless but is a link endpoint — keep so links don't dangle
      if (linkedIds.has(p.id)) return true;
      return false;
    });
    console.log('GEDCOM parse:', validPersons.length, 'persons (after dedup from', persons.length, '),', links.length, 'links');

    return {
      persons: validPersons,
      links,
      families: [],
      meta: { name: 'GEDCOM Import', created: new Date().toISOString(), modified: new Date().toISOString() }
    };
  },

  // ---- Generation label ----
  toRoman(num) {
    const vals = [1000,900,500,400,100,90,50,40,10,9,5,4,1];
    const syms = ['M','CM','D','CD','C','XC','L','XL','X','IX','V','IV','I'];
    let result = '';
    for (let i = 0; i < vals.length; i++) {
      while (num >= vals[i]) { result += syms[i]; num -= vals[i]; }
    }
    return result;
  },

  getGenerationLabel(gen) {
    const g = i18n.t('gen.generation');
    const labels = {
      0: `${g} I — ${i18n.t('gen.oldest')}`,
      1: `${g} II`, 2: `${g} III`, 3: `${g} IV`, 4: `${g} V`,
      5: `${g} VI`, 6: `${g} VII`, 7: `${g} VIII`, 8: `${g} IX`,
      9: `${g} X — ${i18n.t('gen.youngest')}`
    };
    return labels[gen] !== undefined ? labels[gen] : `${g} ${this.toRoman(gen + 1)}`;
  },

  // ---- Family colors ----
  defaultColors: ['#6ab0ff','#ffc660','#6aff9a','#ff6a6a','#c39bd3',
                  '#ffc480','#5bc0de','#ff9f43','#a29bfe','#fd79a8'],

  buildFamilyColors(families, existingColors = {}) {
    const colors = Object.assign({}, existingColors);
    let idx = Object.keys(colors).length;
    (families || []).forEach(f => {
      if (f.name && !colors[f.name]) {
        colors[f.name] = f.color || this.defaultColors[idx++ % this.defaultColors.length];
      }
    });
    return colors;
  }
};
