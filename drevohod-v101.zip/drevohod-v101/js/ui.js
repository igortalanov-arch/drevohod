// ui.js — UI helpers: modals, toast, theme, toolbar, keyboard, minimap, zoom
// Drevohod v4.5 Arena Edition

const ui = {
  // ---- Theme ----
  setTheme(theme) {
    document.body.setAttribute('data-theme', theme);
    const btn = document.getElementById('btn-theme');
    // v100 (аудит UX #4): иконка показывает СЛЕДУЮЩУЮ тему (ту, на которую
    // переключит кнопка), а не текущую — раньше это сбивало с толку.
    // Тема light → показываем 🌙 («переключить на тёмную»), dark → ☀️.
    if (btn) {
      btn.querySelector('span').textContent = theme === 'dark' ? '☀️' : '🌙';
      btn.title = theme === 'dark'
        ? (i18n.currentLang === 'en' ? 'Switch to light theme' : 'Переключить на светлую тему')
        : (i18n.currentLang === 'en' ? 'Switch to dark theme' : 'Переключить на тёмную тему');
    }
    const st = document.getElementById('settings-theme');
    if (st) st.value = theme;
    storage.saveTheme(theme);
  },

  toggleTheme(currentTheme) {
    const next = currentTheme === 'dark' ? 'light' : 'dark';
    this.setTheme(next);
    return next;
  },

  // ---- Lang toggle ----
  applyLangUI(lang) {
    // Toggle active/inactive marker on Ru/En button
    const ru = document.getElementById('lang-ru');
    const en = document.getElementById('lang-en');
    if (ru && en) {
      if (lang === 'ru') { ru.className = 'lang-active'; en.className = 'lang-inactive'; }
      else               { ru.className = 'lang-inactive'; en.className = 'lang-active'; }
    }

    const t = (key) => i18n.t(key);

    // Helper: set textContent of element by id if it exists
    const setText = (id, text) => { const el = document.getElementById(id); if (el) el.textContent = text; };
    // Helper: set innerHTML of element by id if it exists
    const setHtml = (id, html) => { const el = document.getElementById(id); if (el) el.innerHTML = html; };

    // ---- Start screen ----
    // Note: app name (Древоход / Drevohol) in start-title intentionally NOT translated per requirement
    const subtitle = document.querySelector('.start-subtitle');
    if (subtitle) subtitle.textContent = t('app.subtitle');
    setText('start-version', t('app.version'));

    // Start-screen buttons (label/desc inside .start-btn)
    const startBtns = document.querySelectorAll('.start-btn');
    const startKeys = [
      // continue, new, demo, load
      { label: t('start.continue'),  desc: t('start.continueDesc') },
      { label: t('start.new'),       desc: t('start.newDesc') },
      { label: t('start.demo'),      desc: t('start.demoDesc') },
      { label: t('start.load'),      desc: t('start.loadDesc') },
    ];
    startBtns.forEach((btn, i) => {
      if (startKeys[i]) {
        const lbl = btn.querySelector('.label');
        const dsc = btn.querySelector('.desc');
        if (lbl) lbl.textContent = startKeys[i].label;
        if (dsc && i !== 0) dsc.textContent = startKeys[i].desc; // index 0 = continue, desc is dynamic
      }
    });
    const recentH3 = document.querySelector('.start-recent h3');
    if (recentH3) recentH3.textContent = t('start.recent');

    // ---- Toolbar — view mode buttons (btn-text spans) ----
    // btn-tree removed. Only btn-tree2 / btn-cards / btn-table remain.
    const tree2Btn = document.getElementById('btn-tree2');
    const cardsBtn = document.getElementById('btn-cards');
    const tableBtn = document.getElementById('btn-table');
    if (tree2Btn) { const s = tree2Btn.querySelector('.btn-text'); if (s) s.textContent = t('view.tree2'); }
    if (cardsBtn) { const s = cardsBtn.querySelector('.btn-text'); if (s) s.textContent = t('view.cards'); }
    if (tableBtn) { const s = tableBtn.querySelector('.btn-text'); if (s) s.textContent = t('view.table'); }

    // Tree v2.0 sidebar
    document.querySelectorAll('[data-i18n]').forEach(el => {
      const key = el.getAttribute('data-i18n');
      if (key && key.startsWith('tree2.')) {
        el.textContent = t(key);
      }
    });

    // Toolbar action buttons (Add, Search, Tree from, Print)
    document.querySelectorAll('.toolbar-row .btn .btn-text').forEach(span => {
      const cur = span.textContent.trim();
      const map = {
        'Добавить': t('toolbar.add'), 'Add': t('toolbar.add'),
        'Поиск': t('toolbar.search'), 'Search': t('toolbar.search'),
        'Дерево от...': t('toolbar.treeFrom'), 'Tree from...': t('toolbar.treeFrom'),
        'Печать': t('toolbar.print'), 'Print': t('toolbar.print'),
      };
      if (map[cur] !== undefined) span.textContent = map[cur];
    });

    // Fix #5: translate ALL tooltips (title attributes)
    // btn-tree / btn-tree-orientation removed.
    const tipMap = {
      'btn-home':              t('tip.home'),
      'btn-tree2':             t('tip.tree2'),
      'btn-cards':             t('tip.cards'),
      'btn-table':             t('tip.table'),
      'btn-toolbar-collapse':  t('tip.collapse'),
      'btn-lang':              t('tip.lang'),
      'btn-theme':             t('tip.theme'),
    };
    Object.entries(tipMap).forEach(([id, tip]) => {
      const el = document.getElementById(id);
      if (el) el.title = tip;
    });
    // Toolbar icon-only buttons by onclick
    document.querySelectorAll('.toolbar-row .btn-icon, .toolbar-row .btn').forEach(btn => {
      const oc = btn.getAttribute('onclick') || '';
      if (oc.includes('showAddPerson')) btn.title = t('tip.add');
      else if (oc.includes('showSearch')) btn.title = t('tip.search');
      else if (oc.includes('showTreeFrom')) btn.title = t('tip.treeFrom');
      else if (oc.includes('exportPDF')) btn.title = t('tip.print');
      else if (oc.includes('saveData')) btn.title = t('tip.save');
      else if (oc.includes('validateAll')) btn.title = t('tip.validate');
      else if (oc.includes('showHelp')) btn.title = t('tip.help');
      else if (oc.includes('showSettings')) btn.title = t('tip.settings');
      else if (oc.includes('showAbout')) btn.title = t('tip.about');
    });
    // Filter buttons tooltips
    document.querySelectorAll('[data-filter]').forEach(btn => {
      const f = btn.getAttribute('data-filter');
      if (f === 'all') btn.title = t('tip.filterAll');
      else if (f === 'alive') btn.title = t('tip.filterAlive');
      else if (f === 'deceased') btn.title = t('tip.filterDead');
    });
    // Zoom buttons
    document.querySelectorAll('#zoom-controls .btn').forEach(btn => {
      const oc = btn.getAttribute('onclick') || '';
      if (oc.includes('zoomIn')) btn.title = t('tip.zoomIn');
      else if (oc.includes('zoomOut')) btn.title = t('tip.zoomOut');
      else if (oc.includes('zoomReset')) btn.title = t('tip.zoomReset');
    });
    const sidebarToggle = document.getElementById('sidebar-toggle');
    if (sidebarToggle) sidebarToggle.title = t('tip.sidebar');

    // Filter banner reset button
    const bannerClose = document.getElementById('filter-banner-close');
    if (bannerClose) bannerClose.textContent = lang === 'ru' ? '✕ Сбросить фильтр' : '✕ Clear filter';

    // ---- Status bar hint ----
    const hintEl = document.getElementById('status-hint');
    if (hintEl) hintEl.textContent = `Ctrl+S — ${t('hint.save')} | F1 — ${t('hint.help')}`;

    // ---- Search modal static text ----
    const smTitle = document.getElementById('search-modal-title');
    if (smTitle) smTitle.textContent = t('search.title');
    const sName = document.getElementById('search-name');
    if (sName) sName.placeholder = t('search.placeholder');
    // Search select options (family/gender/status/generation) — reset to translated defaults
    const searchFamily = document.getElementById('search-family');
    if (searchFamily && searchFamily.options[0]) searchFamily.options[0].textContent = lang === 'ru' ? 'Все семьи' : 'All families';
    const searchGender = document.getElementById('search-gender');
    if (searchGender) {
      const opts = [t('search.anyGender'), t('search.men'), t('search.women')];
      [...searchGender.options].forEach((o, i) => { if (opts[i] !== undefined) o.textContent = opts[i]; });
    }
    const searchStatus = document.getElementById('search-status');
    if (searchStatus) {
      const opts = [t('search.anyStatus'), t('search.alive'), t('search.deceased'), t('search.unknown')];
      [...searchStatus.options].forEach((o, i) => { if (opts[i] !== undefined) o.textContent = opts[i]; });
    }
    const searchGen = document.getElementById('search-generation');
    if (searchGen && searchGen.options[0]) searchGen.options[0].textContent = lang === 'ru' ? 'Все поколения' : 'All generations';
    const incLabel = document.querySelector('label[for="search-incomplete"]') ||
      document.querySelector('#modal-search label');
    // translate incomplete checkbox label
    const incLbl = document.getElementById('search-incomplete-label');
    if (incLbl) incLbl.textContent = t('search.incomplete');

    // FIX #3: translate import buttons in modal-add
    const addImportLabel = document.getElementById('add-modal-import-label');
    if (addImportLabel) addImportLabel.textContent = t('add.importLabel') || (lang === 'en' ? 'Import data:' : 'Импорт данных:');
    const addImportJson = document.getElementById('add-modal-import-json-label');
    if (addImportJson) addImportJson.textContent = t('add.importJSON') || (lang === 'en' ? 'Import JSON' : 'Импорт JSON');
    const addImportGed = document.getElementById('add-modal-import-ged-label');
    if (addImportGed) addImportGed.textContent = t('add.importGEDCOM') || (lang === 'en' ? 'Import GEDCOM' : 'Импорт GEDCOM');
    const addImportJsonBtn = document.getElementById('add-modal-import-json-btn');
    if (addImportJsonBtn) addImportJsonBtn.title = lang === 'en' ? 'Import from JSON file' : 'Импортировать из JSON файла';
    const addImportGedBtn = document.getElementById('add-modal-import-ged-btn');
    if (addImportGedBtn) addImportGedBtn.title = lang === 'en' ? 'Import from GEDCOM (.ged) file' : 'Импортировать из GEDCOM (.ged) файла';

    // FIX #2: translate modal titles
    const modalTitleMap = {
      'modal-settings':       t('modal.settings'),
      'modal-validation':     t('modal.validation'),
      'modal-help':           t('modal.help'),
      'modal-about':          t('modal.about'),
      'modal-unsaved':        t('modal.unsaved'),
      'modal-select-person':  t('modal.selectPerson'),
      'modal-tree-from':      '🌲 ' + t('treeFrom.title'),
    };
    Object.entries(modalTitleMap).forEach(([id, title]) => {
      const el = document.querySelector(`#${id} .modal-title`);
      if (el && !el.querySelector('span[id]')) el.textContent = title;
    });

    // FIX #2: translate settings buttons
    const settingsBtnMap = {
      saveData:    t('settings.saveData'),
      exportJSON:  t('settings.exportJson'),
      exportGEDCOM:t('settings.exportGedcom'),
      exportBackup:t('settings.backup'),
      importJSON:  t('settings.importJson'),
      importGEDCOM:t('settings.importGedcom'),
      exportPDF:   t('settings.print'),
      clearAllData:t('settings.clearAll'),
    };
    document.querySelectorAll('#modal-settings .btn-lg').forEach(btn => {
      const oc = btn.getAttribute('onclick') || '';
      Object.entries(settingsBtnMap).forEach(([fnName, label]) => {
        if (oc.includes(fnName + '()')) btn.textContent = label;
      });
    });

    // FIX #2: translate settings section titles
    document.querySelectorAll('#modal-settings .panel-section-title').forEach(el => {
      const t2 = el.textContent.trim();
      if (t2 === 'Внешний вид' || t2 === 'Appearance') el.textContent = t('settings.appearance');
      if (t2 === 'Данные' || t2 === 'Data') el.textContent = t('settings.data');
      if (t2 === 'О приложении' || t2 === 'About') el.textContent = t('about.title');
    });

    // FIX #2: translate filter-banner close button
    const filterClose = document.getElementById('filter-banner-close');
    if (filterClose) filterClose.textContent = t('filter.reset');

    // FIX #2: translate start-screen theme button
    const startThemeSpan = document.querySelector('#btn-theme-start span[data-i18n]');
    if (startThemeSpan) startThemeSpan.textContent = t('start.changeTheme');

    // FIX #2: translate add-form section title 'Связи с родственниками'
    document.querySelectorAll('#modal-add .panel-section-title').forEach(el => {
      const t2 = el.textContent.trim();
      if (t2 === 'Связи с родственниками' || t2 === 'Relative links') el.textContent = t('form.relLinks');
    });

    // FIX #2: translate add-form button labels
    document.querySelectorAll('#modal-add .modal-footer .btn').forEach(btn => {
      const oc = btn.getAttribute('onclick') || '';
      const txt = btn.textContent.trim();
      if (oc.includes('closeModal') && (txt === 'Отмена' || txt === 'Cancel')) btn.textContent = t('form.cancel');
      if (oc.includes('submitAddPerson') && (txt === 'Добавить' || txt === 'Add')) btn.textContent = t('add.submit');
    });
    const addSubmitBtn = document.getElementById('modal-add-submit');
    // only set if not in edit mode (will be overridden by editPerson if editing)
    if (addSubmitBtn && (addSubmitBtn.textContent === 'Добавить' || addSubmitBtn.textContent === 'Add')) {
      addSubmitBtn.textContent = t('add.submit');
    }

    // FIX #2: translate photo upload button
    document.querySelectorAll('#modal-add .btn-sm').forEach(btn => {
      const oc = btn.getAttribute('onclick') || '';
      const txt = btn.textContent.trim();
      if (oc.includes('add-photo-input') && !oc.includes('delete') && (txt.includes('Фото') || txt.includes('photo'))) {
        btn.textContent = t('form.uploadPhoto');
      }
    });
    const photoDeleteBtn = document.getElementById('add-photo-delete');
    if (photoDeleteBtn) photoDeleteBtn.textContent = t('form.deletePhoto');

    // FIX #2: translate add-form relative buttons
    document.querySelectorAll('#modal-add .btn-sm[onclick*="addRelativeRow"]').forEach(btn => {
      const oc = btn.getAttribute('onclick') || '';
      const typeMatch = oc.match(/'(\w+)'/);
      if (typeMatch) {
        const relType = typeMatch[1];
        const icons = { parent:'👤', child:'👶', spouse:'💍', brother:'👦', sister:'👧' };
        const icon = icons[relType] || '';
        const label = i18n.t('add.' + relType) || relType;
        btn.innerHTML = `${icon} <span>${label}</span>`;
      }
    });

    // FIX #2: translate unsaved modal buttons
    document.querySelectorAll('#modal-unsaved .modal-footer .btn').forEach(btn => {
      const oc = btn.getAttribute('onclick') || '';
      const txt = btn.textContent.trim();
      if (oc.includes('discardUnsaved')) btn.textContent = t('unsaved.discard');
      if (!oc && (txt === 'Отмена' || txt === 'Cancel')) btn.textContent = t('form.cancel');
      if (oc.includes('saveThenContinue')) btn.textContent = t('unsaved.save');
    });
    const unsavedBody = document.querySelector('#modal-unsaved .modal-body p');
    if (unsavedBody) unsavedBody.textContent = t('unsaved.msg');

    // ---- Tree-from modal ----
    const tfSearch = document.getElementById('tree-from-search');
    if (tfSearch) tfSearch.placeholder = lang === 'ru' ? 'Поиск по имени...' : 'Search by name...';
    const tfDepth = document.getElementById('tree-from-depth');
    if (tfDepth) {
      const opts = [t('treeFrom.all'), t('treeFrom.ancestors'), t('treeFrom.descendants'), t('treeFrom.2gen'), t('treeFrom.3gen'), t('treeFrom.4gen')];
      [...tfDepth.options].forEach((o, i) => { if (opts[i]) o.textContent = opts[i]; });
    }
    // Translate tree-from modal title
    const tfTitle = document.querySelector('#modal-tree-from .modal-title');
    if (tfTitle) tfTitle.textContent = '🌲 ' + t('treeFrom.title');

    // ---- Select-person modal ----
    const spSearch = document.getElementById('select-person-search');
    if (spSearch) spSearch.placeholder = lang === 'ru' ? 'Поиск по имени...' : 'Search by name...';

    // ---- About modal — update translated content if modal is currently open ----
    const aboutBody = document.getElementById('about-body');
    if (aboutBody && aboutBody.innerHTML.trim() !== '') {
      // Re-render about content with current lang
      this._updateAboutLang();
    }

    // ---- Add-person form labels (static, hardcoded in HTML) ----
    // These are rendered once in HTML — we leave form labels untranslated for now
    // as they are inside the modal and the form is rebuilt each open.
    // Family select option
    const addFamily = document.getElementById('add-family');
    if (addFamily && addFamily.options[0]) addFamily.options[0].textContent = t('form.noFamily');
    // Fix #5: translate add/edit form labels
    this._translateFormLabels(lang);
  },

  // Fix #5: translate add/edit form labels dynamically
  _translateFormLabels(lang) {
    const t = (key) => i18n.t(key);
    // Add modal title labels (in HTML they're hardcoded, we update via data-i18n)
    document.querySelectorAll('[data-i18n]').forEach(el => {
      const key = el.getAttribute('data-i18n');
      if (key) {
        const val = t(key);
        if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') el.placeholder = val;
        else if (el.getAttribute('data-i18n-type') === 'title') el.title = val;
        else el.textContent = val;
      }
    });
    // Translate gender options in add form
    const addGender = document.getElementById('add-gender');
    if (addGender) {
      if (addGender.options[0]) addGender.options[0].textContent = t('form.male');
      if (addGender.options[1]) addGender.options[1].textContent = t('form.female');
    }
    // Translate status options in add form
    const addStatus = document.getElementById('add-status');
    if (addStatus) {
      if (addStatus.options[0]) addStatus.options[0].textContent = t('form.alive');
      if (addStatus.options[1]) addStatus.options[1].textContent = t('form.deceased');
      if (addStatus.options[2]) addStatus.options[2].textContent = t('form.unknown');
    }
    // Translate settings theme options
    const settingsTheme = document.getElementById('settings-theme');
    if (settingsTheme) {
      if (settingsTheme.options[0]) settingsTheme.options[0].textContent = t('settings.dark');
      if (settingsTheme.options[1]) settingsTheme.options[1].textContent = t('settings.light');
    }
  },

  // Update translated elements inside the About modal (called when modal is open and lang changes)
  _updateAboutLang() {
    const t = (key) => i18n.t(key);
    const setText = (id, text) => { const el = document.getElementById(id); if (el) el.textContent = text; };
    const setHtml = (id, html) => { const el = document.getElementById(id); if (el) el.innerHTML = html; };

    setText('about-features-title', t('app.about.modesTitle'));
    // tree v1.0 about section removed — only tree2 / cards / table remain.
    setText('about-mode-tree2-title', t('about.tree2Title'));
    setHtml('about-mode-tree2-desc',  t('about.tree2Desc'));
    setText('about-mode-cards-title', t('about.cardsTitle'));
    setHtml('about-mode-cards-desc',  t('about.cardsDesc'));
    setText('about-mode-table-title', t('about.tableTitle'));
    setHtml('about-mode-table-desc',  t('about.tableDesc'));
    setText('about-search-title',  t('about.searchTitle'));
    setHtml('about-search-desc',   t('about.searchDesc'));
    setText('about-save-title',    t('about.saveTitle'));
    setHtml('about-save-desc',     t('about.saveDesc'));
    setText('about-keys-title',    t('about.keysTitle'));
    setText('about-key-save',      t('about.keySave'));
    setText('about-key-search',    t('about.keySearch'));
    setText('about-key-help',      t('about.keyHelp'));
    setText('about-key-escape',    t('about.keyEscape'));
    setText('about-key-modes',     t('about.keyModes'));
  },

  // ---- Modals ----
  openModal(id) {
    const overlay = document.getElementById(id);
    if (!overlay) return;
    overlay.classList.add('visible');
    overlay.onclick = (e) => { if (e.target === overlay) overlay.classList.remove('visible'); };
    const modal = overlay.querySelector('.modal');
    if (modal) {
      modal.scrollTop = 0;
      const body = modal.querySelector('.modal-body');
      if (body) body.scrollTop = 0;
    }
    overlay.scrollTop = 0;
  },

  closeModal(id) {
    const el = document.getElementById(id);
    if (el) el.classList.remove('visible');
  },

  closeAllModals() {
    document.querySelectorAll('.modal-overlay.visible').forEach(m => m.classList.remove('visible'));
  },

  // v100 (аудит UX #1): кастомный prompt-диалог вместо нативного window.prompt.
  // Возвращает Promise<string|null> (null = отмена). Поддерживает type: 'text' | 'password'
  // — пароль больше НЕ отображается открытым текстом, как это было с prompt().
  showPrompt(message, { title = null, defaultValue = '', type = 'text', placeholder = '' } = {}) {
    return new Promise((resolve) => {
      const titleText = title || (i18n.currentLang === 'en' ? 'Input' : 'Ввод');
      const okText = 'OK';
      const cancelText = i18n.currentLang === 'en' ? 'Cancel' : 'Отмена';

      let overlay = document.getElementById('modal-prompt');
      if (!overlay) {
        overlay = document.createElement('div');
        overlay.id = 'modal-prompt';
        overlay.className = 'modal-overlay';
        overlay.innerHTML = `
          <div class="modal" style="max-width:440px">
            <div class="modal-header">
              <span class="modal-title" id="prompt-title"></span>
              <button class="modal-close" id="prompt-close">&times;</button>
            </div>
            <div class="modal-body">
              <div id="prompt-message" style="white-space:pre-wrap;margin-bottom:10px;font-size:14px;line-height:1.5"></div>
              <input id="prompt-input" class="form-input" style="width:100%;box-sizing:border-box">
            </div>
            <div class="modal-footer" style="display:flex;gap:8px;justify-content:flex-end;padding:12px 16px;border-top:1px solid var(--border-color)">
              <button class="btn btn-sm" id="prompt-cancel"></button>
              <button class="btn btn-primary btn-sm" id="prompt-ok"></button>
            </div>
          </div>`;
        document.body.appendChild(overlay);
      }
      document.getElementById('prompt-title').textContent = titleText;
      document.getElementById('prompt-message').textContent = message;
      const input = document.getElementById('prompt-input');
      input.type = type === 'password' ? 'password' : 'text';
      input.value = defaultValue || '';
      input.placeholder = placeholder || '';
      document.getElementById('prompt-ok').textContent = okText;
      document.getElementById('prompt-cancel').textContent = cancelText;
      overlay.classList.add('visible');
      overlay.style.display = 'flex';

      const finish = (val) => {
        overlay.classList.remove('visible');
        overlay.style.display = 'none';
        input.onkeydown = null;
        resolve(val);
      };
      document.getElementById('prompt-ok').onclick = () => finish(input.value);
      document.getElementById('prompt-cancel').onclick = () => finish(null);
      document.getElementById('prompt-close').onclick = () => finish(null);
      input.onkeydown = (e) => {
        if (e.key === 'Enter') finish(input.value);
        if (e.key === 'Escape') finish(null);
      };
      setTimeout(() => input.focus(), 50);
    });
  },

  // ---- Toast ----
  showToast(message) {
    let toast = document.getElementById('toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'toast';
      document.body.appendChild(toast);
    }
    toast.textContent = message;
    toast.style.opacity = '1';
    clearTimeout(this._toastTimer);
    this._toastTimer = setTimeout(() => { toast.style.opacity = '0'; }, 2500);
  },

  // v73 #13: non-blocking alert replacement. Shows a modal dialog with the
  // message and OK + Copy buttons. Falls back to window.alert if no modal container.
  showAlert(message, title) {
    const t = (k) => i18n.t ? i18n.t(k) : k;
    const titleText = title || (i18n.currentLang === 'en' ? 'Notice' : 'Уведомление');
    const okText = i18n.currentLang === 'en' ? 'OK' : 'OK';
    const copyText = i18n.currentLang === 'en' ? 'Copy' : 'Копировать';

    // Use existing modal infrastructure if available; otherwise build minimal dialog
    let overlay = document.getElementById('modal-alert');
    if (!overlay) {
      overlay = document.createElement('div');
      overlay.id = 'modal-alert';
      overlay.className = 'modal-overlay';
      overlay.innerHTML = `
        <div class="modal" style="max-width:500px">
          <div class="modal-header">
            <span class="modal-title" id="alert-title"></span>
            <button class="modal-close" id="alert-close">&times;</button>
          </div>
          <div class="modal-body" id="alert-body" style="white-space:pre-wrap;word-break:break-word;font-family:monospace;font-size:13px;line-height:1.5;max-height:60vh;overflow-y:auto"></div>
          <div class="modal-footer" style="display:flex;gap:8px;justify-content:flex-end;padding:12px 16px;border-top:1px solid var(--border-color)">
            <button class="btn btn-sm" id="alert-copy">${copyText}</button>
            <button class="btn btn-primary btn-sm" id="alert-ok">${okText}</button>
          </div>
        </div>`;
      document.body.appendChild(overlay);
    }
    document.getElementById('alert-title').textContent = titleText;
    document.getElementById('alert-body').textContent = message;
    overlay.classList.add('visible');
    overlay.style.display = 'flex';

    const close = () => {
      overlay.classList.remove('visible');
      overlay.style.display = 'none';
    };
    document.getElementById('alert-close').onclick = close;
    document.getElementById('alert-ok').onclick = close;
    document.getElementById('alert-copy').onclick = () => {
      if (navigator.clipboard) {
        navigator.clipboard.writeText(message).then(() => {
          this.showToast(i18n.currentLang === 'en' ? 'Copied' : 'Скопировано');
        });
      } else {
        // Fallback for non-secure contexts
        const ta = document.createElement('textarea');
        ta.value = message;
        document.body.appendChild(ta);
        ta.select();
        try { document.execCommand('copy'); } catch (e) {}
        document.body.removeChild(ta);
        this.showToast(i18n.currentLang === 'en' ? 'Copied' : 'Скопировано');
      }
    };
    // Click outside to close
    overlay.onclick = (e) => { if (e.target === overlay) close(); };
  },

  // ---- Toolbar collapse ----
  toggleToolbarCollapse(collapsed) {
    const tb = document.getElementById('toolbar');
    if (!tb) return collapsed;
    if (collapsed) {
      tb.classList.add('collapsed');
      document.documentElement.style.setProperty('--toolbar-h', '56px');
    } else {
      tb.classList.remove('collapsed');
      document.documentElement.style.setProperty('--toolbar-h', '112px');
    }
    const icon = document.getElementById('toolbar-collapse-icon');
    if (icon) icon.textContent = collapsed ? '▲' : '▼';
    return collapsed;
  },

  // ---- Filter banner ----
  showFilterBanner(name, onClose) {
    const banner = document.getElementById('filter-banner');
    const text   = document.getElementById('filter-banner-text');
    if (!banner || !text) return;
    text.textContent = `${i18n.t('toolbar.treeFrom')}: ${name}`;
    banner.classList.add('visible');
    document.body.classList.add('filter-active'); // FIX #3
    document.getElementById('filter-banner-close').onclick = onClose;
    // Translate close button
    const closeBtn = document.getElementById('filter-banner-close');
    if (closeBtn) closeBtn.textContent = i18n.t('filter.reset');
  },

  hideFilterBanner() {
    const banner = document.getElementById('filter-banner');
    if (banner) banner.classList.remove('visible');
    document.body.classList.remove('filter-active'); // FIX #3
  },

  // ---- Filter status buttons ----
  setFilterButtons(status) {
    ['all','alive','deceased'].forEach(s => {
      document.querySelectorAll(`[data-filter="${s}"]`).forEach(btn => {
        btn.classList.toggle('active', s === status);
      });
    });
  },

  // ---- View buttons ----
  setViewButtons(view) {
    // 'tree' button removed — only tree2 / cards / table remain.
    ['tree2','cards','table'].forEach(v => {
      const btn = document.getElementById('btn-' + v);
      if (btn) btn.classList.toggle('active', v === view);
    });
  },

  // ---- Status bar ----
  updateStatusBar(data, issues, lang) {
    const alive    = data.persons.filter(p => p.status === 'alive').length;
    const deceased = data.persons.filter(p => p.status === 'deceased').length;
    const famCount = new Set(data.persons.map(p => p.family).filter(Boolean)).size;

    const pEl = document.getElementById('status-people');
    if (pEl) pEl.textContent = `${data.persons.length} ${i18n.t('status.people')} (${i18n.t('status.alive')}: ${alive}, ${i18n.t('status.deceased')}: ${deceased})`;

    const fEl = document.getElementById('status-families');
    if (fEl) fEl.textContent = `${famCount} ${i18n.t('status.families')}`;

    const hEl = document.getElementById('status-hint');
    if (hEl) hEl.textContent = `Ctrl+S — ${i18n.t('hint.save')} | F1 — ${i18n.t('hint.help')}`;

    const valEl = document.getElementById('status-validation');
    if (valEl) {
      if (issues.length > 0) {
        valEl.innerHTML = `<span class="validation-badge warning" style="cursor:pointer" id="status-val-btn">⚠ ${issues.length} ${i18n.t('status.problems')}</span>`;
      } else if (data.persons.length > 0) {
        valEl.innerHTML = `<span class="validation-badge ok">✓ OK</span>`;
      } else {
        valEl.innerHTML = '';
      }
    }
  },

  // ---- Unsaved dot ----
  setUnsaved(unsaved) {
    const dot = document.getElementById('unsaved-dot');
    if (!dot) return;
    if (unsaved) {
      dot.classList.add('visible');
      if (!document.title.startsWith('●')) document.title = '● ' + document.title.replace(/^● /, '');
    } else {
      dot.classList.remove('visible');
      document.title = document.title.replace(/^● /, '');
    }
  },

  // tree v1.0 functions (applyZoom, updateMinimap, setupMinimapDrag,
  // applyTreeOrientationUI) are now no-ops — the elements they manipulated
  // (#tree-content, #minimap-svg, #btn-tree-orientation) have been removed.
  // Kept as no-ops so any stray callers don't crash.
  applyZoom(level) { /* no-op: tree v1.0 removed */ },
  updateMinimap(data, familyColors) { /* no-op: tree v1.0 removed */ },
  setupMinimapDrag() { /* no-op: tree v1.0 removed */ },
  applyTreeOrientationUI(orientation) { /* no-op: tree v1.0 removed */ },

  // ---- Family selects ----
  updateFamilySelects(data, i18nRef) {
    const familyNames = [...new Set(data.persons.map(p => p.family).filter(Boolean))];
    ['add-family', 'search-family'].forEach(id => {
      const select = document.getElementById(id);
      if (!select) return;
      const current = select.value;
      const firstOpt = select.options[0].outerHTML;
      select.innerHTML = firstOpt;
      familyNames.forEach(name => {
        const opt = document.createElement('option');
        opt.value = name; opt.textContent = name;
        select.appendChild(opt);
      });
      if (id === 'add-family') {
        const newOpt = document.createElement('option');
        newOpt.value = '__new__';
        newOpt.textContent = i18nRef.t('newFamily.option');
        select.appendChild(newOpt);
      }
      select.value = current;
    });
  },

  updateGenerationSelects(data, dataModule) {
    const select = document.getElementById('search-generation');
    if (!select) return;
    const current = select.value;
    const firstOpt = select.options[0].outerHTML;
    select.innerHTML = firstOpt;
    const gens = new Set();
    data.persons.forEach(p => gens.add(dataModule.getGeneration(data.persons, data.links, p.id)));
    [...gens].sort((a, b) => a - b).forEach(g => {
      const opt = document.createElement('option');
      opt.value = g;
      opt.textContent = dataModule.getGenerationLabel(g);
      select.appendChild(opt);
    });
    select.value = current;
  },

  // ---- Photo helpers ----
  resizeAndPreview(file, previewId, dataId, onDone) {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const maxSize = 400;
        let w = img.width, h = img.height;
        if (w > maxSize || h > maxSize) {
          if (w > h) { h = Math.round(h * maxSize / w); w = maxSize; }
          else { w = Math.round(w * maxSize / h); h = maxSize; }
        }
        canvas.width = w; canvas.height = h;
        canvas.getContext('2d').drawImage(img, 0, 0, w, h);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.82);
        const preview = document.getElementById(previewId);
        if (preview) preview.innerHTML = `<img src="${dataUrl}" alt="">`;
        const hidden = document.getElementById(dataId);
        if (hidden) hidden.value = dataUrl;
        if (onDone) onDone(dataUrl);
      };
      img.src = e.target.result;
    };
    reader.readAsDataURL(file);
  },

  // ---- About content ----
  buildAboutHTML(icon, changelog) {
    const t = (key) => i18n.t(key);
    let clHtml = '';
    changelog.forEach(entry => {
      clHtml += `<div style="margin-bottom:12px">
        <div style="font-size:14px;font-weight:600;color:var(--accent)">v${entry.ver} <span style="font-size:12px;color:var(--text-muted);font-weight:400">${entry.date}</span></div>
        <ul style="font-size:12px;line-height:1.7;color:var(--text-secondary);padding-left:16px;margin:4px 0 0 0">
        ${entry.changes.map(c => `<li>${c}</li>`).join('')}
        </ul></div>`;
    });
    return `
      <div style="text-align:center;margin-bottom:20px">
        <div style="display:flex;justify-content:center;margin-bottom:8px"><img src="${icon}" alt="Древоход" style="width:80px;height:80px"></div>
        <h2 style="margin:0;font-size:24px;background:linear-gradient(135deg,var(--accent),#a78bfa);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text">Древоход</h2>
        <p style="color:var(--text-muted);font-size:14px;margin-top:4px">${t('app.version')}</p>
      </div>
      <div class="panel-section">
        <div class="panel-section-title">${i18n.currentLang === 'ru' ? 'О программе' : 'About'}</div>
        <p style="font-size:14px;line-height:1.7;color:var(--text-secondary)">${t('app.about.desc')}</p>
      </div>
      <div class="panel-section">
        <div class="panel-section-title" id="about-features-title">${t('app.about.modesTitle')}</div>
        <div id="about-features-body" style="font-size:13px;line-height:1.75;color:var(--text-secondary)">
          <p><strong id="about-mode-tree2-title">${t('about.tree2Title')}</strong></p>
          <p id="about-mode-tree2-desc">${t('about.tree2Desc')}</p>

          <p style="margin-top:10px"><strong id="about-mode-cards-title">${t('about.cardsTitle')}</strong></p>
          <p id="about-mode-cards-desc">${t('about.cardsDesc')}</p>

          <p style="margin-top:10px"><strong id="about-mode-table-title">${t('about.tableTitle')}</strong></p>
          <p id="about-mode-table-desc">${t('about.tableDesc')}</p>

          <p style="margin-top:10px"><strong id="about-search-title">${t('about.searchTitle')}</strong></p>
          <p id="about-search-desc">${t('about.searchDesc')}</p>

          <p style="margin-top:10px"><strong id="about-save-title">${t('about.saveTitle')}</strong></p>
          <p id="about-save-desc">${t('about.saveDesc')}</p>

          <p style="margin-top:10px"><strong id="about-keys-title">${t('about.keysTitle')}</strong></p>
          <table style="font-size:13px;width:100%;border-collapse:collapse">
            <tr><td style="padding:3px 8px;color:var(--text-muted);white-space:nowrap">Ctrl+S</td><td id="about-key-save">${t('about.keySave')}</td></tr>
            <tr><td style="padding:3px 8px;color:var(--text-muted);white-space:nowrap">Ctrl+F</td><td id="about-key-search">${t('about.keySearch')}</td></tr>
            <tr><td style="padding:3px 8px;color:var(--text-muted);white-space:nowrap">F1</td><td id="about-key-help">${t('about.keyHelp')}</td></tr>
            <tr><td style="padding:3px 8px;color:var(--text-muted);white-space:nowrap">Escape</td><td id="about-key-escape">${t('about.keyEscape')}</td></tr>
            <tr><td style="padding:3px 8px;color:var(--text-muted);white-space:nowrap">1 / 2 / 3 / 4</td><td id="about-key-modes">${t('about.keyModes')}</td></tr>
          </table>
        </div>
      </div>
      <div class="panel-section">
        <div class="panel-section-title" id="about-changelog-title">${t('app.about.changelog')}</div>
        <div style="max-height:250px;overflow-y:auto">${clHtml}</div>
      </div>
      <div style="text-align:center;margin-top:16px;padding-top:16px;border-top:2px solid var(--border-color)">
        <p style="font-size:15px;font-weight:700;color:var(--text-primary);margin-bottom:4px">
          <strong>${i18n.currentLang === 'ru' ? 'Автор:' : 'Author:'}</strong> ${t('app.author')}
        </p>
        <p style="font-size:14px;color:var(--text-secondary);margin-bottom:10px">© 2026</p>
        <p style="font-size:13px;color:var(--text-muted);line-height:1.7;max-width:440px;margin:0 auto">
          ${t('app.license')}
        </p>
      </div>`;
  },

  buildHelpHTML() {
    const t   = (key) => i18n.t(key);
    const isEn = i18n.currentLang === 'en';
    const ru = (ruText, enText) => isEn ? enText : ruText;
    return `
      <style>
        .help-section { margin-bottom: 18px; }
        .help-section-title {
          font-size: 13px; font-weight: 700; color: var(--accent);
          text-transform: uppercase; letter-spacing: 0.5px;
          border-bottom: 2px solid var(--accent-light); padding-bottom: 4px; margin-bottom: 8px;
        }
        .help-p { font-size: 13px; line-height: 1.7; color: var(--text-secondary); margin-bottom: 5px; }
        .help-ul { font-size: 13px; line-height: 1.7; color: var(--text-secondary); padding-left: 18px; margin-bottom: 5px; }
        .help-ul li { margin-bottom: 2px; }
        .help-kbd {
          display: inline-block; background: var(--bg-input); border: 1px solid var(--border-color);
          border-radius: 4px; padding: 1px 7px; font-size: 12px; font-family: monospace;
          color: var(--text-primary); white-space: nowrap;
        }
        .help-kbtable { width: 100%; font-size: 13px; border-collapse: collapse; }
        .help-kbtable td { padding: 4px 8px; border-bottom: 1px solid var(--border-light); }
        .help-kbtable td:first-child { white-space: nowrap; width: 150px; }
      </style>

      <div class="help-section">
        <div class="help-section-title">🌲 ${t('about.tree2Title')}</div>
        <p class="help-p">${ru(
          'Основной режим. Послойная (tidy tree) схема для деревьев любого размера — от 15 человек до 500+. Каждый связный компонент (несвязанное поддерево) располагается вертикально один под другим с заголовком «Дерево N: Фамилия (X чел.)». Корень компонента — сверху, поколения идут вниз. Каждое поддерево резервирует достаточно горизонтального пространства, поэтому карточки 150×50px никогда не перекрываются — даже при 500+ человек.',
          'Main mode. Layered (tidy tree) layout for trees of any size — from 15 people to 500+. Each connected component (disconnected subtree) is stacked vertically with a header «Tree N: Surname (X people)». Component root at top, generations go down. Each subtree reserves enough horizontal space, so 150×50px cards never overlap — even with 500+ people.'
        )}</p>
        <p class="help-p" style="margin-top:8px"><strong>${ru('Три режима просмотра (кнопки в сайдбаре слева):','Three view modes (sidebar buttons on the left):')}</strong></p>
        <ul class="help-ul">
          <li><strong>${ru('🌲 Полное дерево','🌲 Full tree')}</strong> — ${ru('все поколения, все люди. По умолчанию для деревьев до 200 человек.','all generations, all people. Default for trees up to 200 people.')}</li>
          <li><strong>${ru('📁 Папка','📁 Folder')}</strong> — ${ru('ветви с &gt;3 детей сворачиваются в жёлтые карточки «[+] N детей». Клик по папке разворачивает её с пересчётом layout — дети получают корректные позиции. Кнопки «📂+» / «📂−» в сайдбаре разворачивают/сворачивают все папки сразу. По умолчанию для деревьев &gt;200 человек.','branches with &gt;3 children collapse into yellow «[+] N children» cards. Click a folder to expand it with a layout recompute — children get proper positions. «📂+» / «📂−» buttons in the sidebar expand/collapse all folders at once. Default for trees &gt;200 people.')}</li>
          <li><strong>${ru('🌳 Потомки','🌳 Descendants')}</strong> — ${ru('фокус на потомках выбранного человека и их супругах. Выберите карточку, затем переключитесь в этот режим.','focus on the selected person\'s descendants and their spouses. Select a card, then switch to this mode.')}</li>
        </ul>
        <p class="help-p" style="margin-top:8px"><strong>${ru('Масштаб (3 уровня зума):','Zoom (3 levels):')}</strong></p>
        <ul class="help-ul">
          <li><strong>${ru('🛰 10% (спутник)','🛰 10% (satellite)')}</strong> — ${ru('точки-персоны, цвет = семья. Общий обзор всего дерева.','person dots, colour = family. Bird\'s-eye view of the whole tree.')}</li>
          <li><strong>${ru('🗂 40% (структурный)','🗂 40% (structural)')}</strong> — ${ru('только фамилии и год рождения. Поиск «где тут Ивановы?»','surnames and birth year only. «Where are the Ivanovs?» overview.')}</li>
          <li><strong>${ru('🎯 100% (рабочий)','🎯 100% (working)')}</strong> — ${ru('полные ФИО, годы жизни, иконки брака ⚮/⚭. Детальный просмотр.','full names, life years, marriage icons ⚮/⚭. Detailed view.')}</li>
        </ul>
        <p class="help-p" style="margin-top:8px"><strong>${ru('Клик по карточке — подсветка связей уровня «семья»:','Click on a card — family-level connection highlight:')}</strong></p>
        <ul class="help-ul">
          <li>${ru('Подсвечиваются: выбранная карточка + её родители + супруг(а) + свои дети + общие с супругом дети + внуки.','Highlights: the selected card + their parents + spouse(s) + own children + shared children + grandchildren.')}</li>
          <li>${ru('Жирные синие связи parent→child с акцентной тенью; пунктирная розовая связь брака с супругом.','Thick blue parent→child links with accent shadow; dashed pink marriage link to the spouse.')}</li>
          <li>${ru('Связи стыкуются с краем карточки в точке подхода (сверху/снизу/слева/справа/в углу), а не идут к центру.','Links dock to the card edge at the approach point (top/bottom/left/right/corner), not to the centre.')}</li>
          <li>${ru('Неподсвеченные карточки затемнены до 25% прозрачности; линии без видимых endpoint\'ов не рисуются (нет «висящих» связей).','Non-highlighted cards dimmed to 25% opacity; lines without visible endpoints are not drawn (no dangling links).')}</li>
          <li><strong>${ru('Повторный клик на той же карточке','Repeated click on the same card')}</strong> — ${ru('снимает подсветку (toggle).','clears the highlight (toggle).')}</li>
        </ul>
        <p class="help-p" style="margin-top:8px"><strong>${ru('Контекстное меню (правая кнопка мыши):','Context menu (right-click):')}</strong></p>
        <ul class="help-ul">
          <li><strong>${ru('Показать всех потомков / предков / сиблингов / супругов','Show all descendants / ancestors / siblings / spouses')}</strong> — ${ru('фокусирует карту на этих родственниках. Повторный клик на том же человеке снимает фокус (toggle).','focuses the map on these relatives. Repeated click on the same person clears the focus (toggle).')}</li>
          <li><strong>${ru('Сделать центром','Make centre')}</strong> — ${ru('центрирует карту на выбранном человеке. Повторный выбор ре-центрирует (idempotent).','centres the map on the selected person. Repeated click re-centres (idempotent).')}</li>
          <li><strong>${ru('Открыть карточку персоны','Open person card')}</strong> — ${ru('открывает детальную панель справа. Закрытие — по крестику или повторному клику «Открыть карточку».','opens the detail panel on the right. Close via the ✕ button or repeated «Open card» click.')}</li>
          <li><strong>${ru('Сбросить фокус','Reset focus')}</strong> — ${ru('очищает всю подсветку и фокус, закрывает детальную панель.','clears all highlight and focus, closes the detail panel.')}</li>
        </ul>
        <p class="help-p" style="margin-top:8px"><strong>${ru('Навигация:','Navigation:')}</strong></p>
        <ul class="help-ul">
          <li><strong>${ru('Колесо мыши','Mouse wheel')}</strong> — ${ru('зум ( курсор остаётся якорем).','zoom (cursor stays anchored).')}</li>
          <li><strong>${ru('Зажатая ЛКМ + перетаскивание','Hold LMB + drag')}</strong> — ${ru('панорамирование карты.','pan the map.')}</li>
          <li><strong>${ru('Мини-карта (правый нижний угол)','Minimap (bottom right)')}</strong> — ${ru('клик/перетаскивание прямоугольника перемещает viewport. Показывает «N точек».','click/drag the rectangle to move the viewport. Shows «N points».')}</li>
          <li><strong>${ru('Слайдер глубины 1–10','Depth slider 1–10')}</strong> — ${ru('скрывает поколения глубже выбранного. Пресеты: ⬆️ Предки (3), ⬇️ Потомки (5), 🌳 Полное (10).','hides generations deeper than the selected one. Presets: ⬆️ Ancestors (3), ⬇️ Descendants (5), 🌳 Full (10).')}</li>
          <li><strong>${ru('Цветовая полоса семьи слева на каждой карточке','Family colour stripe on the left of every card')}</strong> — ${ru('визуально отслеживает ветви семей.','visually traces family branches.')}</li>
          <li><strong>${ru('Скобка «}» над сиблингами','«}» bracket above siblings')}</strong> — ${ru('группирует детей одних родителей.','groups children of the same parents.')}</li>
        </ul>
        <p class="help-p" style="margin-top:8px"><strong>${ru('Перформанс:','Performance:')}</strong> ${ru('viewport culling — рисуются только видимые в текущей области узлы и связи (при 500+ человек обычно ~50, не 524). Все операции (зум, пан, клик, переключение режимов) — 0–1 мс. Bubble-resolve после layout отталкивает перекрывающиеся карточки.','viewport culling — only nodes and links visible in the current area are drawn (with 500+ people usually ~50, not 524). All operations (zoom, pan, click, mode switching) — 0–1 ms. Bubble-resolve after layout pushes overlapping cards apart.')}</p>
        <p class="help-p" style="margin-top:8px"><strong>${ru('Cross-mode выбор:','Cross-mode selection:')}</strong> ${ru('выбранный человек сохраняется при переходе между всеми режимами (Дерево → Карточки → Таблица → Дерево). В режиме Таблица — выделяется строка и прокручивается к ней.','the selected person is preserved when switching between all modes (Tree → Cards → Table → Tree). In Table mode — the row is highlighted and scrolled into view.')}</p>
      </div>

      <div class="help-section">
        <div class="help-section-title">🃏 ${t('about.cardsTitle')}</div>
        <p class="help-p">${ru(
          'Выбранный человек в центре; вокруг него карточки родственников.',
          'Selected person in the centre; relatives shown around them.'
        )}</p>
        <ul class="help-ul">
          <li><strong>${ru('Клик на своей карточке','Click your own card')}</strong> — ${ru('открывает/закрывает панель деталей.','opens/closes the detail panel.')}</li>
          <li><strong>${ru('Клик на другой карточке','Click another card')}</strong> — ${ru('переключает выбранного человека.','switches the selected person.')}</li>
          <li><strong>${ru('Стрелка ▶ слева','Arrow ▶ on the left')}</strong> — ${ru('указывает на выбранного человека.','points to the selected person.')}</li>
          <li><strong>${ru('Левая боковая панель','Left sidebar')}</strong> — ${ru('список людей и дерево связей.','list of people and connection tree.')}</li>
          <li><strong>${ru('Навигация ◀/▶ вверху','◀/▶ navigation')}</strong> — ${ru('листание по всем людям.','browse all people.')}</li>
        </ul>
      </div>

      <div class="help-section">
        <div class="help-section-title">📊 ${t('about.tableTitle')}</div>
        <ul class="help-ul">
          <li>${ru('Клик по заголовку столбца — сортировка (повторный — обратная).','Click column header to sort; click again to reverse.')}</li>
          <li>${ru('Клик по фамилии — открывает боковую панель с деталями.','Click a surname to open the detail panel.')}</li>
          <li>${ru('При выборе человека в другом режиме — строка подсвечивается и прокручивается в зону видимости.','When a person is selected in another mode — the row is highlighted and scrolled into view.')}</li>
        </ul>
      </div>

      <div class="help-section">
        <div class="help-section-title">➕ ${ru('Добавление и редактирование','Adding & Editing')}</div>
        <ul class="help-ul">
          <li>${ru('Кнопка «Добавить» в тулбаре — форма нового человека.','«Add» button in toolbar — form for a new person.')}</li>
          <li>${ru('Клик по карточке → «Редактировать» — редактирование.','Click card → «Edit» to edit the person.')}</li>
          <li>${ru('Связи: Родитель / Ребёнок / Супруг(а) / Брат / Сестра.','Links: Parent / Child / Spouse / Brother / Sister.')}</li>
          <li>${ru('Фото хранятся в IndexedDB — без ограничения 5 МБ.','Photos stored in IndexedDB — no 5 MB limit.')}</li>
          <li>${ru('Клик на фото в карточке — просмотр в полном размере.','Click photo in card — view fullscreen.')}</li>
        </ul>
      </div>

      <div class="help-section">
        <div class="help-section-title">🔍 ${t('about.searchTitle')}</div>
        <ul class="help-ul">
          <li>${ru('Поиск по имени, семье, полу, статусу, поколению, году рождения.','Search by name, family, gender, status, generation, birth year.')}</li>
          <li>${ru('«Только с неполными данными» — люди без даты рождения, фамилии или семьи.','«Incomplete only» — people without birth date, last name or family.')}</li>
          <li>${ru('Клик по результату — переход к человеку в текущем режиме.','Click result — navigates to the person in the current view.')}</li>
        </ul>
      </div>

      <div class="help-section">
        <div class="help-section-title">💾 ${t('about.saveTitle')}</div>
        <ul class="help-ul">
          <li><span class="help-kbd">Ctrl+S</span> — ${ru('сохранить в браузер (localStorage).','save to browser (localStorage).')}</li>
          <li>${ru('Жёлтая точка рядом с 💾 — есть несохранённые изменения.','Yellow dot next to 💾 — unsaved changes exist.')}</li>
          <li>${ru('Автосохранение каждые 2 минуты.','Auto-save every 2 minutes.')}</li>
          <li>${ru('Экспорт JSON / GEDCOM — сохранить в файл.','Export JSON / GEDCOM — save to file.')}</li>
          <li>${ru('Импорт JSON / GEDCOM — загрузить с диска.','Import JSON / GEDCOM — load from disk.')}</li>
          <li>${ru('«Открыть файл» на стартовом экране поддерживает JSON и GEDCOM (.ged).','«Open file» on start screen supports JSON and GEDCOM (.ged).')}</li>
        </ul>
      </div>

      <div class="help-section">
        <div class="help-section-title">🎛️ ${ru('Кнопки тулбара','Toolbar buttons')}</div>
        <p class="help-p">${ru('В верхней панели программы расположены кнопки управления. Ниже — описание основных иконок:','The top toolbar contains control buttons. Below are the main icons:')}</p>
        <table class="help-kbtable">
          <tr><td><span style="font-size:18px">🏠</span></td><td><strong>${ru('На стартовый экран','To start screen')}</strong> — ${ru('возврат к стартовому экрану с кнопками «Продолжить», «Создать новое», «Открыть файл», «Посмотреть пример». Текущее древо сохраняется автоматически.','return to the start screen with «Continue», «New», «Open file», «View example» buttons. The current tree is auto-saved.')}</td></tr>
          <tr><td><span style="font-size:18px">📋</span></td><td><strong>${ru('Проверка данных','Validate data')}</strong> — ${ru('проверка целостности: люди без имени/фамилии, умершие без даты смерти, дубликаты связей, изолированные персоны. Открывает модальное окно со списком всех найденных проблем.','data integrity check: people without name/surname, deceased without death date, duplicate links, isolated persons. Opens a modal with the list of all issues found.')}</td></tr>
          <tr><td><span style="font-size:18px">☀️ / 🌙</span></td><td><strong>${ru('Сменить тему','Toggle theme')}</strong> — ${ru('переключение между светлой и тёмной темой оформления. Выбор сохраняется в браузере и применяется при следующем запуске.','switch between light and dark colour theme. The choice is saved in the browser and applied on the next launch.')}</td></tr>
          <tr><td><span style="font-size:18px">💾</span></td><td><strong>${ru('Сохранить','Save')}</strong> — ${ru('сохранение данных в браузер (localStorage + IndexedDB для фото). Жёлтая точка рядом с иконкой означает наличие несохранённых изменений.','save data to the browser (localStorage + IndexedDB for photos). A yellow dot next to the icon means there are unsaved changes.')}</td></tr>
          <tr><td><span style="font-size:18px">❓</span></td><td><strong>${ru('Помощь (F1)','Help (F1)')}</strong> — ${ru('открытие этого окна справки с описанием всех режимов и горячих клавиш.','open this help window with descriptions of all modes and keyboard shortcuts.')}</td></tr>
          <tr><td><span style="font-size:18px">⚙️</span></td><td><strong>${ru('Настройки','Settings')}</strong> — ${ru('выбор темы оформления, импорт/экспорт данных (JSON, GEDCOM), резервная копия, печать/PDF, очистка всех данных.','theme selection, data import/export (JSON, GEDCOM), backup, print/PDF, clear all data.')}</td></tr>
          <tr><td><span style="font-size:18px">ℹ️</span></td><td><strong>${ru('О программе','About')}</strong> — ${ru('информация о версии, авторе, лицензии и список изменений по версиям.','information about the version, author, license and the changelog by version.')}</td></tr>
          <tr><td><span style="font-size:18px">👥 / 🍃 / 🕯️</span></td><td><strong>${ru('Фильтр: Все / Живые / Ушедшие','Filter: All / Living / Deceased')}</strong> — ${ru('кнопки фильтрации отображаемых людей. «Все» показывает всех, «Живые» — только живых (🍃), «Ушедшие» — только умерших (🕯️). Работает во всех режимах: Дерево, Карточки, Таблица. Активный фильтр подсвечен, над деревом появляется баннер с кнопкой «Сбросить фильтр».','display filter buttons. «All» shows everyone, «Living» — only living (🍃), «Deceased» — only deceased (🕯️). Works in all modes: Tree, Cards, Table. The active filter is highlighted, a banner with «Clear filter» appears above the tree.')}</td></tr>
        </table>
      </div>

      <div class="help-section">
        <div class="help-section-title">⌨️ ${t('about.keysTitle')}</div>
        <table class="help-kbtable">
          <tr><td><span class="help-kbd">Ctrl+S</span></td><td>${t('about.keySave')}</td></tr>
          <tr><td><span class="help-kbd">Ctrl+F</span></td><td>${t('about.keySearch')}</td></tr>
          <tr><td><span class="help-kbd">F1</span></td><td>${t('about.keyHelp')}</td></tr>
          <tr><td><span class="help-kbd">F2</span></td><td>${ru('О программе','About')}</td></tr>
          <tr><td><span class="help-kbd">Escape</span></td><td>${t('about.keyEscape')}</td></tr>
          <tr><td><span class="help-kbd">1</span> / <span class="help-kbd">2</span> / <span class="help-kbd">3</span></td><td>${ru('Переключить режим: 1=Дерево, 2=Карточки, 3=Таблица','Switch mode: 1=Tree, 2=Cards, 3=Table')}</td></tr>
          <tr><td><span class="help-kbd">${ru('колесо','wheel')}</span></td><td>${ru('Масштаб в режиме Дерево ( курсор — якорь)','Zoom in Tree mode (cursor-anchored)')}</td></tr>
          <tr><td>${ru('Зажатая ЛКМ + перетаскивание','Hold LMB + drag')}</td><td>${ru('Панорамирование карты в режиме Дерево','Pan the map in Tree mode')}</td></tr>
          <tr><td>${ru('ПКМ по карточке','RMB on a card')}</td><td>${ru('Контекстное меню (потомки/предки/сиблинги/супруги/центр/карточка)','Context menu (descendants/ancestors/siblings/spouses/centre/card)')}</td></tr>
        </table>
      </div>`;
  },

  // v101 FIX Б25: Removed duplicate buildAboutHTML — was defined twice, second shadowing first.

  // v73 #24: legacy _legacyBuildHelpHTML removed — was a no-op stub
};
